/**
 * ONE-TIME SETUP SCRIPT — run once, then you're done.
 *
 * What it does:
 *  1. Creates the admin Firebase Auth account (shivaminfotech89@gmail.com)
 *  2. Writes admins/{uid} to Firestore  →  role: 'master'
 *  3. Seeds the initial activation codes into Firestore codes/{CODE}
 *
 * Run with:
 *   npx tsx scripts/seed-firebase.ts
 *
 * Safe to re-run — existing codes are NOT overwritten if already used.
 */

import { initializeApp } from 'firebase-admin/app';
import { cert }          from 'firebase-admin/app';
import { getAuth }       from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import dotenv from 'dotenv';

dotenv.config();

const privateKey = process.env.FIREBASE_PRIVATE_KEY;
if (!privateKey || !process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PROJECT_ID) {
  console.error('❌  Missing Firebase Admin credentials in .env');
  process.exit(1);
}

initializeApp({
  credential: cert({
    projectId:   process.env.FIREBASE_PROJECT_ID!,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL!,
    privateKey:  privateKey.replace(/\\n/g, '\n'),
  }),
});

const authAdmin  = getAuth();
const db         = getFirestore();

const ADMIN_EMAIL    = 'shivaminfotech89@gmail.com';
const ADMIN_PASSWORD = 'Megha@221092';

const INITIAL_CODES: { code: string; plan: string; durationDays: number }[] = [
  { code: 'NUTRI-STARTER',        plan: 'starter', durationDays: 7   },
  { code: 'NUTRI-FAMILY',         plan: 'family',  durationDays: 30  },
  { code: 'NUTRI-PREMIUM',        plan: 'premium', durationDays: 30  },
  { code: 'CNK2026-S',            plan: 'starter', durationDays: 7   },
  { code: 'CNK2026-F',            plan: 'family',  durationDays: 30  },
  { code: 'CNK2026-P',            plan: 'premium', durationDays: 30  },
  { code: 'MASTER-OVERRIDE-2026', plan: 'premium', durationDays: 365 },
];

async function seed() {
  console.log('🌱  Chef Nutri-Kid — Firebase seed script starting…\n');

  // ── 1. Create or fetch admin user ─────────────────────────────────────────
  let adminUser;
  try {
    adminUser = await authAdmin.getUserByEmail(ADMIN_EMAIL);
    console.log(`✅  Admin user already exists (uid: ${adminUser.uid})`);
  } catch {
    adminUser = await authAdmin.createUser({
      email:       ADMIN_EMAIL,
      password:    ADMIN_PASSWORD,
      displayName: 'Master Admin',
    });
    console.log(`✅  Admin user created   (uid: ${adminUser.uid})`);
  }

  // ── 2. Set custom claim so admin panel can verify role from the token ──────
  await authAdmin.setCustomUserClaims(adminUser.uid, { role: 'master' });
  console.log('✅  Custom claim set: { role: "master" }');

  // ── 3. Write admins/{uid} document ────────────────────────────────────────
  await db.collection('admins').doc(adminUser.uid).set({
    email:     ADMIN_EMAIL,
    role:      'master',
    createdAt: FieldValue.serverTimestamp(),
  }, { merge: true });
  console.log('✅  admins collection document written');

  // ── 4. Seed activation codes ───────────────────────────────────────────────
  const batch = db.batch();
  for (const { code, plan, durationDays } of INITIAL_CODES) {
    const ref  = db.collection('codes').doc(code);
    const snap = await ref.get();

    if (snap.exists && snap.data()?.status === 'used') {
      console.log(`⏩  Skipped (already used): ${code}`);
      continue;
    }

    batch.set(ref, {
      plan,
      durationDays,
      status:    'active',
      createdBy: adminUser.uid,
      createdAt: FieldValue.serverTimestamp(),
      usedBy:    null,
      usedAt:    null,
      expiresAt: null,
    }, { merge: true });
    console.log(`✅  Seeded: ${code}  (${plan}, ${durationDays}d)`);
  }
  await batch.commit();

  console.log('\n🎉  Seed complete!');
  console.log(`    Admin email : ${ADMIN_EMAIL}`);
  console.log(`    Admin UID   : ${adminUser.uid}`);
  process.exit(0);
}

seed().catch(err => {
  console.error('\n❌  Seed failed:', err.message || err);
  process.exit(1);
});
