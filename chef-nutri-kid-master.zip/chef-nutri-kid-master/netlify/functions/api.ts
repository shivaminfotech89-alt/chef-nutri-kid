import express from 'express';
import serverless from 'serverless-http';
import { apiRouter } from '../../src/api.js';

const app = express();

app.use(express.json({ limit: '50mb' }));

// CORS — permissive so admin panel and plans.html can call from any origin
app.use((_req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (_req.method === 'OPTIONS') { res.sendStatus(200); return; }
  next();
});

app.use('/api', apiRouter);

const serverlessApp = serverless(app);

export const handler = async (event: any, context: any) => {
  // Netlify invokes functions as /.netlify/functions/api/...
  // Strip /.netlify/functions so Express sees /api/admin/users etc.
  const fixedEvent = {
    ...event,
    path: (event.path || '/').replace('/.netlify/functions', '') || '/',
  };
  return serverlessApp(fixedEvent, context);
};
