# Chef Nutri-Kid Firebase Migration — Step 6 TODO

## Status as of this session

### DONE and browser-tested
- Step 1: Firebase packages installed, firebase.ts + firebaseAdmin.ts created
- Step 2: Auth (login/signup via AuthGate component)
- Step 3: Secure code activation endpoint (/api/activate-code) on Express server
- Step 4: Premium/plan data synced from Firestore on login (users/{uid} doc)
- Step 5: Child profiles saved to and loaded from Firestore (users/{uid}.childProfiles)
- Sign Out button added to header (red pill, calls Firebase signOut)
- Firestore security rules deployed (firestore.rules in project root)

### PARTIALLY APPLIED — Step 6: savedRecipes + alerts to Firestore

Edits 1 and 2 were applied manually by the user. Edits 3-6 are NOT yet applied.
AlertEngine.tsx is NOT yet changed. firestore.rules is NOT yet updated for Step 6.

App.tsx current state (confirmed clean):
- Edit 1 DONE: line 48 is `const [alerts, setAlerts] = useState<any[]>(...)`
- Edit 2 DONE: line 79 is `const alertCount = alerts.filter(...).length;`
- Edit 3 NOT DONE: login useEffect still says "Steps 4 & 5", still missing setSavedRecipes/setAlerts
- Edit 4 NOT DONE: duplicate React.useEffect for savedRecipes still present (~line 258)
- Edit 5 NOT DONE: savedRecipes autosave still localStorage-only (~line 323)
- Edit 6 NOT DONE: AlertEngine JSX call still uses old onClose with setAlertCount

IMPORTANT: Claude's Edit tool previews appear truncated/mangled on this user's screen.
Recommend doing Edits 3-6 manually using the code blocks below as reference,
OR having Claude show each edit as a plain code block and confirm before applying.

---

## App.tsx — 6 edits needed (in order)

### Edit 1 — line ~48: replace alertCount state with alerts state
OLD:
  const [alertCount, setAlertCount] = useState(0);

NEW:
  const [alerts, setAlerts] = useState<any[]>(() => store.get<any[]>('cnk_alerts', []));

### Edit 2 — lines ~79-90: replace polling alertCount useEffect with derived const
OLD:
  // Check for active alerts count
  useEffect(() => {
    const checkAlerts = () => {
      try {
        const alerts = store.get<any[]>('cnk_alerts', []);
        setAlertCount(alerts.filter((a: any) => a.active).length);
      } catch {}
    };
    checkAlerts();
    const timer = setInterval(checkAlerts, 60000);
    return () => clearInterval(timer);
  }, []);

NEW:
  const alertCount = alerts.filter((a: any) => a.active).length;

### Edit 3 — login/logout useEffect: extend to cover savedRecipes and alerts
OLD comment: // ── Steps 4 & 5: Sync plan + child profiles from Firestore on login / logout ──
Add to logout branch (after setProfiles([])):
  setSavedRecipes([]);
  setAlerts([]);

Add to login branch (after childProfiles block):
  if (Array.isArray(d.savedRecipes) && d.savedRecipes.length > 0) {
    setSavedRecipes(d.savedRecipes);
  }
  if (Array.isArray(d.alerts) && d.alerts.length > 0) {
    setAlerts(d.alerts);
  }

Update comment to: // ── Steps 4, 5 & 6: Sync plan, profiles, recipes + alerts from Firestore ──

### Edit 4 — remove duplicate savedRecipes autosave (the React.useEffect one, ~line 258)
DELETE this entire block:
  React.useEffect(() => {
    localStorage.setItem('nutripeds_recipe_box', JSON.stringify(savedRecipes));
  }, [savedRecipes]);

### Edit 5 — extend remaining savedRecipes autosave + add alerts autosave (~line 323)
OLD:
  useEffect(() => { store.set('cnk_saved_recipes', savedRecipes); }, [savedRecipes]);

NEW (replace with two useEffects):
  useEffect(() => {
    store.set('cnk_saved_recipes', savedRecipes);
    if (currentUser && currentUser !== 'loading') {
      setDoc(doc(db, 'users', (currentUser as User).uid), { savedRecipes }, { merge: true })
        .catch((err: any) => console.error('[Firestore] setDoc ERROR:', err));
    }
  }, [savedRecipes]);
  useEffect(() => {
    store.set('cnk_alerts', alerts);
    if (currentUser && currentUser !== 'loading') {
      setDoc(doc(db, 'users', (currentUser as User).uid), { alerts }, { merge: true })
        .catch((err: any) => console.error('[Firestore] setDoc ERROR:', err));
    }
  }, [alerts]);

### Edit 6 — AlertEngine JSX call: pass new props, simplify onClose
OLD:
      {showAlertEngine && (
        <AlertEngine onClose={() => { setShowAlertEngine(false); const a = JSON.parse(localStorage.getItem('cnk_alerts')||'[]'); setAlertCount(a.filter((x:any)=>x.active).length); }}/>
      )}

NEW:
      {showAlertEngine && (
        <AlertEngine alerts={alerts} setAlerts={setAlerts} onClose={() => setShowAlertEngine(false)} />
      )}

---

## AlertEngine.tsx — 4 changes needed

File: src/components/AlertEngine.tsx

### Change 1 — Props interface: add alerts and setAlerts
OLD:
  interface Props {
    onClose: () => void;
  }

NEW:
  interface Props {
    alerts: any[];
    setAlerts: (updated: any[]) => void;
    onClose: () => void;
  }

### Change 2 — component signature: destructure new props
OLD:
  export default function AlertEngine({ onClose }: Props) {

NEW:
  export default function AlertEngine({ alerts, setAlerts, onClose }: Props) {

### Change 3 — remove internal alerts useState (lines 22-24)
DELETE:
  const [alerts, setAlerts] = useState<Alert[]>(() => {
    try { return JSON.parse(localStorage.getItem('cnk_alerts') || '[]'); } catch { return []; }
  });

### Change 4 — simplify save() function (remove localStorage write)
OLD:
  const save = (updated: Alert[]) => {
    setAlerts(updated);
    localStorage.setItem('cnk_alerts', JSON.stringify(updated));
  };

NEW:
  const save = (updated: Alert[]) => {
    setAlerts(updated);
  };

---

## firestore.rules — 1 change needed

File: firestore.rules (project root)

The current rule allows client writes only to 'childProfiles'.
Change the hasOnly() check to also allow 'savedRecipes' and 'alerts':

OLD:
  ? request.resource.data.keys().hasOnly(['childProfiles'])
  : request.resource.data.diff(resource.data).affectedKeys()
      .hasOnly(['childProfiles'])

NEW:
  ? request.resource.data.keys().hasOnly(['childProfiles', 'savedRecipes', 'alerts'])
  : request.resource.data.diff(resource.data).affectedKeys()
      .hasOnly(['childProfiles', 'savedRecipes', 'alerts'])

After updating, copy the full contents of firestore.rules and publish in
Firebase Console -> Firestore -> Rules.

---

## After Step 6 is complete

Next step is Step 8: Admin panel connected to Firebase.
Step 7 (photo Storage migration) is permanently skipped per user decision.
