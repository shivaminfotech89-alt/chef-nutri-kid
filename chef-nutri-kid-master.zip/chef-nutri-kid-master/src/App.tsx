import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Sparkles, Utensils, BookOpen, UserCheck, ShieldAlert, Award, ArrowLeft, Search, HelpCircle, Activity, ChevronRight, Upload, PlayCircle, Globe, Calendar as CalendarIcon, Leaf, Users, Download, BookmarkPlus, Bookmark, Book, Trash2, Lock, Crown, X, TrendingUp, BarChart2, Bell, Target, Camera, Image as ImageIcon, Volume2, VolumeX } from 'lucide-react';
import IngredientSelector from './components/IngredientSelector';
import HarvardPlate from './components/HarvardPlate';
import WeeklyPlanner from './components/WeeklyPlanner';
import ProfileManager from './components/ProfileManager';
import GrowthTracker from './components/GrowthTracker';
import DailyProgress from './components/DailyProgress';
import AlertEngine from './components/AlertEngine';
import MomentsGallery from './components/MomentsGallery';
import { type Recipe, type DietaryPreference, type ChildProfile, type HealthReport, type OptimizationGoal } from './data';
import { downloadAsPDF } from './utils';
import { freemium, store } from './freemium';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import AuthGate from './components/AuthGate';

export default function App() {
  const [activeTab, setActiveTab] = useState<'pantry' | 'weekly' | 'box'>('pantry');
  const [currentUser, setCurrentUser] = useState<User | null | 'loading'>('loading');

  // ── FIX #2: All state initialized from localStorage ──
  const [isPremium, setIsPremium] = useState<boolean>(() => freemium.isPremium());
  const [hasUsedFree, setHasUsedFree] = useState<boolean>(() => freemium.hasUsedFree());
  const [showPaywall, setShowPaywall] = useState<boolean>(false);
  const [paywallReason, setPaywallReason] = useState<'generate' | 'profile' | 'report' | 'weekly' | 'save'>('generate');
  const [unlockCode, setUnlockCode] = useState<string>('');
  const [unlockError, setUnlockError] = useState<string>('');

  // ── FIX #1: User profile required before activation ──
  const [showUserProfileForm, setShowUserProfileForm] = useState(false);
  const [userProfileName, setUserProfileName] = useState(() => freemium.getUserData().name || '');
  const [userProfileEmail, setUserProfileEmail] = useState(() => freemium.getUserData().email || '');
  const [userProfilePhone, setUserProfilePhone] = useState(() => freemium.getUserData().phone || '');
  const [pendingCode, setPendingCode] = useState('');

  // ── FIX #3: Speech synthesis state ──
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  // ── New feature modals ──
  const [showGrowthTracker, setShowGrowthTracker] = useState(false);
  const [showDailyProgress, setShowDailyProgress] = useState(false);
  const [showAlertEngine, setShowAlertEngine] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [optimizationGoal, setOptimizationGoal] = useState<OptimizationGoal | ''>('');
  const [alerts, setAlerts] = useState<any[]>(() => store.get<any[]>('cnk_alerts', []));
  // ── Plan expiration countdown (Fix #3) ──
  const [remainingDays, setRemainingDays] = useState<number | null>(() => freemium.getRemainingDays());
  const [showRenewalModal, setShowRenewalModal] = useState(false);

  // Recompute remaining days + enforce expiry + check code revocation
  useEffect(() => {
    const check = () => {
      const justExpired = freemium.enforceExpiry();
      const justRevoked = freemium.validateActiveCode();
      setRemainingDays(freemium.getRemainingDays());
      if (justExpired || justRevoked) {
        setIsPremium(false);
        setShowRenewalModal(true);
      }
    };
    check();
    // Check every 30s so admin revocation / expiry reflects quickly
    const t = setInterval(check, 30 * 1000);
    return () => clearInterval(t);  }, []);


  // ── FIX #2: Autosave deep state to localStorage on every change ──
  useEffect(() => {
    store.set('cnk_active_tab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    store.set('cnk_optimization_goal', optimizationGoal);
  }, [optimizationGoal]);

  const alertCount = alerts.filter((a: any) => a.active).length;

  // ── Firebase Auth listener ──
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => setCurrentUser(user));
    return unsub;
  }, []);

  // ── Steps 4, 5 & 6: Sync plan, profiles, recipes + alerts from Firestore ──
  useEffect(() => {
    if (currentUser === 'loading') return;
    if (currentUser === null) {
      freemium.reset();
      setIsPremium(false);
      setRemainingDays(null);
      setProfiles([]);
      setSavedRecipes([]);
      setAlerts([]);
      return;
    }
    const unsubscribe = onSnapshot(
      doc(db, 'users', currentUser.uid),
      (snap) => {
        if (!snap.exists()) return;
        const d = snap.data();
        if (d.isPremium) {
          store.set('cnk_is_premium',   true);
          store.set('cnk_plan_type',    d.planType   || 'starter');
          store.set('cnk_plan_expiry',  d.planExpiry || '');
          store.set('cnk_activated_at', d.activatedAt || new Date().toISOString());
          store.set('cnk_used_code',    d.usedCode   || '');
          setIsPremium(true);
          setRemainingDays(freemium.getRemainingDays());
        }
        if (Array.isArray(d.childProfiles) && d.childProfiles.length > 0) {
          setProfiles(d.childProfiles);
        }
        if (Array.isArray(d.savedRecipes) && d.savedRecipes.length > 0) {
          setSavedRecipes(d.savedRecipes);
        }
        if (Array.isArray(d.alerts) && d.alerts.length > 0) {
          setAlerts(d.alerts);
        }
      },
      (err) => console.error('[Firestore] onSnapshot ERROR:', err)
    );
    return unsubscribe;
  }, [currentUser]);


  const triggerPaywall = (reason: typeof paywallReason) => {
    setPaywallReason(reason);
    setShowPaywall(true);
  };

  const handleSignOut = async () => {
    const { signOut } = await import('firebase/auth');
    await signOut(auth);
  };

  const handleUnlock = async () => {
    setUnlockError('');
    const code = (pendingCode || unlockCode).trim().toUpperCase();
    if (!code) { setUnlockError('Please enter your activation code.'); return; }

    const result = await freemium.unlockWithServer(code);
    if (result.success) {
      setIsPremium(true);
      setRemainingDays(freemium.getRemainingDays());
      setShowPaywall(false);
      setUnlockCode('');
      setPendingCode('');
      setShowUserProfileForm(false);
      alert('🎉 Plan activated successfully! Welcome to Chef Nutri-Kid Premium! 🌟');
    } else {
      setUnlockError(result.error || '❌ Invalid code. Check the code sent to your WhatsApp.');
    }
  };

  const handleSaveUserProfile = async () => {
    if (!userProfileName.trim() || !userProfileEmail.trim() || !userProfileEmail.includes('@')) {
      setUnlockError('Please enter your full name and valid email address.');
      return;
    }
    freemium.setUserData({ name: userProfileName.trim(), email: userProfileEmail.trim(), phone: userProfilePhone.trim() });
    setShowUserProfileForm(false);
    if (pendingCode) {
      const result = await freemium.unlockWithServer(pendingCode);
      if (result.success) {
        setIsPremium(true);
        setRemainingDays(freemium.getRemainingDays());
        setShowPaywall(false);
        setPendingCode('');
        setUnlockCode('');
        alert('🎉 Plan activated! Welcome to Chef Nutri-Kid Premium! 🌟');
      } else {
        setUnlockError(result.error || 'Activation failed.');
      }
    }
  };

  // ── Onboarding guide ──
  const [showOnboarding, setShowOnboarding] = useState<boolean>(() => {
    return !localStorage.getItem('cnk_onboarded');
  });
  const [onboardStep, setOnboardStep] = useState<number>(0);

  const onboardSteps = [
    { emoji: '👋', title: 'Welcome to Chef Nutri-Kid!', desc: 'Your AI-powered nutrition guide for your little ones. Let us show you around in 30 seconds!' },
    { emoji: '🥦', title: 'Pick Ingredients', desc: 'Tap food items from the list below OR use the 📷 Scan button to scan real food from your kitchen!' },
    { emoji: '✨', title: 'Generate Magic Recipe', desc: 'Click the orange "Create Chef Nutri-Kid Magic Recipe" button to get 2 healthy recipes with exact quantities!' },
    { emoji: '👶', title: 'Add Your Child Profile', desc: 'Click "NutriPeds Profiles" at the top to add your child\'s name, date of birth and allergies. Get personalized recipes!' },
    { emoji: '📊', title: 'Health Report', desc: 'Select your child profile → Click "Report" button to get a complete nutrition analysis with daily meal plan!' },
    { emoji: '📅', title: 'Weekly Planner', desc: 'Click "Weekly Planner" tab to get a full 7-day meal chart — changes every week automatically!' },
    { emoji: '🔊', title: 'Recipe Read Aloud', desc: 'After generating a recipe, click "Read Recipe Aloud" button — it reads the recipe in your selected language!' },
    { emoji: '🎉', title: 'You\'re All Set!', desc: 'Enjoy Chef Nutri-Kid! Select your language from the top right. Change language anytime — page updates instantly!' },
  ];

  const completeOnboarding = () => {
    localStorage.setItem('cnk_onboarded', 'true');
    setShowOnboarding(false);
  };

  // ── Language change with page feedback ──
  // FIX #6: Save to localStorage and hard reload — no React state dependency
  const handleLanguageChange = (newLang: string) => {
    try {
      freemium.setLanguage(newLang);
    } catch {}
    // Hard reload boots app fresh with new locale from storage
    window.location.reload();
  };

  const [selectedIngredients, setSelectedIngredients] = useState<string[]>(['Broccoli', 'Carrots', 'Brown Rice', 'Chicken Breast', 'Eggs', 'Olive Oil', 'Fresh Water']);
  const [language, setLanguage] = useState<string>(() => freemium.getLanguage());

  // ── FIX #3: handleReadAloud MUST be declared AFTER language state to avoid TDZ ──
  const handleReadAloud = useCallback((text: string) => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const langMap: Record<string, string> = {
      'Gujarati': 'gu', 'Hindi': 'hi', 'English': 'en',
      'Español': 'es', 'Français': 'fr', 'Deutsch': 'de'
    };
    const langCode = langMap[language] || 'en';
    const voice = voices.find(v => v.lang.startsWith(langCode));
    if (voice) utter.voice = voice;
    utter.rate = 0.85; utter.pitch = 1.05;
    utter.onend = () => setIsSpeaking(false);
    utter.onerror = () => setIsSpeaking(false);
    speechRef.current = utter;
    setIsSpeaking(true);
    window.speechSynthesis.speak(utter);
  }, [isSpeaking, language]);

  const [diet, setDiet] = useState<DietaryPreference>('Any / No Restriction');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [recipeOptions, setRecipeOptions] = useState<Recipe[] | null>(null);
  const [recipeFallbackNote, setRecipeFallbackNote] = useState<string | null>(null);
  const [healthReport, setHealthReport] = useState<HealthReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [moveChallengeDone, setMoveChallengeDone] = useState<boolean>(false);
  const [showMoveConfetti, setShowMoveConfetti] = useState<boolean>(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Recipe Box State
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>(() => {
    try {
      const stored = localStorage.getItem('nutripeds_recipe_box');
      return stored ? JSON.parse(stored) : [];
    } catch(e) { return []; }
  });

  // Recipe Box — which saved recipe is expanded to show step-by-step
  const [expandedBoxIdx, setExpandedBoxIdx] = useState<number | null>(null);

  // Profile Management State
  const [profiles, setProfiles] = useState<ChildProfile[]>(() => store.get<ChildProfile[]>('cnk_child_profiles', []));
  const [activeProfileId, setActiveProfileId] = useState<string | null>(() => {
    try { return localStorage.getItem('cnk_active_profile_id') || null; } catch { return null; }
  });
  // Persist active child selection across refreshes
  useEffect(() => {
    try {
      if (activeProfileId) localStorage.setItem('cnk_active_profile_id', activeProfileId);
      else localStorage.removeItem('cnk_active_profile_id');
    } catch {}
  }, [activeProfileId]);
  // Auto-select when exactly one child exists; clear if the active child was deleted
  useEffect(() => {
    if (profiles.length === 1 && !activeProfileId) {
      setActiveProfileId(profiles[0].id);
    } else if (activeProfileId && !profiles.some(p => p.id === activeProfileId)) {
      setActiveProfileId(null);
    }
  }, [profiles, activeProfileId]);

  // ── FIX #7: Admin reactive sync — listen for admin actions across tabs ──
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'nk_admin_action' && e.newValue) {
        try {
          const action = JSON.parse(e.newValue);
          const affectedMe = freemium.syncAdminAction(action);
          if (affectedMe) {
            setIsPremium(false);
            setRemainingDays(null);
            if (action.type === 'deleteProfile') {
              setProfiles([]);
              setActiveProfileId(null);
            }
            window.location.reload();
          }
        } catch {}
      }
      if (e.key === 'cnk_is_premium') {
        setIsPremium(freemium.isPremium());
        setRemainingDays(freemium.getRemainingDays());
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);

  // FIX #2: Autosave profiles and recipes — MUST be AFTER state declarations to avoid TDZ
  useEffect(() => {
    store.set('cnk_child_profiles', profiles);
    if (currentUser && currentUser !== 'loading') {
      const stripped = profiles.map(({ photo: _p, ...rest }: any) => rest);
      setDoc(doc(db, 'users', (currentUser as User).uid), { childProfiles: stripped }, { merge: true })
        .catch((err: any) => console.error('[Firestore] setDoc ERROR:', err));
    }
 }, [profiles]);
  useEffect(() => {
    store.set('cnk_saved_recipes', savedRecipes);
    if (currentUser && currentUser !== 'loading') {
      setDoc(doc(db, 'users', (currentUser as User).uid), { savedRecipes }, { merge: true })
        .catch((err: any) => console.error('[Firestore] setDoc ERROR:', err));
    }
  }, [savedRecipes]);
  useEffect(() => {
    store.set('cnk_alerts', alerts);
    if (currentUser && currentUser !== 'loading') {
      setDoc(doc(db, 'users', (currentUser as User).uid), { alerts }, { merge: true })
        .catch((err: any) => console.error('[Firestore] setDoc ERROR:', err));
    }
  }, [alerts]);

  const activeProfile = profiles.find(p => p.id === activeProfileId);

  // Playful cooking state tips to rotate through during generation
  const [loadingTipIndex, setLoadingTipIndex] = useState(0);
  const loadingTips = [
    "Washing our fresh vegetables to create superhero shields... 🥬🧼",
    "Gently measuring out the steady-energy whole grains... 🌾📏",
    "Prepping the muscle-builder proteins with kid-glove care... 🍗🔬",
    "Stir-frying up some magic with cold-pressed olive oil... 🫗✨",
    "Pouring custom hydration cups to keep our brains sparkling... 💧🧠",
    "Chef Nutri-Kid is polishing the golden dining spoons... 🥄⭐"
  ];

  // Dynamic interval to change tips during loading
  React.useEffect(() => {
    let timer: any;
    if (isLoading) {
      timer = setInterval(() => {
        setLoadingTipIndex((prev) => (prev + 1) % loadingTips.length);
      }, 2500);
    }
    return () => clearInterval(timer);
  }, [isLoading]);

  const handleGenerateRecipe = async () => {
    // Freemium gate — block if used free trial and not premium
    if (!isPremium && hasUsedFree) {
      triggerPaywall('generate');
      return;
    }
    // ── Premium must select a child so the meal matches that child ──
    if (isPremium && profiles.length > 0 && !activeProfile) {
      setError('👶 Please select which child this recipe is for. Recipes are tailored to each child\'s exact age, diet and allergies.');
      // Scroll the picker into view if present
      try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch {}
      return;
    }
    if (isPremium && profiles.length === 0) {
      setError('👶 Please add a child profile first (tap "NutriPeds Profiles" at the top) so recipes match your child.');
      return;
    }
    // ── Allergy safety gate ──
    const allergies = (activeProfile?.allergies || []).map(a => a.toLowerCase().trim()).filter(Boolean);
    if (allergies.length > 0) {
      const hit = selectedIngredients.find(item => {
        const it = item.toLowerCase();
        return allergies.some(al => it.includes(al) || al.includes(it));
      });
      if (hit) {
        setError(`🚨 "${hit}" conflicts with ${activeProfile?.name}'s allergy (${activeProfile?.allergies?.join(', ')}). Please remove it before generating a recipe.`);
        return;
      }
    }
    setIsLoading(true);
    setError(null);
    setCompletedTasks([]);
    setMoveChallengeDone(false);
    setShowMoveConfetti(false);
    setUploadedPhotos([]);
    setHealthReport(null);

    try {
      const ingredientString = selectedIngredients.join(', ');
      const effectiveDiet = activeProfile ? activeProfile.foodCategories : diet;
      const isVegetarian = /vegetarian|vegan|jain/i.test(effectiveDiet) && !/non-veg/i.test(effectiveDiet);

      const requestBody: any = { 
        ingredients: ingredientString, 
        language, 
        diet: effectiveDiet,
        isVegetarian,
        childAge: activeProfile ? (activeProfile.ageDisplay || `${activeProfile.age} years`) : undefined,
        childAllergies: activeProfile?.allergies?.join(', ') || undefined,
        optimizationGoal: optimizationGoal || undefined,
      };
      if (activeProfile) {
         requestBody.childProfile = activeProfile;
      }

      const response = await fetch('/api/recipe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('API server not found! Please ensure your backend functions are deployed and GEMINI_API_KEY is configured in your hosting environment.');
        }
        let errMessage = 'Our baking ovens got a bit too hot! Let\'s try mixing ingredients again.';
        try {
            const errData = await response.json();
            if (errData.error) errMessage = errData.error;
        } catch (e) {}
        throw new Error(errMessage);
      }

      const data = await response.json();
      if (data?.error) { throw new Error(data.error); }

      if (data?.recipes && Array.isArray(data.recipes)) {
        setRecipeOptions(data.recipes);
        // Show a note if the AI was busy and returned the English backup
        setRecipeFallbackNote(data.isLive === false && data.fallbackNote ? data.fallbackNote : null);
        // Mark free trial as used after first successful generation
        if (!isPremium) {
          freemium.markUsed();
          setHasUsedFree(true);
        }
      } else {
        throw new Error("Invalid response format received from the server.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Something went wrong in Chef Nutri-Kid\'s kitchen. Please make sure your server is online.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateReport = async (profile: ChildProfile) => {
    if (!isPremium) { triggerPaywall('report'); return; }
    setIsLoading(true);
    setError(null);
    setRecipe(null);
    setHealthReport(null);
    setShowProfileModal(false);

    try {
      const response = await fetch('/api/health-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ childProfile: profile, language })
      });

      if (!response.ok) {
        let errMessage = 'Failed to generate report.';
        try { const errData = await response.json(); if(errData.error) errMessage = errData.error; } catch(e) {}
        throw new Error(errMessage);
      }

      const reportData = await response.json();
      setHealthReport(reportData);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate the creative health report.');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTask = (task: string) => {
    if (completedTasks.includes(task)) {
      setCompletedTasks(completedTasks.filter(t => t !== task));
    } else {
      setCompletedTasks([...completedTasks, task]);
    }
  };

  const handleCompleteMoveChallenge = () => {
    setMoveChallengeDone(true);
    setShowMoveConfetti(true);
    setTimeout(() => {
      setShowMoveConfetti(false);
    }, 4000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result && typeof e.target.result === 'string') {
          setUploadedPhotos(prev => [...prev, e.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // ── Auth gate — every hook above has already been called unconditionally ──
  if (currentUser === 'loading') {
    return (
      <div className="min-h-screen bg-[#FFFDF0] flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4">👨‍🍳</div>
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-4 border-b-4 border-[#FF6B6B]" />
          <p className="text-slate-400 text-sm font-semibold mt-3">Loading Chef Nutri-Kid…</p>
        </div>
      </div>
    );
  }
  if (!currentUser) return <AuthGate />;

  return (
    <div className="min-h-screen bg-[#FFFDF0] font-sans pb-16 transition-all duration-300">
      {/* Visual Accent top ribbon */}
      <div className="h-3 bg-gradient-to-r from-[#FF6B6B] via-[#FFD93D] to-[#4ECDC4]"></div>

      {/* Language Changed Toast */}
      <div id="lang-changed-toast" style={{position:'fixed',top:'70px',left:'50%',transform:'translateX(-50%)',background:'#4ECDC4',color:'#fff',padding:'8px 20px',borderRadius:'999px',fontWeight:800,fontSize:'13px',zIndex:999,opacity:0,transition:'opacity 0.3s',pointerEvents:'none'}}>
        🌐 Language changed to {language}!
      </div>

      {/* Onboarding Guide Modal */}
      {showOnboarding && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-[70] backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-7 shadow-2xl border-4 border-[#FFD93D] w-full max-w-sm text-center">
            <div className="text-5xl mb-4">{onboardSteps[onboardStep].emoji}</div>
            <div className="flex justify-center gap-1.5 mb-4">
              {onboardSteps.map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full transition-all ${i === onboardStep ? 'w-6 bg-[#FF6B6B]' : 'w-1.5 bg-slate-200'}`}/>
              ))}
            </div>
            <h2 className="text-xl font-black text-slate-800 mb-3">{onboardSteps[onboardStep].title}</h2>
            <p className="text-sm text-slate-500 leading-relaxed mb-6">{onboardSteps[onboardStep].desc}</p>
            <div className="flex gap-2">
              {onboardStep > 0 && (
                <button onClick={() => setOnboardStep(s => s-1)} className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-2xl font-black text-sm hover:bg-slate-200">← Back</button>
              )}
              {onboardStep < onboardSteps.length - 1 ? (
                <button onClick={() => setOnboardStep(s => s+1)} className="flex-1 py-3 bg-[#FF6B6B] text-white rounded-2xl font-black text-sm hover:bg-red-500">Next →</button>
              ) : (
                <button onClick={completeOnboarding} className="flex-1 py-3 bg-[#4ECDC4] text-white rounded-2xl font-black text-sm hover:bg-teal-500">🎉 Let's Start!</button>
              )}
            </div>
            <button onClick={completeOnboarding} className="mt-3 text-xs text-slate-400 hover:text-slate-600 font-semibold">Skip tour</button>
          </div>
        </div>
      )}

      {/* FIX #1: User Profile Form Modal */}
      {showUserProfileForm && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-[80] backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-7 shadow-2xl border-4 border-[#4ECDC4] w-full max-w-md">
            <div className="text-center mb-5">
              <div className="text-4xl mb-2">👤</div>
              <h2 className="text-xl font-black text-slate-800">Complete Your Profile</h2>
              <p className="text-sm text-slate-500 mt-1">Required before activating your plan — this links your subscription to your account.</p>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Full Name *</label>
                <input type="text" value={userProfileName} onChange={e => setUserProfileName(e.target.value)} placeholder="e.g. Priya Sharma" className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
              </div>
              <div>
                <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Email Address *</label>
                <input type="email" value={userProfileEmail} onChange={e => setUserProfileEmail(e.target.value)} placeholder="you@email.com" className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
              </div>
              <div>
                <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">WhatsApp Number</label>
                <input type="tel" value={userProfilePhone} onChange={e => setUserProfilePhone(e.target.value)} placeholder="9876543210" className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
              </div>
              {unlockError && <p className="text-xs text-red-500 font-bold bg-red-50 p-2.5 rounded-xl">{unlockError}</p>}
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={handleSaveUserProfile} className="flex-1 py-3 bg-[#4ECDC4] text-white rounded-2xl font-black text-sm hover:bg-teal-500">
                ✅ Save & Activate Plan
              </button>
              <button onClick={() => { setShowUserProfileForm(false); setPendingCode(''); setUnlockError(''); }} className="px-4 py-3 bg-slate-100 text-slate-600 rounded-2xl font-black text-sm">
                Cancel
              </button>
            </div>
            <p className="text-xs text-slate-400 text-center mt-3">🔒 Your data is stored locally on your device only.</p>
          </div>
        </div>
      )}

      {/* FIX #9: Moments Gallery */}
      {showGallery && <MomentsGallery onClose={() => setShowGallery(false)}/>}

      {/* Growth Tracker Modal */}
      {showGrowthTracker && activeProfile && (
        <GrowthTracker
          profile={activeProfile}
          onUpdate={(updated) => {
            setProfiles(profiles.map(p => p.id === updated.id ? updated : p));
          }}
          onClose={() => setShowGrowthTracker(false)}
        />
      )}

      {/* Daily Progress Modal */}
      {showDailyProgress && activeProfile && (
        <DailyProgress
          profile={activeProfile}
          onUpdate={(updated) => {
            setProfiles(profiles.map(p => p.id === updated.id ? updated : p));
          }}
          onClose={() => setShowDailyProgress(false)}
        />
      )}

 {/* Alert Engine Modal */}
      {showAlertEngine && (
        <AlertEngine alerts={alerts} setAlerts={setAlerts} onClose={() => setShowAlertEngine(false)} />
      )}

      {/* Plan Renewal Modal (Fix #3) */}
      {showRenewalModal && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-[90] backdrop-blur-sm" onClick={() => setShowRenewalModal(false)}>
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-amber-200 w-full max-w-sm p-6 text-center" onClick={e => e.stopPropagation()}>
            <div className="text-5xl mb-3">{remainingDays !== null && remainingDays <= 0 ? '🔒' : '⏳'}</div>
            <h2 className="text-lg font-black text-slate-800 mb-1">
              {remainingDays !== null && remainingDays <= 0 ? 'Your Plan Has Expired' : `${remainingDays} Day${remainingDays === 1 ? '' : 's'} Remaining`}
            </h2>
            <p className="text-sm text-slate-500 mb-5">
              {remainingDays !== null && remainingDays <= 0
                ? 'Renew now to keep generating personalized recipes, meal plans, and tracking your child\'s nutrition.'
                : 'Renew early to avoid any interruption to your child\'s nutrition journey.'}
            </p>
            <div className="space-y-2">
              <a href="/plans.html"
                className="block w-full py-3 bg-gradient-to-r from-[#FF6B6B] to-orange-500 text-white rounded-2xl font-black text-sm">
                🔄 Renew My Plan
              </a>
              <button onClick={() => setShowRenewalModal(false)}
                className="w-full py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-2xl">
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}

      {showPaywall && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[60] backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-7 shadow-2xl border-4 border-[#FFD93D] w-full max-w-md">
            <div className="flex justify-between items-start mb-4">
              <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-3xl mb-1">🔒</div>
              <button onClick={() => { setShowPaywall(false); setUnlockError(''); setUnlockCode(''); }} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <h2 className="text-2xl font-black text-slate-800 mb-1">
              {paywallReason === 'generate' ? '🍳 Free Trial Used!' :
               paywallReason === 'profile' ? '👤 Child Profiles — Premium' :
               paywallReason === 'report' ? '📊 Health Reports — Premium' :
               paywallReason === 'weekly' ? '📅 Weekly Planner — Premium' :
               '🔖 Recipe Box — Premium'}
            </h2>
            <p className="text-slate-500 text-sm mb-5 leading-relaxed">
              {paywallReason === 'generate'
                ? 'You\'ve used your 1 free recipe generation. Upgrade to a plan to generate unlimited recipes, save favourites, and access all premium features!'
                : 'This feature is available to paid plan members. Upgrade to unlock child profiles, health reports, weekly planners, and unlimited recipe generation!'}
            </p>

            {/* Plan quick links */}
            <div className="space-y-2 mb-5">
              {[
                { name: '🌱 Starter', price: '₹199/month', desc: 'Unlimited recipes + WhatsApp plan' },
                { name: '👨‍👩‍👧 Family', price: '₹399/month', desc: 'Profiles + weekly planner + 3 children' },
              ].map(plan => (
                <div key={plan.name} className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3">
                  <div>
                    <div className="font-bold text-sm text-slate-800">{plan.name} — <span className="text-[#FF6B6B]">{plan.price}</span></div>
                    <div className="text-xs text-slate-500">{plan.desc}</div>
                  </div>
                  <a href="/plans.html" target="_blank" rel="noreferrer">
                    <button className="text-xs bg-[#FF6B6B] text-white px-3 py-1.5 rounded-xl font-bold hover:bg-red-500 transition-colors">
                      Register & Pay →
                    </button>
                  </a>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-4">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Already have an activation code?</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={unlockCode}
                  onChange={e => { setUnlockCode(e.target.value); setUnlockError(''); }}
                  onKeyDown={e => e.key === 'Enter' && handleUnlock()}
                  placeholder="Enter code e.g. NUTRI-STARTER"
                  className="flex-1 p-3 border-2 border-slate-200 rounded-xl text-sm font-bold focus:border-[#FF6B6B] outline-none"
                />
                <button onClick={handleUnlock} className="px-4 py-3 bg-[#4ECDC4] text-white rounded-xl font-bold text-sm hover:bg-teal-500 transition-colors">
                  Unlock
                </button>
              </div>
              {unlockError && <p className="text-xs text-red-500 font-bold mt-2">{unlockError}</p>}
              <p className="text-xs text-slate-400 mt-2">You'll receive an activation code on WhatsApp after payment confirmation.</p>
            </div>
          </div>
        </div>
      )}

      {showProfileModal && (
        <ProfileManager 
          profiles={profiles} 
          setProfiles={setProfiles} 
          activeProfileId={activeProfileId} 
          setActiveProfileId={setActiveProfileId} 
          onClose={() => setShowProfileModal(false)}
          onGenerateReport={handleGenerateReport}
          isPremium={isPremium}
        />
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">

        {/* Global Header Section */}
        <header className="print:hidden flex flex-col sm:flex-row items-center justify-between bg-white rounded-3xl p-5 md:p-6 shadow-sm border-2 border-[#FFD966] mb-6 gap-4 relative">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-[#FF6B6B] rounded-2xl flex items-center justify-center text-4xl shadow-md animate-chef-bounce">
              👨‍🍳
            </div>
            <div>
              <h1 id="app-title" className="text-2xl sm:text-3xl font-black text-[#4A4A4A] tracking-tight">
                CHEF NUTRI-KID
              </h1>
              <p className="text-xs sm:text-sm font-bold text-[#FF6B6B] flex items-center gap-1.5">
                Powered by NutriPeds AI <span className="animate-pulse">🌟</span>
              </p>
            </div>
          </div>

          {/* Profile & Controls */}
          <div className="flex flex-col items-center sm:items-end gap-3 text-center sm:text-right">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => isPremium ? setShowProfileModal(true) : triggerPaywall('profile')}
                className={`px-4 py-2 rounded-2xl text-white font-black text-xs shadow-sm uppercase tracking-wider flex items-center gap-2 transition-colors border-2 ${isPremium ? 'bg-[#4ECDC4] hover:bg-teal-500 border-teal-600' : 'bg-slate-400 hover:bg-slate-500 border-slate-500'}`}
              >
                {isPremium ? <Users className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                {isPremium
                  ? (activeProfile
                    ? `${activeProfile.name} · ${activeProfile.ageDisplay || activeProfile.age + 'y'}`
                    : 'NutriPeds Profiles')
                  : 'Profiles — Premium 🔒'}
              </button>

              {/* Plan Expiration Countdown Badge (Fix #3) */}
              {isPremium && remainingDays !== null && (
                <button
                  onClick={() => setShowRenewalModal(true)}
                  title="Days remaining in your plan"
                  className={`px-3 py-2 rounded-2xl font-black text-xs border-2 flex items-center gap-1.5 transition-colors ${
                    remainingDays <= 2 ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-600 animate-pulse'
                    : remainingDays <= 5 ? 'bg-amber-400 hover:bg-amber-500 text-white border-amber-500'
                    : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200'
                  }`}
                >
                  ⏳ {remainingDays} day{remainingDays === 1 ? '' : 's'} left
                </button>
              )}

              {/* Growth Tracker Button */}
              {isPremium && activeProfile && (
                <button
                  onClick={() => setShowGrowthTracker(true)}
                  className="px-3 py-2 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs border-2 border-emerald-600 flex items-center gap-1.5 transition-colors"
                  title="Growth Tracker"
                >
                  <TrendingUp className="w-3.5 h-3.5"/> Growth
                </button>
              )}

              {/* Daily Progress Button */}
              {isPremium && activeProfile && (
                <button
                  onClick={() => setShowDailyProgress(true)}
                  className="px-3 py-2 rounded-2xl bg-indigo-500 hover:bg-indigo-600 text-white font-black text-xs border-2 border-indigo-600 flex items-center gap-1.5 transition-colors"
                  title="Daily Caloric Progress"
                >
                  <BarChart2 className="w-3.5 h-3.5"/> Progress
                </button>
              )}

              {/* Alert Engine Button */}
              <button
                onClick={() => setShowAlertEngine(true)}
                className="relative px-3 py-2 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black text-xs border-2 border-amber-600 flex items-center gap-1.5 transition-colors"
                title="Reminders & Alerts"
              >
                <Bell className="w-3.5 h-3.5"/> Alerts
                {alertCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                    {alertCount}
                  </span>
                )}
              </button>

              {/* FIX #9: Gallery Button */}
              <button
                onClick={() => setShowGallery(true)}
                className="px-3 py-2 rounded-2xl bg-pink-500 hover:bg-pink-600 text-white font-black text-xs border-2 border-pink-600 flex items-center gap-1.5 transition-colors"
                title="Moments Gallery"
              >
                <ImageIcon className="w-3.5 h-3.5"/> Gallery
              </button>
            </div>
            
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <Leaf className="w-4 h-4 text-emerald-500" />
              {activeProfile ? (
                 <span className="bg-transparent text-sm font-bold text-emerald-700 outline-hidden tracking-wide">{activeProfile.foodCategories}</span>
              ) : (
                <select
                  value={diet}
                  onChange={(e) => setDiet(e.target.value as DietaryPreference)}
                  className="bg-transparent text-sm font-bold text-emerald-700 outline-hidden cursor-pointer"
                >
                  {['Any / No Restriction', 'Vegetarian', 'Non-Vegetarian', 'Vegan', 'Eggetarian', 'Jain'].map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              )}
            </div>
            
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <Globe className="w-4 h-4 text-slate-500" />
              <select
                value={language}
                onChange={(e) => handleLanguageChange(e.target.value)}
                className="bg-transparent text-sm font-bold text-slate-600 outline-hidden cursor-pointer"
              >
                {["English", "Gujarati", "Hindi", "Español", "Français", "Deutsch", "Italiano", "Português"].map(lang => (
                  <option key={lang} value={lang}>{lang}</option>
                ))}
              </select>
            </div>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs px-3 py-1.5 rounded-2xl border border-red-200 transition-colors"
            >
              Sign Out
            </button>
          </div>
        </header>

        {/* Navigation Tabs */}
        {!recipe && !healthReport && (
          <div className="print:hidden mb-6 sm:mb-8">
            {/* Mobile: full width stacked tabs */}
            <div className="flex bg-white border-2 border-slate-200 shadow-sm rounded-2xl p-1 gap-1">
              <button
                onClick={() => setActiveTab('pantry')}
                className={`flex-1 py-3 px-2 sm:px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all min-h-[48px] ${
                  activeTab === 'pantry' ? 'bg-[#FF6B6B] text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Utensils className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
                <span className="hidden xs:inline sm:inline">Pantry</span>
                <span className="sm:hidden">Chef</span>
              </button>
              <button
                onClick={() => isPremium ? setActiveTab('weekly') : triggerPaywall('weekly')}
                className={`flex-1 py-3 px-2 sm:px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all min-h-[48px] relative ${
                  activeTab === 'weekly' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {isPremium ? <CalendarIcon className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /> : <Lock className="w-3.5 h-3.5 shrink-0" />}
                <span>Weekly</span>
                {!isPremium && <span className="hidden sm:inline text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-black">PRO</span>}
              </button>
              <button
                onClick={() => isPremium ? setActiveTab('box') : triggerPaywall('save')}
                className={`flex-1 py-3 px-2 sm:px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all min-h-[48px] ${
                  activeTab === 'box' ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {isPremium ? <Book className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /> : <Lock className="w-3.5 h-3.5 shrink-0" />}
                <span>Recipes</span>
                {!isPremium && <span className="hidden sm:inline text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-black">PRO</span>}
              </button>
            </div>
          </div>
        )}

        {/* Error Notification Banner */}
        {error && (
          <div className="mb-6 p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl flex items-start gap-3 text-rose-800 shadow-sm">
            <ShieldAlert className="w-6 h-6 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm">A Little Kitchen Spill Occurred!</h4>
              <p className="text-xs text-rose-700 mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* Main Interface Arena */}
        {healthReport ? (
           <div id="health-report-pdf-container" className="space-y-6 bg-white p-4 sm:p-6 rounded-3xl">
              <div className="flex justify-between items-center bg-indigo-50 rounded-2xl p-4 border border-indigo-200">
                <h2 className="text-xl font-black text-indigo-900 flex items-center gap-2">
                  <Activity className="w-6 h-6 text-indigo-500" /> NutriPeds Clinical Report: {healthReport.childName}
                </h2>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => downloadAsPDF('health-report-pdf-container', 'health-report.pdf')} 
                    className="print:hidden px-4 py-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 transition-colors border border-indigo-200"
                  >
                    <Download className="w-4 h-4" /> Download PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => setHealthReport(null)}
                    className="print:hidden px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm border border-slate-350 shadow-xs flex items-center gap-2 transition-all"
                  >
                    <ArrowLeft className="w-4 h-4" /> Go back
                  </button>
                </div>
              </div>

              {healthReport.medicalDisclaimer && (
                <div className="bg-yellow-50 p-4 border-l-4 border-yellow-400 rounded-r-xl">
                  <p className="text-xs font-bold text-yellow-800 uppercase tracking-widest mb-1">MANDATORY MEDICAL DISCLAIMER</p>
                  <p className="text-xs text-yellow-900 font-medium">{healthReport.medicalDisclaimer}</p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-3xl border-2 border-slate-200 shadow-sm">
                  <h3 className="text-slate-800 font-black text-lg mb-3">Health Summary</h3>
                  <p className="text-slate-600 text-sm font-medium leading-relaxed">{healthReport.healthSummary}</p>
                </div>
                
                <div className="bg-indigo-50 p-6 rounded-3xl border-2 border-indigo-200 shadow-sm relative overflow-hidden">
                  <Activity className="w-24 h-24 text-indigo-200 absolute -right-4 -bottom-4 opacity-30" />
                  <h3 className="text-indigo-900 font-black text-lg mb-3">Growth Chart Analysis</h3>
                  <p className="text-indigo-800 text-sm font-medium leading-relaxed">{healthReport.growthChartAnalysis}</p>
                </div>

                <div className="bg-emerald-50 p-6 rounded-3xl border-2 border-emerald-200 shadow-sm md:col-span-2">
                  <h3 className="text-emerald-900 font-black text-lg mb-4 flex items-center gap-2">
                    <Utensils className="w-5 h-5 text-emerald-500" /> The "Proactive Plate" Strategy
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {healthReport.proactivePlateStrategy.map((strategy, i) => (
                      <div key={i} className="bg-white p-4 rounded-xl border border-emerald-100 shadow-sm">
                        <div className="bg-emerald-100 text-emerald-800 w-8 h-8 flex items-center justify-center rounded-full font-black mb-3">{i + 1}</div>
                        <p className="text-xs font-bold text-slate-700 leading-snug">{strategy}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {healthReport.allergySafetyShield && (
                  <div className="bg-rose-50 p-6 rounded-3xl border-2 border-rose-300 shadow-sm md:col-span-2">
                    <h3 className="text-rose-900 font-black text-lg mb-3 flex items-center gap-2">
                      <ShieldAlert className="w-5 h-5 text-rose-500" /> Allergy Safety Shield
                    </h3>
                    <p className="text-rose-800 text-sm font-bold bg-white p-4 rounded-xl border border-rose-200 shadow-xs">
                      {healthReport.allergySafetyShield}
                    </p>
                  </div>
                )}
                
                <div className="bg-[#FFFBEB] p-6 rounded-3xl border-2 border-[#FFD93D] shadow-sm md:col-span-2">
                  <h3 className="text-[#A35D36] font-black text-lg mb-3">Milestone & Energy Tracker</h3>
                  <p className="text-[#854d0e] text-sm font-bold leading-relaxed">{healthReport.milestoneTracker}</p>
                </div>
              </div>
           </div>
        ) : !recipe ? (
          /* View A: Selector Views */
          <div className="space-y-6">
            {activeTab === 'weekly' ? (
              <WeeklyPlanner
                language={language}
                diet={activeProfile ? activeProfile.foodCategories : diet}
                childProfile={activeProfile}
                allProfiles={profiles}
                onSaveRecipe={(name, meal) => {
                  // Preserve the ENTIRE structured object so Recipe Box shows step-by-step
                  const m = meal || {};
                  const recipeToSave = {
                    mealName: name,
                    dietIndicator: m.dietIndicator || activeProfile?.foodCategories || diet,
                    plateBreakdown: m.plateBreakdown || { fruitsVeggies: 'Vegetables and fruits', wholeGrains: 'Whole grains', strongProtein: 'Protein source', fatsHydrates: 'Healthy fats' },
                    instructions: Array.isArray(m.steps) && m.steps.length ? m.steps
                                : Array.isArray(m.instructions) && m.instructions.length ? m.instructions
                                : [m.meal || name],
                    juniorDuties: Array.isArray(m.juniorDuties) ? m.juniorDuties
                                : m.kidTask ? String(m.kidTask).split(' · ')
                                : ['Help prepare this meal! 🍳'],
                    powerMealFact: m.powerFact || m.powerMealFact || 'Nutritious meal from your weekly plan! 🌟',
                    moveChallenge: m.moveChallenge || 'Stay active after eating! 🏃',
                    tutorialQuery: m.tutorialQuery || name + ' healthy recipe for kids',
                    nutrition: m.nutrition && m.nutrition.calories
                      ? { calories: m.nutrition.calories, protein: m.nutrition.protein || m.nutrition.pro || '10g', carbs: m.nutrition.carbs || '30g', fat: m.nutrition.fat || '8g', fiber: m.nutrition.fiber || '4g', keyVitamins: m.nutrition.keyVitamins || 'Various' }
                      : { calories: 250, protein: '10g', carbs: '30g', fat: '8g', fiber: '4g', keyVitamins: 'Various' },
                  } as any;
                  if (savedRecipes.some(r => r.mealName === name)) {
                    setSavedRecipes(savedRecipes.map(r => r.mealName === name ? { ...r, ...recipeToSave } : r));
                  } else {
                    setSavedRecipes([...savedRecipes, recipeToSave]);
                  }

                }}
                isPremium={isPremium}
              />
            ) : activeTab === 'box' ? (
              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-emerald-100 min-h-[400px]">
                 <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2 mb-6 uppercase">
                   <Book className="w-6 h-6 text-emerald-500" /> Saved NutriPeds Recipes
                 </h2>
                 {savedRecipes.length === 0 ? (
                   <div className="text-center p-8 bg-emerald-50 rounded-2xl border-2 border-dashed border-emerald-200 flex flex-col items-center justify-center">
                     <Book className="w-12 h-12 text-emerald-300 mb-3" />
                     <p className="text-emerald-800 font-bold">Your Recipe Box is empty!</p>
                     <p className="text-emerald-600 text-sm mt-1">Generate recipes in the Pantry Chef and save your favorites here.</p>
                     <button onClick={() => setActiveTab('pantry')} className="mt-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-sm transition-colors text-sm">
                       Go back to Pantry Chef
                     </button>
                   </div>
                 ) : (
                   <div className="space-y-4">
                     {savedRecipes.map((r, i) => {
                       const isExpanded = expandedBoxIdx === i;
                       return (
                       <div key={i} className="bg-slate-50 border-2 border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:border-emerald-300 transition-all">
                         {/* Card header — click to expand */}
                         <div className="p-5 cursor-pointer" onClick={() => setExpandedBoxIdx(isExpanded ? null : i)}>
                           <div className="flex items-start justify-between gap-3">
                             <div className="flex-1 min-w-0">
                               <p className="text-[10px] uppercase font-extrabold tracking-widest text-[#A35D36] mb-1">
                                 ✨ {r.dietIndicator}{(r as any).optimizationGoal ? ` · 🎯 ${(r as any).optimizationGoal}` : ''}
                               </p>
                               <h3 className="text-lg font-black text-[#7D4427] leading-tight mb-2">{r.mealName}</h3>
                               <div className="flex flex-wrap gap-1">
                                 <span className="text-[10px] font-bold bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full">{r.nutrition?.calories} kcal</span>
                                 <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">{r.nutrition?.protein} prot</span>
                                 {r.nutrition?.fiber && <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">{r.nutrition.fiber} fiber</span>}
                               </div>
                             </div>
                             <button className="shrink-0 flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200 min-h-[40px]">
                               {isExpanded ? <>Hide <ChevronRight className="w-3.5 h-3.5 rotate-90"/></> : <><BookOpen className="w-3.5 h-3.5"/> View</>}
                             </button>
                           </div>
                         </div>

                         {/* Expanded step-by-step content */}
                         {isExpanded && (
                           <div className="px-5 pb-5 space-y-4 border-t border-slate-200 pt-4">
                             {/* Plate breakdown */}
                             {r.plateBreakdown && (
                               <div className="grid grid-cols-2 gap-2">
                                 {[
                                   ['🥦 Veggies/Fruits', r.plateBreakdown.fruitsVeggies],
                                   ['🌾 Whole Grains', r.plateBreakdown.wholeGrains],
                                   ['💪 Protein', r.plateBreakdown.strongProtein],
                                   ['🫗 Fats/Hydrates', r.plateBreakdown.fatsHydrates],
                                 ].map(([label, val]) => val ? (
                                   <div key={label as string} className="bg-white rounded-xl p-2.5 border border-slate-100">
                                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-wide">{label}</p>
                                     <p className="text-xs text-slate-700 font-semibold mt-0.5">{val}</p>
                                   </div>
                                 ) : null)}
                               </div>
                             )}

                             {/* Step-by-step instructions */}
                             {Array.isArray(r.instructions) && r.instructions.length > 0 && (
                               <div>
                                 <div className="flex items-center justify-between mb-2">
                                   <p className="text-xs font-black text-slate-500 uppercase tracking-wide">📖 Preparation Steps</p>
                                   <button
                                     onClick={() => handleReadAloud(`${r.mealName}. Steps: ${r.instructions.join('. ')}`)}
                                     className="flex items-center gap-1 text-[10px] font-bold text-[#4ECDC4] hover:text-teal-700">
                                     <Volume2 className="w-3 h-3"/> Read Aloud
                                   </button>
                                 </div>
                                 <div className="space-y-2">
                                   {r.instructions.flatMap((step: string) => String(step).split('\n')).filter(Boolean).map((step: string, si: number) => (
                                     <div key={si} className="flex items-start gap-2.5">
                                       <span className="w-5 h-5 bg-[#FF6B6B] text-white rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5">{si+1}</span>
                                       <p className="text-sm text-slate-600 font-semibold leading-snug">{step}</p>
                                     </div>
                                   ))}
                                 </div>
                               </div>
                             )}

                             {/* Junior chef tasks */}
                             {Array.isArray(r.juniorDuties) && r.juniorDuties.length > 0 && (
                               <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-3">
                                 <p className="text-xs font-black text-yellow-700 mb-1.5">👶 Junior Chef Tasks</p>
                                 <ul className="space-y-1">
                                   {r.juniorDuties.map((task: string, ti: number) => (
                                     <li key={ti} className="text-xs text-yellow-600 font-semibold flex items-start gap-1.5">
                                       <span className="shrink-0">✓</span>{task}
                                     </li>
                                   ))}
                                 </ul>
                               </div>
                             )}

                             {/* Power fact */}
                             {r.powerMealFact && (
                               <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3">
                                 <p className="text-xs font-black text-emerald-700 mb-1">💡 Power Fact</p>
                                 <p className="text-xs text-emerald-600 font-semibold">{r.powerMealFact}</p>
                               </div>
                             )}

                             {/* Actions */}
                             <div className="flex gap-2 pt-1">
                               <button onClick={() => { setRecipe(r); setActiveTab('pantry'); }}
                                 className="flex-1 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs rounded-xl min-h-[44px]">
                                 Open Full View
                               </button>
                               <button onClick={() => { setSavedRecipes(savedRecipes.filter((_, index) => index !== i)); setExpandedBoxIdx(null); }}
                                 className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl border border-rose-200 min-h-[44px]">
                                 Remove
                               </button>
                             </div>
                           </div>
                         )}
                       </div>
                       );
                     })}
                   </div>
                 )}
              </div>
            ) : isLoading ? (
              /* Loading State Screen with rotating tips */
              <div className="bg-white rounded-3xl p-12 text-center border-4 border-[#FF6B6B] shadow-xl max-w-2xl mx-auto my-12 animate-pulse">
                <div className="text-6xl mb-6">🌋</div>
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-[#4ECDC4] mb-4"></div>
                <h3 className="text-2xl font-black text-slate-705">Mixing in Chef Nutri-Kid's Blender...</h3>
                
                <div className="mt-6 p-4 bg-amber-50 rounded-2xl border border-amber-200">
                  <p className="text-[#A35D36] font-bold text-md italic animate-bounce">
                    "{loadingTips[loadingTipIndex]}"
                  </p>
                </div>
                
                <p className="text-slate-400 text-xs mt-6">
                  Applying clinical nutrient ratios using Gemini AI for kid goodness...
                </p>
              </div>
            ) : recipeOptions ? (
              /* Display Recipe Options */
              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-indigo-100 min-h-[400px]">
                 <div className="flex justify-between items-center mb-6">
                   <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2 uppercase">
                     <Sparkles className="w-6 h-6 text-amber-500" /> Chef Nutri-Kid's Options
                   </h2>
                   <button
                     onClick={() => setRecipeOptions(null)}
                     className="px-4 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold text-xs sm:text-sm border border-slate-200 transition-colors"
                   >
                     Back to Pantry
                   </button>
                 </div>
                 <p className="text-slate-600 mb-6 font-medium">Select your favorite recipe option below to see full details!</p>
                 {recipeFallbackNote && (
                   <div className="mb-6 bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 flex items-start gap-3">
                     <span className="text-2xl shrink-0">⚠️</span>
                     <div>
                       <p className="text-sm font-bold text-amber-800">{recipeFallbackNote}</p>
                       <button
                         onClick={() => { setRecipeOptions(null); setRecipeFallbackNote(null); handleGenerateRecipe(); }}
                         className="mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-black text-xs rounded-xl min-h-[40px]"
                       >
                         🔄 Try Again for Full Recipe
                       </button>
                     </div>
                   </div>
                 )}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {recipeOptions.map((opt, i) => (
                     <div key={i} className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all cursor-pointer group flex flex-col justify-between" onClick={() => { setRecipe(opt); setRecipeOptions(null); }}>
                       <div>
                         <p className="text-xs uppercase font-extrabold tracking-widest text-[#A35D36] mb-2">
                           ✨ Option {i + 1} | {opt.dietIndicator}
                         </p>
                         <h3 className="text-xl font-black text-indigo-900 leading-tight mb-4">{opt.mealName}</h3>
                         {opt.nutritionalFocus && (
                           <p className="text-sm font-medium text-slate-600 mb-4 bg-indigo-50 p-3 rounded-xl line-clamp-3">
                             {opt.nutritionalFocus}
                           </p>
                         )}
                         <div className="flex flex-wrap gap-2 mb-4">
                            <span className="text-xs font-bold bg-sky-100 text-sky-800 px-3 py-1 rounded-full">{opt.nutrition.calories} kcal</span>
                            <span className="text-xs font-bold bg-rose-100 text-rose-800 px-3 py-1 rounded-full">{opt.nutrition.protein} prot</span>
                         </div>
                       </div>
                       <button className="mt-4 w-full py-2 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-xl shadow-sm transition-colors text-sm">
                         View Full Recipe
                       </button>
                     </div>
                   ))}
                 </div>
              </div>
            ) : (
              /* Ready to pick ingredients */
              <div className="space-y-4">
                {/* Choose-a-child prompt: premium parent must pick a child first */}
                {isPremium && profiles.length >= 1 && !activeProfile && (
                  <div className="bg-gradient-to-r from-teal-50 to-cyan-50 border-2 border-teal-400 rounded-2xl p-4 shadow-sm">
                    <p className="font-black text-teal-700 text-sm mb-1">👶 Who is this recipe for? (required)</p>
                    <p className="text-xs text-teal-600 mb-3">Pick a child so the recipe matches their exact age, diet and allergies.</p>
                    <div className="flex flex-wrap gap-2">
                      {profiles.map(c => (
                        <button
                          key={c.id}
                          onClick={() => { setActiveProfileId(c.id); setError(null); }}
                          className="flex items-center gap-2 bg-white border-2 border-teal-200 hover:border-teal-400 rounded-xl px-3 py-2 font-bold text-sm text-slate-700 transition-all min-h-[48px]"
                        >
                          <span className="w-7 h-7 rounded-full bg-gradient-to-br from-amber-300 to-orange-400 flex items-center justify-center text-white font-black text-xs overflow-hidden">
                            {(c as any).photo ? <img src={(c as any).photo} alt={c.name} className="w-full h-full object-cover"/> : (c.gender === 'Girl' ? '👧' : '👦')}
                          </span>
                          {c.name} · {c.ageDisplay || c.age + 'y'}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {/* Free trial banner */}
                {!isPremium && (
                  <div className={`flex items-center justify-between gap-3 px-5 py-3 rounded-2xl border-2 ${hasUsedFree ? 'bg-rose-50 border-rose-300' : 'bg-amber-50 border-[#FFD93D]'}`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{hasUsedFree ? '🔒' : '🎁'}</span>
                      <div>
                        <p className="font-black text-sm text-slate-800">
                          {hasUsedFree ? 'Free trial used!' : '1 Free Recipe Generation Available'}
                        </p>
                        <p className="text-xs text-slate-500">
                          {hasUsedFree
                            ? 'Upgrade to a plan to generate unlimited recipes & unlock all features.'
                            : 'Try Chef Nutri-Kid once for free. Upgrade to unlock unlimited generations + all features!'}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => triggerPaywall('generate')}
                      className="shrink-0 px-4 py-2 bg-[#FF6B6B] text-white text-xs font-black rounded-xl hover:bg-red-500 transition-colors"
                    >
                      {hasUsedFree ? 'Upgrade →' : 'See Plans'}
                    </button>
                  </div>
                )}

                {/* Optimization Goal Selector */}
                {isPremium && (
                  <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-2xl p-4">
                    <p className="text-xs font-black text-purple-700 uppercase tracking-wide mb-2">🎯 Recipe Optimization Goal</p>
                    <div className="flex flex-wrap gap-2">
                      {(['', 'Boost Immunity', 'Enhance Weight Gain', 'Maximize Iron', 'Brain Development', 'Bone Strength', 'Balanced Growth'] as const).map(goal => (
                        <button
                          key={goal}
                          onClick={() => setOptimizationGoal(goal as OptimizationGoal | '')}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border-2 ${
                            optimizationGoal === goal
                              ? 'bg-purple-500 text-white border-purple-600'
                              : 'bg-white text-purple-600 border-purple-200 hover:border-purple-400'
                          }`}
                        >
                          {goal === '' ? '⚖️ Auto' : 
                           goal === 'Boost Immunity' ? '🛡️ ' + goal :
                           goal === 'Enhance Weight Gain' ? '💪 ' + goal :
                           goal === 'Maximize Iron' ? '🩸 ' + goal :
                           goal === 'Brain Development' ? '🧠 ' + goal :
                           goal === 'Bone Strength' ? '🦴 ' + goal :
                           '🌱 ' + goal}
                        </button>
                      ))}
                    </div>
                    {optimizationGoal && (
                      <p className="text-xs text-purple-500 mt-2">✅ AI will optimize recipe to maximize: <strong>{optimizationGoal}</strong></p>
                    )}
                  </div>
                )}

                <IngredientSelector
                  selectedItems={selectedIngredients}
                  onChangeSelected={setSelectedIngredients}
                  onGenerate={handleGenerateRecipe}
                  isLoading={isLoading}
                  diet={activeProfile ? activeProfile.foodCategories : diet}
                  childAllergies={activeProfile?.allergies || []}
                />
              </div>
            )}
          </div>
        ) : (
          /* View B: Active Recipe Plate & Steps */
          <div className="space-y-6">

            {/* Allergy cross-check banner */}
            {activeProfile?.allergies && activeProfile.allergies.length > 0 && (() => {
              const recipeText = JSON.stringify(recipe).toLowerCase();
              const triggered = activeProfile.allergies.filter(a => {
                const al = a.toLowerCase().trim();
                return al && recipeText.includes(al);
              });
              return triggered.length > 0 ? (
                <div className="bg-red-50 border-4 border-red-400 rounded-2xl p-4 flex items-start gap-3">
                  <span className="text-3xl shrink-0">🚨</span>
                  <div>
                    <p className="font-black text-red-700 text-base">ALLERGY ALERT — Check before serving!</p>
                    <p className="text-sm text-red-600 font-semibold mt-1">
                      This recipe may contain <strong>{triggered.join(', ')}</strong>, which {activeProfile.name} is allergic to. Review the ingredients carefully or regenerate without these items.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-green-50 border-2 border-green-300 rounded-2xl px-4 py-2.5 flex items-center gap-2">
                  <span className="text-lg">✅</span>
                  <p className="text-sm text-green-700 font-bold">Allergy-safe for {activeProfile.name} — no known allergens ({activeProfile.allergies.join(', ')}) detected.</p>
                </div>
              );
            })()}

            {/* Header recipe alert with return button */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#FFE8D6] rounded-2xl p-4 border-2 border-[#FFB280]">
              <div>
                <p className="text-xs uppercase font-extrabold tracking-widest text-[#A35D36]">
                  ✨ Fresh Out of the Kitchen {recipe.dietIndicator && <span className="bg-white/50 px-2 py-0.5 rounded-full ml-2 inline-block shadow-xs border border-white/60">{recipe.dietIndicator}</span>}
                </p>
                <h2 id="recipe-meal-title" className="text-2xl font-black text-[#7D4427] leading-tight">
                  {recipe.mealName}
                </h2>
                {/* Speak Recipe Button */}
                {/* FIX #3: Play/Stop toggle for Read Aloud */}
                <button
                  type="button"
                  onClick={() => {
                    const text = `${recipe.mealName}. ${recipe.nutritionalFocus || ''}. Ingredients and steps: ${recipe.instructions?.join('. ')}. Fun fact: ${recipe.powerMealFact || ''}`;
                    handleReadAloud(text);
                  }}
                  className={`mt-2 flex items-center gap-1.5 font-bold text-xs px-3 py-1.5 rounded-full border transition-all ${isSpeaking ? 'bg-red-100 border-red-300 text-red-700 animate-pulse' : 'bg-white/70 hover:bg-white text-[#A35D36] border-[#FFB280]'}`}
                >
                  {isSpeaking ? <><VolumeX className="w-3.5 h-3.5"/> Stop Reading</> : <><Volume2 className="w-3.5 h-3.5"/> Read Aloud</>}
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!isPremium) { triggerPaywall('save'); return; }
                    const alreadySaved = savedRecipes.some(r => r.mealName === recipe.mealName);
                    if (alreadySaved) {
                       setSavedRecipes(savedRecipes.filter(r => r.mealName !== recipe.mealName));
                    } else {
                       setSavedRecipes([...savedRecipes, recipe]);
                    }
                  }}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm border shadow-xs flex items-center gap-2 transition-all ${
                    !isPremium
                      ? 'bg-slate-100 border-slate-200 text-slate-500'
                      : savedRecipes.some(r => r.mealName === recipe.mealName)
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 hover:bg-emerald-200'
                        : 'bg-white hover:bg-amber-50 text-emerald-700 border-emerald-200'
                  }`}
                >
                  {!isPremium
                    ? <><Lock className="w-4 h-4" /> Save Recipe 🔒</>
                    : savedRecipes.some(r => r.mealName === recipe.mealName)
                      ? <><Bookmark className="w-4 h-4 fill-current" /> Saved to Box</>
                      : <><BookmarkPlus className="w-4 h-4" /> Save Recipe</>
                  }
                </button>
                <button
                  id="btn-return-fridge"
                  type="button"
                  onClick={() => setRecipe(null)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm border border-slate-350 shadow-xs flex items-center gap-2 transition-all"
                >
                  <ArrowLeft className="w-4 h-4" /> Go back
                </button>
              </div>
            </div>

            {recipe.medicalDisclaimer && (
              <div className="bg-yellow-50 p-4 border-l-4 border-yellow-400 rounded-r-xl shadow-xs">
                <p className="text-xs font-bold text-yellow-800 uppercase tracking-widest mb-1">MANDATORY MEDICAL DISCLAIMER</p>
                <p className="text-xs text-yellow-900 font-medium">{recipe.medicalDisclaimer}</p>
              </div>
            )}

            {/* Main Interactive 12-Column Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Side: 5-Col Harvard Plate Visualization */}
              <div className="lg:col-span-5 flex flex-col space-y-6">
                <HarvardPlate recipe={recipe} />

                {/* Nutripeds specific facts */}
                {recipe.nutritionalFocus && (
                  <div className="bg-[#F1F8E9] p-5 rounded-3xl border-2 border-[#95CD41] shadow-sm relative overflow-hidden">
                    <span className="absolute top-2 right-2 text-3xl opacity-15">🔬</span>
                    <h5 className="text-xs font-black text-[#33691E] uppercase tracking-wider mb-2 flex items-center gap-2">
                      <Award className="w-4 h-4 text-[#33691E]" /> NUTRIPEDS COCHING FACT
                    </h5>
                    <p className="text-xs font-bold text-[#558B2F]">
                      {recipe.nutritionalFocus}
                    </p>
                  </div>
                )}
                
                {/* Serving Size */}
                {recipe.servingSize && (
                  <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl px-4 py-3 flex items-center gap-3">
                    <span className="text-2xl">🍽️</span>
                    <div>
                      <div className="font-black text-xs text-amber-800 uppercase tracking-wider">Serving Size</div>
                      <div className="text-sm text-amber-700 font-bold mt-0.5">{recipe.servingSize}</div>
                    </div>
                  </div>
                )}

                {/* Age Guidance */}
                {recipe.ageGuidance && (
                  <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl px-4 py-3 flex items-start gap-3">
                    <span className="text-2xl">👶</span>
                    <div>
                      <div className="font-black text-xs text-blue-800 uppercase tracking-wider">Age Preparation Guide</div>
                      <div className="text-sm text-blue-700 font-bold mt-0.5">{recipe.ageGuidance}</div>
                    </div>
                  </div>
                )}

                {/* Ingredients with Quantities */}
                {recipe.ingredientsWithQuantity && recipe.ingredientsWithQuantity.length > 0 && (
                  <div className="bg-green-50 border-2 border-green-200 rounded-2xl px-4 py-4">
                    <div className="font-black text-xs text-green-800 uppercase tracking-wider mb-3 flex items-center gap-2">
                      <span>🧺</span> Ingredients & Exact Quantities
                    </div>
                    <ul className="space-y-2">
                      {recipe.ingredientsWithQuantity.map((item: string, i: number) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-green-800">
                          <span className="text-green-500 font-black mt-0.5 text-base">•</span>
                          <span className="font-semibold">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {recipe.allergyCheck && (
                  <div className="bg-rose-50 p-5 rounded-3xl border-2 border-rose-300 shadow-sm relative overflow-hidden">
                    <span className="absolute top-2 right-2 text-3xl opacity-15">🛡️</span>
                    <h5 className="text-xs font-black text-rose-700 uppercase tracking-wider mb-2 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-rose-500" /> ALLERGY SAFETY SHIELD
                    </h5>
                    <p className="text-xs font-bold text-rose-800">
                      {recipe.allergyCheck}
                    </p>
                  </div>
                )}

                {/* Nutrition Breakdown */}
                {recipe.nutrition && (
                   <div className="bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-sm">
                      <h4 className="text-slate-800 font-black text-sm uppercase mb-4 flex items-center gap-2">
                        <Activity className="w-5 h-5 text-sky-500" /> Nutritional Power (Kid's Portion)
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-sky-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-2xl font-black text-sky-600">{recipe.nutrition.calories}</span>
                           <span className="text-[10px] font-bold text-sky-800 uppercase">Calories 🔥</span>
                        </div>
                        <div className="bg-rose-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-rose-600">{recipe.nutrition.protein}</span>
                           <span className="text-[10px] font-bold text-rose-800 uppercase">Protein 💪</span>
                        </div>
                        <div className="bg-amber-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-amber-600">{recipe.nutrition.carbs}</span>
                           <span className="text-[10px] font-bold text-amber-800 uppercase">Carbs ⚡</span>
                        </div>
                        <div className="bg-emerald-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-emerald-600">{recipe.nutrition.fiber}</span>
                           <span className="text-[10px] font-bold text-emerald-800 uppercase">Fiber 🌿</span>
                        </div>
                        <div className="col-span-2 bg-yellow-50 p-3 rounded-2xl text-center flex items-center justify-center gap-2">
                           <span className="text-xs font-black text-yellow-800">Key Vitamins: 🌟 {recipe.nutrition.keyVitamins}</span>
                        </div>
                      </div>
                   </div>
                )}
              </div>

              {/* Right Side: 7-Col Instructions, Tasks, Move Challenge */}
              <div className="lg:col-span-7 flex flex-col space-y-6">
                
                {/* Steps Section */}
                <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-gray-100 flex-1">
                  <h3 className="text-[#4A4A4A] font-black text-xl mb-6 flex items-center gap-2">
                    <Utensils className="w-6 h-6 text-[#FF6B6B]" /> 👩‍🍳 EASY STEP-BY-STEP RECIPE
                  </h3>

                  <div className="space-y-5">
                    {recipe.instructions.map((step, idx) => (
                      <div key={idx} className="flex space-x-4 items-start group">
                        <div className="font-black text-2xl text-[#4ECDC4] opacity-50 select-none mt-0.5">
                          {String(idx + 1).padStart(2, '0')}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm sm:text-base text-slate-700 leading-relaxed font-medium">
                            {step}
                          </p>
                          <button
                            onClick={() => handleReadAloud(`Step ${idx + 1}: ${step}`)}
                            className="mt-1.5 flex items-center gap-1 text-[10px] font-bold text-[#4ECDC4] hover:text-teal-700 opacity-0 group-hover:opacity-100 transition-all"
                          >
                            <Volume2 className="w-3 h-3"/> Read this step
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Junior Assistant Tasks Section */}
                  <div className="mt-8 bg-[#E0F7FA] border-2 border-[#4ECDC4] rounded-2xl p-5 md:p-6">
                    <h4 className="text-[#00838F] font-black text-sm uppercase tracking-widest mb-3 flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-[#00838F]" /> 🧑‍🍳 JUNIOR CHEF SAFE TASKS
                    </h4>
                    <p className="text-xs text-slate-500 mb-4 font-semibold">
                      Hey there kiddo! Tap and check off your kitchen chores to finish this dish safely:
                    </p>

                    <div className="space-y-2.5">
                      {recipe.juniorDuties.map((task, idx) => {
                        const isDone = completedTasks.includes(task);
                        return (
                          <div
                            key={idx}
                            id={`junior-task-box-${idx}`}
                            onClick={() => toggleTask(task)}
                            className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                              isDone
                                ? 'bg-teal-50 border-teal-300 text-teal-800 line-through opacity-85'
                                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}} // toggled via parent div click
                              className="accent-teal-600 h-4 w-4 rounded-md pointer-events-none"
                            />
                            <span className="text-xs sm:text-sm font-bold leading-tight">
                              {task}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {completedTasks.length === recipe.juniorDuties.length && (
                      <div className="mt-4 p-3 bg-teal-100 rounded-xl text-teal-900 border border-teal-400 text-center animate-bounce text-xs font-extrabold flex items-center justify-center gap-2">
                        🌟 Double High Five! Junior Chef Assistant Complete! 🥳
                      </div>
                    )}
                  </div>
                </div>

                {/* Upload Photos Section */}
                <div className="bg-white rounded-3xl p-6 border-2 border-indigo-100 shadow-sm">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
                    <h4 className="text-indigo-800 font-black text-sm uppercase flex items-center gap-2">
                      <Upload className="w-5 h-5 text-indigo-500" /> Share Your Masterpiece! 📸
                    </h4>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-colors border border-indigo-200 shadow-sm"
                    >
                      Upload Photo
                    </button>
                    <input 
                      type="file" 
                      accept="image/*" 
                      multiple
                      className="hidden" 
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                    />
                  </div>
                  {uploadedPhotos.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                      {uploadedPhotos.map((photo, i) => (
                        <div key={i} className="aspect-square rounded-2xl overflow-hidden border-2 border-indigo-200 shadow-sm group relative">
                          <img src={photo} alt="Uploaded meal" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                          <button 
                            onClick={() => setUploadedPhotos(prev => prev.filter((_, index) => index !== i))}
                            className="absolute top-1 right-1 bg-white/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                           <Trash2 className="w-3 h-3 text-rose-500" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-indigo-200 rounded-2xl p-6 text-center bg-indigo-50/50">
                       <p className="text-indigo-400 font-medium text-xs sm:text-sm">No photos yet! Upload your plate here when finished so we can celebrate! 🎉</p>
                    </div>
                  )}
                </div>

                {/* Row Grid: Move Challenge & Scientific Fact */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Why this is powerful card */}
                  <div className="bg-[#FFE8D6] p-5 rounded-3xl border-2 border-[#FFB280] flex flex-col justify-between">
                    <div>
                      <h5 className="text-[10px] font-black text-[#A35D36] uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        💡 WHY IT'S A POWER MEAL
                      </h5>
                      <p className="text-xs sm:text-sm font-bold text-[#7D4427] italic leading-relaxed">
                        "{recipe.powerMealFact}"
                      </p>
                    </div>
                    <div className="mt-4 text-xs text-[#A35D36] font-semibold flex items-center gap-1.5">
                      💪 Nutrition Science for Kids!
                    </div>
                  </div>

                  {/* Move Challenge Card */}
                  <div className={`p-5 rounded-3xl border-2 flex flex-col justify-between transition-all ${
                    moveChallengeDone 
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800' 
                      : 'bg-[#FFFBEB] border-[#FFD93D] text-[#854d0e]'
                  }`}>
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
                          🏃‍♂️ MOVE CHALLENGE!
                        </h5>
                        {moveChallengeDone && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                            COMPLETED ⭐
                          </span>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm font-bold leading-relaxed">
                        {recipe.moveChallenge}
                      </p>
                    </div>

                    <div className="mt-4 pt-2">
                      {moveChallengeDone ? (
                        <p className="text-xs font-black text-emerald-700 italic flex items-center gap-1">
                          🎉 Engines fired up & ready to digest!
                        </p>
                      ) : (
                        <button
                          id="btn-complete-challenge"
                          onClick={handleCompleteMoveChallenge}
                          className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-xl shadow-xs transition-transform hover:scale-102 flex items-center justify-center gap-1.5"
                        >
                          🦖 Done the Challenge!
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Move challenge confetti simulation banner */}
                {showMoveConfetti && (
                  <div className="p-3 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-2xl text-[#7D4427] font-black text-xs text-center border-2 border-yellow-400 animate-bounce">
                    ✨ Sparkle Power Activators Online! You stomped like a real dinosaur! 🦖✨ Let's enjoy!
                  </div>
                )}

              </div>
            </div>

            {/* Bottom Navigation & Youtube assistant */}
            <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 mt-6 text-white shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                 <div className="bg-red-500 rounded-full p-3 shadow-lg shrink-0">
                   <PlayCircle className="w-8 h-8 text-white" />
                 </div>
                 <div className="text-center sm:text-left">
                    <h4 className="font-black text-lg text-white flex items-center justify-center sm:justify-start gap-2">Watch a Video Guide! 📺</h4>
                    <p className="text-slate-400 text-sm mt-1 mb-3">Check out this search to see parents making something similar.</p>
                    <div className="bg-slate-800 p-3 rounded-xl border border-slate-700 inline-flex flex-col sm:flex-row items-center gap-3 w-full">
                       <code className="text-yellow-400 font-mono font-bold text-xs select-all text-center sm:text-left break-all">"{recipe.tutorialQuery}"</code>
                       <a href={`https://www.youtube.com/results?search_query=${encodeURIComponent(recipe.tutorialQuery)}`} target="_blank" rel="noopener noreferrer" className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 text-xs font-bold rounded-lg transition-colors shrink-0 whitespace-nowrap">
                         Search YouTube
                       </a>
                    </div>
                 </div>
              </div>

              <button
                onClick={() => setRecipe(null)}
                className="w-full lg:w-auto px-8 py-4 bg-white hover:bg-slate-100 text-slate-900 font-black text-sm rounded-xl shadow-md transition-all shrink-0"
              >
                🌿 Return to Pantry
              </button>
            </div>

          </div>
        )}

        {/* Global Footer Details */}
        <footer className="mt-12 flex flex-col sm:flex-row items-center justify-between text-slate-400 px-4 py-6 border-t border-slate-200/60 text-center gap-2">
          <p className="text-[10px] sm:text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
            🍎 Based on the Harvard Kid’s Healthy Eating Plate Model
          </p>
          <p className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-400">
            © 2026 Chef Nutri-Kid • Hand-prepared with Clinical Culinary Love
          </p>
        </footer>

      </div>
    </div>
  );
}
