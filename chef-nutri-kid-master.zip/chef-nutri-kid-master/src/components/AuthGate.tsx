import React, { useState } from 'react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth } from '../firebase';

export default function AuthGate() {
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>('signin');

  const [name,     setName]     = useState('');
  const [email,    setEmail]    = useState('');
  const [phone,    setPhone]    = useState('');
  const [password, setPassword] = useState('');
  const [confirm,  setConfirm]  = useState('');

  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [notice,  setNotice]  = useState('');

  const clear = () => { setError(''); setNotice(''); };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    clear();
    if (!email || !password) { setError('Please enter your email and password.'); return; }
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
      // onAuthStateChanged in App.tsx takes over from here
    } catch (err: any) {
      setError(friendlyError(err.code));
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    clear();
    if (!name.trim())               { setError('Please enter your full name.');          return; }
    if (!email.includes('@'))       { setError('Please enter a valid email address.');   return; }
    if (password.length < 6)        { setError('Password must be at least 6 characters.'); return; }
    if (password !== confirm)       { setError('Passwords do not match.');               return; }
    setLoading(true);
    try {
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      // App.tsx onAuthStateChanged fires → user lands in the app
      // Name & phone are saved to Firestore in Step 4; stored locally for now
      if (name)  localStorage.setItem('cnk_signup_name',  name.trim());
      if (phone) localStorage.setItem('cnk_signup_phone', phone.trim());
    } catch (err: any) {
      setError(friendlyError(err.code));
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    clear();
    if (!email.includes('@')) { setError('Please enter your email address.'); return; }
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setNotice('Password reset email sent! Check your inbox.');
    } catch (err: any) {
      setError(friendlyError(err.code));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FFFDF0] flex items-center justify-center p-4">
      {/* Top colour ribbon */}
      <div className="fixed top-0 left-0 right-0 h-3 bg-gradient-to-r from-[#FF6B6B] via-[#FFD93D] to-[#4ECDC4] z-50" />

      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-[#FF6B6B] rounded-3xl flex items-center justify-center text-5xl shadow-lg mx-auto mb-3">
            👨‍🍳
          </div>
          <h1 className="text-2xl font-black text-[#4A4A4A]">CHEF NUTRI-KID</h1>
          <p className="text-xs font-bold text-[#FF6B6B] mt-0.5">Powered by NutriPeds AI 🌟</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border-2 border-[#FFD966] p-7">

          {/* ── SIGN IN ── */}
          {mode === 'signin' && (
            <>
              <h2 className="text-lg font-black text-slate-800 mb-1">Welcome back! 👋</h2>
              <p className="text-xs text-slate-500 mb-5">Sign in to access your child's nutrition plans.</p>
              <form onSubmit={handleSignIn} className="space-y-3">
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Email</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="you@email.com" autoComplete="email"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Password</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••" autoComplete="current-password"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                {error  && <p className="text-xs text-red-500 font-bold bg-red-50 p-2.5 rounded-xl">{error}</p>}
                {notice && <p className="text-xs text-teal-600 font-bold bg-teal-50 p-2.5 rounded-xl">{notice}</p>}
                <button type="submit" disabled={loading}
                  className="w-full py-3 bg-[#FF6B6B] text-white rounded-2xl font-black text-sm hover:bg-red-500 disabled:opacity-60 transition-colors">
                  {loading ? 'Signing in…' : '🔓 Sign In'}
                </button>
              </form>
              <div className="mt-4 space-y-2 text-center">
                <button onClick={() => { setMode('reset'); clear(); }}
                  className="text-xs text-slate-400 hover:text-slate-600 font-semibold block w-full">
                  Forgot password?
                </button>
                <p className="text-xs text-slate-500">
                  New here?{' '}
                  <button onClick={() => { setMode('signup'); clear(); }}
                    className="text-[#FF6B6B] font-black hover:underline">
                    Create an account →
                  </button>
                </p>
              </div>
            </>
          )}

          {/* ── SIGN UP ── */}
          {mode === 'signup' && (
            <>
              <h2 className="text-lg font-black text-slate-800 mb-1">Create your account 🌟</h2>
              <p className="text-xs text-slate-500 mb-5">One account for all your children's nutrition plans.</p>
              <form onSubmit={handleSignUp} className="space-y-3">
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Full Name *</label>
                  <input type="text" value={name} onChange={e => setName(e.target.value)}
                    placeholder="e.g. Priya Sharma" autoComplete="name"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Email *</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="you@email.com" autoComplete="email"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">WhatsApp Number</label>
                  <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                    placeholder="9876543210" autoComplete="tel"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Password * (min 6 characters)</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••" autoComplete="new-password"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Confirm Password *</label>
                  <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)}
                    placeholder="••••••••" autoComplete="new-password"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                {error && <p className="text-xs text-red-500 font-bold bg-red-50 p-2.5 rounded-xl">{error}</p>}
                <button type="submit" disabled={loading}
                  className="w-full py-3 bg-[#4ECDC4] text-white rounded-2xl font-black text-sm hover:bg-teal-500 disabled:opacity-60 transition-colors">
                  {loading ? 'Creating account…' : '✅ Create Account'}
                </button>
              </form>
              <p className="text-center mt-4 text-xs text-slate-500">
                Already have an account?{' '}
                <button onClick={() => { setMode('signin'); clear(); }}
                  className="text-[#FF6B6B] font-black hover:underline">
                  Sign in →
                </button>
              </p>
            </>
          )}

          {/* ── PASSWORD RESET ── */}
          {mode === 'reset' && (
            <>
              <h2 className="text-lg font-black text-slate-800 mb-1">Reset your password 🔑</h2>
              <p className="text-xs text-slate-500 mb-5">Enter your email and we'll send a reset link.</p>
              <form onSubmit={handleReset} className="space-y-3">
                <div>
                  <label className="text-xs font-black text-slate-500 uppercase tracking-wide block mb-1">Email</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="you@email.com" autoComplete="email"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-semibold outline-none focus:border-[#4ECDC4]"/>
                </div>
                {error  && <p className="text-xs text-red-500 font-bold bg-red-50 p-2.5 rounded-xl">{error}</p>}
                {notice && <p className="text-xs text-teal-600 font-bold bg-teal-50 p-2.5 rounded-xl">{notice}</p>}
                <button type="submit" disabled={loading}
                  className="w-full py-3 bg-slate-700 text-white rounded-2xl font-black text-sm hover:bg-slate-800 disabled:opacity-60 transition-colors">
                  {loading ? 'Sending…' : '📧 Send Reset Email'}
                </button>
              </form>
              <p className="text-center mt-4 text-xs text-slate-500">
                <button onClick={() => { setMode('signin'); clear(); }}
                  className="text-[#FF6B6B] font-black hover:underline">
                  ← Back to sign in
                </button>
              </p>
            </>
          )}

        </div>

        <p className="text-center text-xs text-slate-400 mt-4">
          🔒 Your data is stored securely in the cloud and syncs across all your devices.
        </p>
      </div>
    </div>
  );
}

// ── Translate Firebase error codes into plain English ──
function friendlyError(code: string): string {
  switch (code) {
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password. Please try again.';
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Try signing in instead.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/too-many-requests':
      return 'Too many failed attempts. Please wait a few minutes and try again.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your internet connection.';
    default:
      return 'Something went wrong. Please try again.';
  }
}
