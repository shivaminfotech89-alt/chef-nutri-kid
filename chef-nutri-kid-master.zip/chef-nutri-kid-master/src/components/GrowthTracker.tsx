import React, { useState } from 'react';
import { TrendingUp, Plus, Scale, Ruler, Calendar, X, Activity } from 'lucide-react';
import { type ChildProfile, type GrowthEntry, getNutritionTargets } from '../data';

interface Props {
  profile: ChildProfile;
  onUpdate: (profile: ChildProfile) => void;
  onClose: () => void;
}

function calcBMI(weight: number, height: number): number {
  if (!height || !weight) return 0;
  const h = height / 100;
  return Math.round((weight / (h * h)) * 10) / 10;
}

function getBMIStatus(bmi: number, ageYears: number): { status: string; color: string } {
  if (bmi === 0) return { status: 'Not calculated', color: 'text-slate-400' };
  if (ageYears < 2) return { status: 'Infant — consult pediatrician', color: 'text-blue-500' };
  if (bmi < 14) return { status: '⚠️ Underweight', color: 'text-red-500' };
  if (bmi < 18) return { status: '✅ Healthy Weight', color: 'text-green-600' };
  if (bmi < 22) return { status: '⚠️ Overweight', color: 'text-amber-500' };
  return { status: '❗ Obese — consult doctor', color: 'text-red-600' };
}

export default function GrowthTracker({ profile, onUpdate, onClose }: Props) {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [notes, setNotes] = useState('');
  const [saved, setSaved] = useState(false);

  const targets = getNutritionTargets(profile.age);
  const history = profile.growthHistory || [];
  const latest = history[history.length - 1];
  const bmi = calcBMI(parseFloat(weight) || profile.weight, parseFloat(height) || profile.height || 0);
  const bmiStatus = getBMIStatus(bmi, profile.age);

  const addEntry = () => {
    if (!weight) return;
    const entry: GrowthEntry = {
      date: new Date().toISOString().split('T')[0],
      weight: parseFloat(weight),
      height: parseFloat(height) || profile.height || 0,
      bmi: calcBMI(parseFloat(weight), parseFloat(height) || profile.height || 0),
      notes
    };
    const updated: ChildProfile = {
      ...profile,
      weight: parseFloat(weight),
      height: parseFloat(height) || profile.height || 0,
      growthHistory: [...history, entry],
      targetCalories: targets.calories,
      targetProtein: targets.protein,
      targetIron: targets.iron,
      targetCalcium: targets.calcium,
    };
    onUpdate(updated);
    setSaved(true);
    setWeight(''); setHeight(''); setNotes('');
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 flex items-start justify-center p-4 z-50 overflow-y-auto pt-8 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-200 w-full max-w-lg">
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-2xl flex items-center justify-center"><TrendingUp className="w-5 h-5 text-emerald-600"/></div>
            <div>
              <h2 className="text-lg font-black text-slate-800">Growth Tracker</h2>
              <p className="text-xs text-slate-400">{profile.name} · {profile.ageDisplay}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400"/></button>
        </div>

        <div className="p-5 space-y-4">
          {/* Nutrition Targets */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: 'Calories', val: targets.calories, unit: 'kcal', color: 'bg-orange-50 border-orange-200', text: 'text-orange-700' },
              { label: 'Protein', val: targets.protein + 'g', unit: '/day', color: 'bg-blue-50 border-blue-200', text: 'text-blue-700' },
              { label: 'Iron', val: targets.iron + 'mg', unit: '/day', color: 'bg-red-50 border-red-200', text: 'text-red-700' },
              { label: 'Calcium', val: targets.calcium + 'mg', unit: '/day', color: 'bg-purple-50 border-purple-200', text: 'text-purple-700' },
            ].map(t => (
              <div key={t.label} className={`${t.color} border rounded-xl p-2 text-center`}>
                <div className={`text-sm font-black ${t.text}`}>{t.val}</div>
                <div className="text-xs text-slate-500">{t.label}</div>
                <div className="text-[10px] text-slate-400">{t.unit}</div>
              </div>
            ))}
          </div>

          {/* Add new measurement */}
          <div className="bg-slate-50 rounded-2xl p-4">
            <p className="text-sm font-black text-slate-700 mb-3">📏 Add Today's Measurement</p>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Weight (kg) *</label>
                <div className="flex items-center gap-2 bg-white border-2 border-slate-200 rounded-xl px-3 py-2 focus-within:border-emerald-400">
                  <Scale className="w-4 h-4 text-slate-400"/>
                  <input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="15.5" min="1" max="80" step="0.1" className="flex-1 text-sm font-bold outline-none bg-transparent"/>
                  <span className="text-xs text-slate-400">kg</span>
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Height (cm)</label>
                <div className="flex items-center gap-2 bg-white border-2 border-slate-200 rounded-xl px-3 py-2 focus-within:border-emerald-400">
                  <Ruler className="w-4 h-4 text-slate-400"/>
                  <input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="95" min="30" max="200" step="0.5" className="flex-1 text-sm font-bold outline-none bg-transparent"/>
                  <span className="text-xs text-slate-400">cm</span>
                </div>
              </div>
            </div>
            {weight && height && (
              <div className={`text-sm font-bold mb-3 ${bmiStatus.color}`}>
                BMI: {bmi} — {bmiStatus.status}
              </div>
            )}
            <input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional notes (e.g. after illness, growth spurt...)" className="w-full text-xs bg-white border-2 border-slate-200 rounded-xl px-3 py-2 outline-none focus:border-emerald-400 mb-3"/>
            <button onClick={addEntry} disabled={!weight}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl font-black text-sm hover:opacity-90 disabled:opacity-50 transition-all">
              {saved ? '✅ Saved!' : '📊 Add Measurement'}
            </button>
          </div>

          {/* Growth History */}
          {history.length > 0 && (
            <div>
              <p className="text-sm font-black text-slate-700 mb-2">📈 Growth History ({history.length} entries)</p>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {[...history].reverse().map((entry, i) => (
                  <div key={i} className="flex items-center justify-between bg-slate-50 rounded-xl px-3 py-2">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400"/>
                      <span className="text-xs text-slate-500">{entry.date}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-slate-700">{entry.weight}kg</span>
                      {entry.height > 0 && <span className="text-xs text-slate-500">{entry.height}cm</span>}
                      {entry.bmi > 0 && <span className={`text-xs font-bold ${getBMIStatus(entry.bmi, profile.age).color}`}>BMI:{entry.bmi}</span>}
                    </div>
                  </div>
                ))}
              </div>
              {/* Simple growth trend visualization */}
              {history.length >= 2 && (
                <div className="mt-3 bg-emerald-50 border border-emerald-200 rounded-xl p-3">
                  <p className="text-xs font-bold text-emerald-700 mb-1">📊 Growth Trend</p>
                  <div className="flex items-end gap-1 h-12">
                    {history.slice(-8).map((entry, i) => {
                      const maxW = Math.max(...history.map(h => h.weight));
                      const pct = (entry.weight / maxW) * 100;
                      return (
                        <div key={i} className="flex-1 flex flex-col items-center gap-1">
                          <div className="w-full bg-emerald-400 rounded-t-sm transition-all" style={{ height: `${pct}%` }}/>
                          <span className="text-[9px] text-slate-400">{entry.date.slice(5)}</span>
                        </div>
                      );
                    })}
                  </div>
                  <p className="text-xs text-emerald-600 mt-1">
                    {history.length >= 2
                      ? `Weight change: ${(history[history.length-1].weight - history[0].weight).toFixed(1)}kg over ${history.length} measurements`
                      : ''}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
