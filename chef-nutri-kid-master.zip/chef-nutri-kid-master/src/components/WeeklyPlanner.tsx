import React, { useState, useMemo } from 'react';
import { Calendar, Download, RefreshCw, ChevronDown, BookOpen, Star, X, User, Droplets, Zap } from 'lucide-react';
import { downloadAsPDF } from '../utils';
import { WEEKLY_FALLBACK, getAgeBucket, AGE_BUCKET_META, type ChildProfile, type AgeBucket } from '../data';

// ── Nutrient targets by EXACT age ──
function exactAgeTargets(ageYears: number, ageMonths: number) {
  const exactAge = ageYears + ageMonths / 12;
  if (exactAge < 1)   return { cal: 700,  pro: 11, cal_mg: 260,  iron: 11, zinc: 3,  water: 700  };
  if (exactAge < 2)   return { cal: 900,  pro: 11, cal_mg: 500,  iron: 11, zinc: 3,  water: 800  };
  if (exactAge < 3)   return { cal: 1000, pro: 13, cal_mg: 700,  iron: 7,  zinc: 3,  water: 1000 };
  if (exactAge < 4)   return { cal: 1200, pro: 13, cal_mg: 700,  iron: 7,  zinc: 3,  water: 1100 };
  if (exactAge < 5)   return { cal: 1200, pro: 19, cal_mg: 1000, iron: 10, zinc: 5,  water: 1200 };
  if (exactAge < 6)   return { cal: 1300, pro: 19, cal_mg: 1000, iron: 10, zinc: 5,  water: 1300 };
  if (exactAge < 7)   return { cal: 1400, pro: 20, cal_mg: 1000, iron: 10, zinc: 5,  water: 1400 };
  if (exactAge < 8)   return { cal: 1400, pro: 20, cal_mg: 1000, iron: 10, zinc: 5,  water: 1500 };
  if (exactAge < 9)   return { cal: 1600, pro: 25, cal_mg: 1300, iron: 10, zinc: 8,  water: 1600 };
  if (exactAge < 10)  return { cal: 1700, pro: 28, cal_mg: 1300, iron: 10, zinc: 8,  water: 1700 };
  if (exactAge < 11)  return { cal: 1800, pro: 31, cal_mg: 1300, iron: 10, zinc: 9,  water: 1800 };
  if (exactAge < 12)  return { cal: 1900, pro: 34, cal_mg: 1300, iron: 10, zinc: 9,  water: 2000 };
  return                     { cal: 2000, pro: 34, cal_mg: 1300, iron: 8,  zinc: 9,  water: 2100 };
}

// ── Age-specific growth tip ──
function getGrowthTip(ageYears: number): string {
  if (ageYears < 2)  return '🍼 Focus on iron-rich foods and soft textures. Breast milk or formula still important.';
  if (ageYears < 3)  return '🌱 Introduce variety! Expose to 10+ different foods weekly. Small portions, big nutrition.';
  if (ageYears < 4)  return '🎨 Let toddlers help in kitchen — it builds healthy food relationships!';
  if (ageYears < 5)  return '🏃 Active preschoolers need energy-dense snacks. Calcium is critical for bone density.';
  if (ageYears < 6)  return '📚 School start! Brain foods (eggs, fish, walnuts) boost focus and memory.';
  if (ageYears < 7)  return '⚽ High activity age — increase protein and complex carbs for sustained energy.';
  if (ageYears < 8)  return '🧠 Omega-3 DHA from fish 2x/week enhances cognitive performance.';
  if (ageYears < 9)  return '💪 Building muscle foundation — ensure 3 dairy servings daily for calcium.';
  if (ageYears < 10) return '🦴 Bone density peaks at adolescence — maximize calcium NOW. Vitamin D critical.';
  if (ageYears < 11) return '🚀 Pre-puberty: iron needs rise significantly. Dark leafy greens + citrus daily.';
  if (ageYears < 12) return '💥 Growth spurt phase — caloric needs jump 20%. Protein at every single meal.';
  return                    '🏆 Pre-teen elite nutrition: 34g protein/day, 1300mg calcium, 60min activity daily.';
}

// ── Days of week ──
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

interface RecipeModal {
  title: string;
  meal: string;
  day: string;
  steps: string[];
  kidTask: string;
  nutrition: { cal: number; pro: string; carbs: string; };
  loading?: boolean;
  powerFact?: string;
  prepTime?: string;
}

interface WeeklyPlannerProps {
  language: string;
  diet: string;
  childProfile?: ChildProfile;
  allProfiles?: ChildProfile[];
  onSaveRecipe?: (name: string, meal: any) => void;
  isPremium?: boolean;
}

export default function WeeklyPlanner({ language, diet, childProfile, allProfiles = [], onSaveRecipe, isPremium }: WeeklyPlannerProps) {
  // ── Child selection ──
  const [selectedChildId, setSelectedChildId] = useState<string>(childProfile?.id || '');
  const [showChildPicker, setShowChildPicker] = useState(false);

  const availableChildren = allProfiles.filter(p => p.age >= 2 && p.age <= 12);
  const activeChild: ChildProfile | undefined = useMemo(() => {
    if (selectedChildId) return allProfiles.find(p => p.id === selectedChildId) || childProfile;
    return childProfile;
  }, [selectedChildId, allProfiles, childProfile]);

  // ── Age-specific data ──
  const ageYears = activeChild?.age ?? 6;
  const ageMonths = activeChild?.ageMonths ?? 0;
  const ageDisplay = activeChild?.ageDisplay ?? `${ageYears} years`;
  const bucket: AgeBucket = getAgeBucket(ageYears);
  const meta = AGE_BUCKET_META[bucket];
  const targets = exactAgeTargets(ageYears, ageMonths);
  const growthTip = getGrowthTip(ageYears);

  // ── Week variation auto-rotates weekly ──
  const weekIdx = Math.min(Math.floor((new Date().getDate() - 1) / 7), 2);

  // ── Chart state ──
  const [chart, setChart] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  // ── Date picker ──
  const today = new Date();
  const [calYear, setCalYear] = useState(today.getFullYear());
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState<number | null>(today.getDate());
  const [dayLog, setDayLog] = useState<Record<string, boolean>>({});

  // ── Recipe modal ──
  const [modal, setModal] = useState<RecipeModal | null>(null);

  // Safe fallback data
  const fallbackDays = WEEKLY_FALLBACK[bucket]?.[weekIdx] ?? WEEKLY_FALLBACK[bucket]?.[0] ?? [];
  const activeDays = (chart?.meals && Array.isArray(chart.meals) && chart.meals.length >= 7)
    ? chart.meals
    : fallbackDays;

  const generate = async () => {
    setLoading(true);
    setChart(null);
    try {
      const resp = await fetch('/api/weekly-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exactAge: `${ageYears} years ${ageMonths > 0 ? ageMonths + ' months' : ''}`,
          ageBucket: bucket,
          childName: activeChild?.name || 'Child',
          bucketFocus: meta.focus,
          weekVariation: weekIdx + 1,
          language,
          diet: activeChild?.foodCategories || diet,
          childProfile: activeChild,
          targets,
        }),
      });
      if (!resp.ok) throw new Error('api');
      const data = await resp.json();
      if (data?.meals && Array.isArray(data.meals) && data.meals.length >= 7) {
        setChart(data);
      } else {
        setChart({ meals: fallbackDays, groceryList: data?.groceryList ?? [], weeklyTip: growthTip });
      }
    } catch {
      setChart({ meals: fallbackDays, groceryList: [], weeklyTip: growthTip });
    } finally {
      setLoading(false);
    }
  };

  // ── Calendar helpers ──

  // Horizontal date strip: 21 days starting from Monday of current week
  const stripDates = useMemo(() => {
    const base = new Date(today);
    const dow = (base.getDay() + 6) % 7; // 0 = Monday
    const monday = new Date(base);
    monday.setDate(base.getDate() - dow);
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return Array(21).fill(null).map((_, i) => {
      const dt = new Date(monday);
      dt.setDate(monday.getDate() + i);
      const weekdayIdx = (dt.getDay() + 6) % 7;
      return {
        date: dt.getDate(),
        month: dt.getMonth(),
        year: dt.getFullYear(),
        dow: labels[weekdayIdx],
        dayName: DAYS[weekdayIdx],
        isToday: dt.toDateString() === today.toDateString(),
        key: `${dt.getFullYear()}-${dt.getMonth()+1}-${dt.getDate()}`,
      };
    });
  }, [today]);

  // Get meal for selected date
  const selectedDayName = selectedDate ? DAYS[(new Date(calYear, calMonth, selectedDate).getDay() + 6) % 7] : null;
  const selectedDayMeal = selectedDayName ? activeDays.find((d: any) => d?.day === selectedDayName) : null;

  // ── Recipe modal builder ──
  const openModal = async (mealType: string, mealText: string, dayName: string) => {
    // Show modal immediately with quick-parsed steps
    const quickSteps = mealText.split(/[,;]/).map((s: string) => s.trim()).filter(Boolean);
    setModal({
      title: `${dayName} — ${mealType}`,
      meal: mealText,
      day: dayName,
      steps: quickSteps.length > 1 ? quickSteps : [mealText],
      kidTask: 'Help wash the vegetables! 🥦',
      nutrition: { cal: Math.round(targets.cal / 5), pro: `${Math.round(targets.pro / 5)}g`, carbs: '35g' },
      loading: true,
    });

    // Fetch the full step-by-step culinary guide from backend
    try {
      const resp = await fetch('/api/generate-recipe-details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mealText,
          mealType,
          childAge: activeChild ? (activeChild.ageDisplay || `${activeChild.age} years`) : undefined,
          language,
          diet: activeChild?.foodCategories || diet,
        }),
      });
      const d = await resp.json();
      console.log('[WeeklyPlanner] recipe-details status:', resp.status, 'instructions:', d?.instructions);
      if (resp.ok && Array.isArray(d.instructions) && d.instructions.length) {
        setModal(prev => prev ? {
          ...prev,
          steps: d.instructions,
          kidTask: Array.isArray(d.juniorDuties) ? d.juniorDuties.join(' · ') : prev.kidTask,
          powerFact: d.powerMealFact,
          prepTime: d.prepTime,
          nutrition: d.nutrition ? { cal: d.nutrition.calories, pro: d.nutrition.protein, carbs: d.nutrition.carbs } : prev.nutrition,
          loading: false,
        } : prev);
      } else {
        console.warn('[WeeklyPlanner] steps not updated — ok:', resp.ok, 'instructions:', d?.instructions);
        setModal(prev => prev ? { ...prev, loading: false } : prev);
      }
    } catch (err) {
      console.error('[WeeklyPlanner] recipe-details error:', err);
      setModal(prev => prev ? { ...prev, loading: false } : prev);
    }
  };


  const groceryList: string[] = chart?.groceryList ?? ['Seasonal vegetables', 'Dal and legumes', 'Whole grains', 'Dairy products', 'Fresh fruits', 'Nuts and seeds', 'Eggs or protein source'];

  return (
    <div className="space-y-4">

      {/* Recipe Detail Modal */}
      {modal && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-[80] backdrop-blur-sm" onClick={() => setModal(null)}>
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-amber-200 w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-5 rounded-t-3xl border-b border-amber-100">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-black text-amber-600 uppercase tracking-wide mb-1">{modal.title}</p>
                  <h3 className="text-lg font-black text-slate-800 leading-tight">{modal.meal.slice(0, 60)}{modal.meal.length > 60 ? '...' : ''}</h3>
                </div>
                <button onClick={() => setModal(null)} className="p-2 hover:bg-slate-100 rounded-full ml-2 shrink-0"><X className="w-4 h-4 text-slate-400"/></button>
              </div>
            </div>
            <div className="p-5 space-y-4">
              {/* Nutrition snapshot */}
              <div className="grid grid-cols-3 gap-2">
                {[['🔥', modal.nutrition.cal + ' kcal', 'Calories'], ['💪', modal.nutrition.pro, 'Protein'], ['🌾', modal.nutrition.carbs, 'Carbs']].map(([emoji, val, label]) => (
                  <div key={label as string} className="bg-slate-50 rounded-xl p-2 text-center">
                    <div className="text-lg">{emoji}</div>
                    <div className="font-black text-sm text-slate-700">{val}</div>
                    <div className="text-[10px] text-slate-400">{label}</div>
                  </div>
                ))}
              </div>
              {/* Steps */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-black text-slate-500 uppercase tracking-wide">Preparation Steps</p>
                  {modal.loading && (
                    <span className="flex items-center gap-1 text-[10px] font-bold text-indigo-500">
                      <span className="w-3 h-3 border-2 border-indigo-300 border-t-indigo-600 rounded-full animate-spin"/>
                      Loading full guide...
                    </span>
                  )}
                  {modal.prepTime && !modal.loading && (
                    <span className="text-[10px] font-bold text-slate-400">⏱️ {modal.prepTime}</span>
                  )}
                </div>
                <div className="space-y-2">
                  {modal.steps.map((step, i) => (
                    <div key={i} className="flex items-start gap-2.5">
                      <span className="w-5 h-5 bg-[#FF6B6B] text-white rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5">{i+1}</span>
                      <p className="text-sm text-slate-600 font-semibold leading-snug">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
              {/* Power fact */}
              {modal.powerFact && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3">
                  <p className="text-xs font-black text-emerald-700 mb-1">💡 Power Fact</p>
                  <p className="text-xs text-emerald-600 font-semibold">{modal.powerFact}</p>
                </div>
              )}
              {/* Kid task */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-3">
                <p className="text-xs font-black text-yellow-700 mb-1">👶 Junior Chef Task</p>
                <p className="text-xs text-yellow-600 font-semibold">{modal.kidTask}</p>
              </div>
              {/* Save button */}
              {onSaveRecipe && isPremium && (
                <button onClick={() => { onSaveRecipe(modal.meal, modal); setModal(null); }}
                  disabled={modal.loading}
                  className="w-full py-3 bg-gradient-to-r from-amber-400 to-orange-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                  <Star className="w-4 h-4"/> {modal.loading ? 'Fetching recipe...' : 'Save to Recipe Box'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Header: Child Selector + Title */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-black text-slate-800 text-base">
            {activeChild ? `${activeChild.name}'s Meal Plan` : 'Weekly Meal Planner'}
          </h3>
          {activeChild && (
            <p className={`text-xs font-bold ${meta.accent}`}>
              {meta.emoji} Age {ageDisplay} · {meta.label} · Targets: {targets.cal} kcal/day
            </p>
          )}
        </div>

        {/* Multi-child dropdown */}
        {availableChildren.length > 1 && (
          <div className="relative">
            <button onClick={() => setShowChildPicker(!showChildPicker)}
              className="flex items-center gap-2 bg-white border-2 border-slate-200 hover:border-teal-400 rounded-2xl px-3 py-2 text-sm font-bold text-slate-600 transition-all min-w-[140px]">
              <User className="w-4 h-4 text-teal-500"/>
              <span className="flex-1 text-left">{activeChild?.name || 'Select child'}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showChildPicker ? 'rotate-180' : ''}`}/>
            </button>
            {showChildPicker && (
              <div className="absolute right-0 top-full mt-1 bg-white border-2 border-slate-200 rounded-2xl shadow-xl z-30 min-w-[180px] overflow-hidden">
                {availableChildren.map(c => (
                  <button key={c.id} onClick={() => { setSelectedChildId(c.id); setShowChildPicker(false); setChart(null); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left text-sm font-bold transition-colors hover:bg-slate-50 ${c.id === (activeChild?.id) ? 'bg-teal-50 text-teal-700' : 'text-slate-600'}`}>
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-amber-300 to-orange-400 flex items-center justify-center text-white font-black text-xs overflow-hidden">
                      {(c as any).photo ? <img src={(c as any).photo} alt={c.name} className="w-full h-full object-cover"/> : c.name[0]}
                    </div>
                    <div>
                      <div>{c.name}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{c.ageDisplay || c.age + 'y'}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Age-specific growth tip */}
      {activeChild && (
        <div className={`${meta.color} border-2 rounded-2xl p-3 flex items-start gap-2`}>
          <span className="text-lg shrink-0">{meta.emoji}</span>
          <div>
            <p className={`text-xs font-black ${meta.accent} uppercase tracking-wide`}>Age {ageYears} Growth Insight</p>
            <p className="text-xs text-slate-600 mt-0.5 font-semibold">{growthTip}</p>
          </div>
        </div>
      )}

      {/* Daily Nutrition Targets Bar */}
      {activeChild && (
        <div className="bg-white border-2 border-slate-100 rounded-2xl p-3">
          <p className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2">📊 Daily Targets for {ageDisplay}</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: 'Calories', val: targets.cal, unit: 'kcal', color: 'bg-orange-400', icon: '🔥' },
              { label: 'Protein',  val: targets.pro, unit: 'g',    color: 'bg-blue-400',   icon: '💪' },
              { label: 'Calcium',  val: targets.cal_mg, unit: 'mg', color: 'bg-purple-400', icon: '🦴' },
              { label: 'Iron',     val: targets.iron, unit: 'mg',  color: 'bg-red-400',    icon: '🩸' },
            ].map(t => (
              <div key={t.label} className="text-center">
                <div className="text-base">{t.icon}</div>
                <div className="font-black text-sm text-slate-700">{t.val}<span className="text-[10px] text-slate-400 font-normal ml-0.5">{t.unit}</span></div>
                <div className="text-[10px] text-slate-400">{t.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Generate Button */}
      <button onClick={generate} disabled={loading}
        className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-2xl font-black text-sm hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2 shadow-md transition-all">
        {loading
          ? <><RefreshCw className="w-4 h-4 animate-spin"/> Generating personalised plan for {activeChild?.name || 'child'}...</>
          : <><Calendar className="w-4 h-4"/> Generate AI Plan for {activeChild ? activeChild.name + ' (' + ageDisplay + ')' : 'Child'} {meta.emoji}</>}
      </button>

      {/* ── SLICK HORIZONTAL DATE STRIP ── */}
      <div className="bg-white border-2 border-slate-100 rounded-2xl p-3">
        <div className="flex items-center justify-between mb-2 px-1">
          <p className="font-black text-slate-700 text-sm">📅 Pick a Day</p>
          <p className="text-[10px] text-slate-400 font-semibold">Swipe to scroll →</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 px-1 snap-x date-strip" style={{ scrollbarWidth: 'thin' }}>
          {stripDates.map((dt) => {
            const isSelected = dt.date === selectedDate && dt.month === calMonth && dt.year === calYear;
            const hasLog = dayLog[dt.key];
            return (
              <button key={dt.key}
                onClick={() => {
                  if (isSelected) { setSelectedDate(null); }
                  else { setSelectedDate(dt.date); setCalMonth(dt.month); setCalYear(dt.year); }
                }}
                className={`snap-center shrink-0 w-14 min-h-[68px] rounded-2xl flex flex-col items-center justify-center gap-0.5 font-bold transition-all relative border-2 touch-manipulation
                  ${isSelected ? 'bg-[#FF6B6B] text-white border-[#FF6B6B] shadow-md scale-105'
                    : dt.isToday ? 'bg-indigo-50 text-indigo-700 border-indigo-300'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'}`}>
                <span className={`text-[10px] uppercase tracking-wide ${isSelected ? 'text-white/80' : dt.isToday ? 'text-indigo-400' : 'text-slate-400'}`}>{dt.dow}</span>
                <span className="text-xl leading-none">{dt.date}</span>
                <span className={`text-[8px] ${isSelected ? 'text-white/70' : 'text-slate-300'}`}>{MONTHS[dt.month].slice(0,3)}</span>
                {hasLog && <span className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-green-400'}`}/>}
              </button>
            );
          })}
        </div>
      </div>


      {/* ── SELECTED DATE MEAL LOG ── */}
      {selectedDate && selectedDayMeal && (
        <div className={`${meta.color} border-2 rounded-2xl p-4`}>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">{meta.emoji}</span>
            <div>
              <h4 className={`font-black text-sm ${meta.accent}`}>
                {MONTHS[calMonth]} {selectedDate} — {selectedDayMeal?.day || selectedDayName}
              </h4>
              <p className="text-[10px] text-slate-400">Tap a meal to view full recipe</p>
            </div>
            <span className={`ml-auto text-[10px] font-bold px-2 py-1 rounded-full ${meta.badge}`}>{meta.label}</span>
          </div>

          <div className="space-y-2">
            {([
              ['🌅', 'Breakfast', selectedDayMeal?.breakfast],
              ['🍎', 'Morning Snack', selectedDayMeal?.morningSnack],
              ['☀️', 'Lunch', selectedDayMeal?.lunch],
              ['💧', 'Hydration', `${targets.water}ml water throughout the day`],
              ['🌤️', 'Evening Snack', selectedDayMeal?.eveningSnack],
              ['🌙', 'Dinner', selectedDayMeal?.dinner],
            ] as [string, string, string | undefined][]).map(([emoji, label, val]) => val ? (
              <div key={label} className="bg-white/80 rounded-xl p-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex-1">
                    <p className="font-black text-slate-500 text-[10px] uppercase tracking-wide">{emoji} {label}</p>
                    <p className="text-slate-700 font-semibold text-xs mt-0.5 leading-snug">{val}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {label !== 'Hydration' && (
                      <button onClick={() => openModal(label, val, selectedDayMeal?.day || '')}
                        className="flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 font-bold text-[10px] px-2 py-1.5 rounded-lg border border-indigo-200 transition-all">
                        <BookOpen className="w-3 h-3"/> Recipe
                      </button>
                    )}
                    {onSaveRecipe && isPremium && label !== 'Hydration' && (
                      <button onClick={() => openModal(label, val, selectedDayMeal?.day || '')}
                        className="flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-600 font-bold text-[10px] px-2 py-1.5 rounded-lg border border-amber-200 transition-all">
                        <Star className="w-3 h-3"/> Save
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : null)}
          </div>

          {selectedDayMeal?.powerFact && (
            <div className="mt-3 bg-white/60 rounded-xl p-2.5 text-xs font-bold text-slate-600">
              {selectedDayMeal.powerFact}
            </div>
          )}
        </div>
      )}

      {/* ── FULL WEEK VIEW ── */}
      <div id="weekly-plan-pdf-container" className="space-y-2">
        <div className="flex items-center justify-between">
          <span className={`text-xs font-black ${meta.accent}`}>
            {meta.emoji} Full Week · {activeChild ? `Age ${ageDisplay}` : meta.label}
            {!chart && <span className="text-slate-400 font-normal ml-1">(preview)</span>}
          </span>
          <button onClick={() => downloadAsPDF('weekly-plan-pdf-container', 'weekly-plan')}
            className="flex items-center gap-1 px-3 py-1.5 bg-white border-2 border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">
            <Download className="w-3 h-3"/> PDF
          </button>
        </div>

        {activeDays.map((day: any, i: number) => (
          <div key={i} className={`${meta.color} border-2 rounded-2xl p-3 sm:p-4`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-base">{meta.emoji}</span>
              <h3 className={`font-black text-sm ${meta.accent}`}>{day?.day ?? `Day ${i+1}`}</h3>
              <span className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full ${meta.badge}`}>{meta.label}</span>
            </div>

            {/* Mobile: vertical, Desktop: grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
              {([
                ['🌅 Breakfast', day?.breakfast],
                ['🍎 Morning Snack', day?.morningSnack],
                ['☀️ Lunch', day?.lunch],
                ['🌤️ Evening Snack', day?.eveningSnack],
                ['🌙 Dinner', day?.dinner],
              ] as [string, string | undefined][]).filter(([, v]) => v).map(([label, val]) => (
                <div key={label} className="bg-white/70 rounded-xl p-2.5">
                  <p className="font-black text-slate-500 text-[10px] uppercase tracking-wide mb-0.5">{label}</p>
                  <p className="text-slate-700 font-semibold leading-snug">{val}</p>
                  <button onClick={() => openModal(label.replace(/^[^ ]+ /, ''), val as string, day?.day || '')}
                    className="mt-1.5 flex items-center gap-1 text-indigo-500 font-bold text-[10px] hover:text-indigo-700 transition-colors">
                    <BookOpen className="w-3 h-3"/> View Recipe
                  </button>
                </div>
              ))}
            </div>

            {day?.powerFact && (
              <div className="mt-2 bg-white/60 rounded-xl p-2 text-xs font-bold text-slate-600">{day.powerFact}</div>
            )}
          </div>
        ))}

        {/* Grocery List */}
        {groceryList.length > 0 && (
          <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-4">
            <p className="font-black text-green-700 text-sm mb-2">🛒 Weekly Grocery List</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
              {groceryList.map((item: string, i: number) => (
                <div key={i} className="flex items-center gap-1.5 text-xs text-green-700">
                  <span className="text-green-400 shrink-0">✓</span>{item}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-3 text-xs font-bold text-amber-700">
          💡 {growthTip}
        </div>
      </div>
    </div>
  );
}
