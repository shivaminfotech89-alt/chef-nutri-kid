import React, { useState, useCallback } from 'react';
import { BarChart2, Plus, X, CheckCircle, Circle, Award, Droplets, Zap, Flame } from 'lucide-react';
import { type ChildProfile, getNutritionTargets } from '../data';

interface Props {
  profile: ChildProfile;
  onUpdate: (profile: ChildProfile) => void;
  onClose: () => void;
}

// Nutrient DB — maps common meal keywords to nutrition values
const NUTRIENT_DB: Record<string, { cal: number; pro: number; cal_mg: number; iron: number; zinc: number }> = {
  // Grains
  'rice':       { cal: 130, pro: 3,  cal_mg: 10,  iron: 0.5, zinc: 0.5 },
  'roti':       { cal: 80,  pro: 3,  cal_mg: 15,  iron: 0.8, zinc: 0.3 },
  'oats':       { cal: 150, pro: 5,  cal_mg: 20,  iron: 2,   zinc: 1   },
  'poha':       { cal: 120, pro: 3,  cal_mg: 15,  iron: 1.5, zinc: 0.5 },
  'idli':       { cal: 60,  pro: 2,  cal_mg: 10,  iron: 0.5, zinc: 0.3 },
  'upma':       { cal: 140, pro: 4,  cal_mg: 20,  iron: 1,   zinc: 0.5 },
  'paratha':    { cal: 200, pro: 5,  cal_mg: 30,  iron: 1,   zinc: 0.5 },
  'bread':      { cal: 70,  pro: 3,  cal_mg: 20,  iron: 0.8, zinc: 0.3 },
  'khichdi':    { cal: 200, pro: 7,  cal_mg: 30,  iron: 2,   zinc: 1   },
  'dalia':      { cal: 130, pro: 4,  cal_mg: 20,  iron: 1.5, zinc: 0.7 },
  // Pulses
  'dal':        { cal: 120, pro: 8,  cal_mg: 40,  iron: 3,   zinc: 1   },
  'rajma':      { cal: 150, pro: 9,  cal_mg: 60,  iron: 4,   zinc: 1.5 },
  'chole':      { cal: 160, pro: 9,  cal_mg: 50,  iron: 4,   zinc: 1.5 },
  'sambar':     { cal: 80,  pro: 4,  cal_mg: 40,  iron: 2,   zinc: 0.8 },
  // Protein
  'egg':        { cal: 80,  pro: 6,  cal_mg: 25,  iron: 1,   zinc: 0.5 },
  'eggs':       { cal: 160, pro: 12, cal_mg: 50,  iron: 2,   zinc: 1   },
  'paneer':     { cal: 180, pro: 12, cal_mg: 200, iron: 0.5, zinc: 1   },
  'chicken':    { cal: 165, pro: 25, cal_mg: 15,  iron: 1,   zinc: 2   },
  'fish':       { cal: 150, pro: 22, cal_mg: 30,  iron: 0.8, zinc: 1   },
  'tofu':       { cal: 100, pro: 10, cal_mg: 130, iron: 2,   zinc: 1   },
  // Dairy
  'milk':       { cal: 120, pro: 6,  cal_mg: 240, iron: 0.1, zinc: 0.9 },
  'curd':       { cal: 90,  pro: 5,  cal_mg: 180, iron: 0.1, zinc: 0.7 },
  'yogurt':     { cal: 100, pro: 6,  cal_mg: 200, iron: 0.1, zinc: 0.9 },
  'cheese':     { cal: 100, pro: 7,  cal_mg: 200, iron: 0.2, zinc: 0.9 },
  // Vegetables
  'spinach':    { cal: 15,  pro: 2,  cal_mg: 100, iron: 3,   zinc: 0.5 },
  'broccoli':   { cal: 25,  pro: 2,  cal_mg: 40,  iron: 0.5, zinc: 0.3 },
  'carrot':     { cal: 25,  pro: 0.5,cal_mg: 30,  iron: 0.3, zinc: 0.2 },
  'palak':      { cal: 20,  pro: 2,  cal_mg: 100, iron: 3,   zinc: 0.5 },
  'vegetables': { cal: 50,  pro: 2,  cal_mg: 50,  iron: 1,   zinc: 0.5 },
  'sabzi':      { cal: 80,  pro: 2,  cal_mg: 40,  iron: 1,   zinc: 0.5 },
  // Fruits
  'banana':     { cal: 90,  pro: 1,  cal_mg: 5,   iron: 0.3, zinc: 0.2 },
  'apple':      { cal: 70,  pro: 0.3,cal_mg: 8,   iron: 0.1, zinc: 0.1 },
  'mango':      { cal: 100, pro: 1,  cal_mg: 10,  iron: 0.2, zinc: 0.1 },
  'orange':     { cal: 60,  pro: 1,  cal_mg: 40,  iron: 0.1, zinc: 0.1 },
  'fruit':      { cal: 75,  pro: 0.5,cal_mg: 15,  iron: 0.2, zinc: 0.1 },
  // Snacks
  'almonds':    { cal: 60,  pro: 2,  cal_mg: 20,  iron: 0.5, zinc: 0.3 },
  'nuts':       { cal: 80,  pro: 2,  cal_mg: 20,  iron: 0.5, zinc: 0.3 },
  'makhana':    { cal: 60,  pro: 3,  cal_mg: 50,  iron: 1,   zinc: 0.5 },
};

function estimateNutrients(mealText: string) {
  const text = mealText.toLowerCase();
  let cal = 0, pro = 0, cal_mg = 0, iron = 0, zinc = 0;
  let matched = 0;
  for (const [key, vals] of Object.entries(NUTRIENT_DB)) {
    if (text.includes(key)) {
      cal += vals.cal; pro += vals.pro; cal_mg += vals.cal_mg; iron += vals.iron; zinc += vals.zinc;
      matched++;
    }
  }
  // If no match, estimate based on meal size descriptor
  if (matched === 0) { cal = 150; pro = 5; cal_mg = 40; iron = 1; zinc = 0.5; }
  return { cal: Math.round(cal / Math.max(matched, 1) * 1.5), pro: Math.round(pro / Math.max(matched, 1) * 1.5 * 10) / 10, cal_mg: Math.round(cal_mg / Math.max(matched, 1) * 1.2), iron: Math.round(iron / Math.max(matched, 1) * 1.2 * 10) / 10, zinc: Math.round(zinc / Math.max(matched, 1) * 10) / 10 };
}

interface NutrientLog {
  cal: number;
  pro: number;
  cal_mg: number;
  iron: number;
  zinc: number;
  water: number;
  meals: { name: string; cal: number; eaten: boolean; time: string }[];
}

const emptyLog = (): NutrientLog => ({ cal: 0, pro: 0, cal_mg: 0, iron: 0, zinc: 0, water: 0, meals: [] });

function getTodayKey() { return new Date().toISOString().split('T')[0]; }

function getMilestone(nutrient: string, pct: number): string | null {
  if (pct >= 100) {
    const milestones: Record<string, string> = {
      cal:    '🎉 Calorie Goal Met! Energy Tank Full!',
      pro:    '💪 Protein Goal Met! Muscles Powered Up!',
      cal_mg: '🦴 Calcium Goal Met! Bones Getting Stronger!',
      iron:   '🩸 Iron Goal Met! Immunity Powered Up! 🛡️',
      zinc:   '⚡ Zinc Goal Met! Growth Boosted!',
      water:  '💧 Hydration Goal Met! Brain Running Smooth!',
    };
    return milestones[nutrient] || null;
  }
  return null;
}

export default function DailyProgress({ profile, onUpdate, onClose }: Props) {
  const todayKey = getTodayKey();
  const targets = getNutritionTargets(profile.age);
  const waterTarget = profile.age <= 3 ? 1000 : profile.age <= 6 ? 1200 : profile.age <= 9 ? 1500 : 1800;

  // Load today's log from dailyLogs
  const todayLog: NutrientLog = (profile.dailyLogs || []).find((l: any) => l.date === todayKey) || emptyLog();
  const [log, setLog] = useState<NutrientLog>(todayLog);

  const [customMeal, setCustomMeal] = useState('');
  const [waterAdd, setWaterAdd] = useState('');
  const [milestones, setMilestones] = useState<string[]>([]);

  const saveLog = useCallback((newLog: NutrientLog) => {
    setLog(newLog);
    const existingLogs = (profile.dailyLogs || []).filter((l: any) => l.date !== todayKey);
    onUpdate({
      ...profile,
      dailyLogs: [...existingLogs, { ...newLog, date: todayKey }]
    });
    // Check milestones
    const newMilestones: string[] = [];
    [
      ['cal', newLog.cal / targets.calories],
      ['pro', newLog.pro / targets.protein],
      ['cal_mg', newLog.cal_mg / targets.calcium],
      ['iron', newLog.iron / targets.iron],
      ['water', newLog.water / waterTarget],
    ].forEach(([k, pct]) => {
      const m = getMilestone(k as string, pct as number);
      if (m && !milestones.includes(m)) newMilestones.push(m);
    });
    if (newMilestones.length > 0) setMilestones(prev => [...prev, ...newMilestones]);
  }, [profile, todayKey, targets, waterTarget, milestones, onUpdate]);

  const addMeal = () => {
    if (!customMeal.trim()) return;
    const nutrients = estimateNutrients(customMeal);
    const meal = { name: customMeal, cal: nutrients.cal, eaten: true, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) };
    const newLog: NutrientLog = {
      ...log,
      cal: log.cal + nutrients.cal,
      pro: log.pro + nutrients.pro,
      cal_mg: log.cal_mg + nutrients.cal_mg,
      iron: log.iron + nutrients.iron,
      zinc: log.zinc + nutrients.zinc,
      meals: [...log.meals, meal],
    };
    saveLog(newLog);
    setCustomMeal('');
  };

  const addWater = () => {
    const ml = parseInt(waterAdd) || 200;
    saveLog({ ...log, water: log.water + ml });
    setWaterAdd('');
  };

  const pct = (val: number, target: number) => Math.min(Math.round((val / target) * 100), 100);

  const bars = [
    { key: 'cal',    label: 'Calories',  icon: '🔥', val: log.cal,    target: targets.calories, unit: 'kcal', color: 'bg-orange-400' },
    { key: 'pro',    label: 'Protein',   icon: '💪', val: log.pro,    target: targets.protein,  unit: 'g',    color: 'bg-blue-400'   },
    { key: 'cal_mg', label: 'Calcium',   icon: '🦴', val: log.cal_mg, target: targets.calcium,  unit: 'mg',   color: 'bg-purple-400' },
    { key: 'iron',   label: 'Iron',      icon: '🩸', val: log.iron,   target: targets.iron,     unit: 'mg',   color: 'bg-red-400'    },
    { key: 'water',  label: 'Hydration', icon: '💧', val: log.water,  target: waterTarget,       unit: 'ml',   color: 'bg-cyan-400'   },
  ];

  // Last 7 days calorie data
  const last7 = Array(7).fill(null).map((_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const key = d.toISOString().split('T')[0];
    const dayLog = (profile.dailyLogs || []).find((l: any) => l.date === key);
    return { label: ['M','T','W','T','F','S','S'][(d.getDay() + 6) % 7], cal: dayLog?.cal || 0, isToday: i === 6 };
  });
  const maxCal = Math.max(...last7.map(d => d.cal), targets.calories);

  return (
    <div className="fixed inset-0 bg-slate-900/60 flex items-start justify-center p-3 sm:p-4 z-50 overflow-y-auto pt-6 sm:pt-8 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-indigo-200 w-full max-w-lg mb-8">

        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-2xl flex items-center justify-center"><BarChart2 className="w-5 h-5 text-indigo-600"/></div>
            <div>
              <h2 className="text-base font-black text-slate-800">NutriPeds Daily Journal</h2>
              <p className="text-xs text-slate-400">{profile.name} · {profile.ageDisplay || profile.age + 'y'} · {getTodayKey()}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full touch-manipulation"><X className="w-5 h-5 text-slate-400"/></button>
        </div>

        <div className="p-4 sm:p-5 space-y-4">

          {/* Milestone Celebrations */}
          {milestones.length > 0 && (
            <div className="space-y-2">
              {milestones.slice(-3).map((m, i) => (
                <div key={i} className="bg-gradient-to-r from-amber-50 to-yellow-50 border-2 border-amber-200 rounded-2xl p-3 flex items-center gap-2 animate-pulse">
                  <Award className="w-5 h-5 text-amber-500 shrink-0"/>
                  <p className="text-sm font-black text-amber-700">{m}</p>
                </div>
              ))}
            </div>
          )}

          {/* Progress Bars */}
          <div className="bg-slate-50 rounded-2xl p-4">
            <p className="text-sm font-black text-slate-700 mb-3">📊 Today's Progress</p>
            <div className="space-y-3">
              {bars.map(b => {
                const p = pct(b.val, b.target);
                return (
                  <div key={b.key}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-bold text-slate-600">{b.icon} {b.label}</span>
                      <span className="text-xs text-slate-500">{Math.round(b.val)}/{b.target} {b.unit} · <span className={p >= 100 ? 'text-green-600 font-black' : 'text-slate-400'}>{p}%</span></span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                      <div className={`${b.color} h-2.5 rounded-full transition-all duration-700`} style={{ width: `${p}%` }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Log a Meal */}
          <div className="bg-indigo-50 rounded-2xl p-4">
            <p className="text-sm font-black text-indigo-700 mb-3">🍽️ Log What {profile.name} Ate</p>
            <div className="flex gap-2">
              <input
                type="text"
                value={customMeal}
                onChange={e => setCustomMeal(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addMeal()}
                placeholder="e.g. Dal rice + sabzi, 2 rotis, banana..."
                className="flex-1 text-sm bg-white border-2 border-indigo-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-400 font-semibold min-h-[44px]"
              />
              <button onClick={addMeal} className="px-4 py-2.5 bg-indigo-500 text-white rounded-xl font-black text-sm hover:bg-indigo-600 transition-colors min-h-[44px] min-w-[44px]">
                <Plus className="w-4 h-4"/>
              </button>
            </div>
            <p className="text-[10px] text-indigo-400 mt-1.5 font-semibold">AI auto-estimates nutrients from meal name</p>
          </div>

          {/* Water Logger */}
          <div className="bg-cyan-50 rounded-2xl p-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-cyan-500"/>
                <div>
                  <p className="text-sm font-black text-cyan-700">Hydration Log</p>
                  <p className="text-xs text-cyan-500">{log.water}ml / {waterTarget}ml target</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  {[100, 150, 200, 250].map(ml => (
                    <button key={ml} onClick={() => saveLog({ ...log, water: log.water + ml })}
                      className="px-2 py-1.5 bg-white border border-cyan-200 rounded-lg text-[10px] font-bold text-cyan-600 hover:bg-cyan-100 transition-colors min-h-[36px]">
                      +{ml}ml
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {/* Water progress */}
            <div className="mt-2 w-full bg-cyan-100 rounded-full h-2">
              <div className="bg-cyan-400 h-2 rounded-full transition-all" style={{ width: `${pct(log.water, waterTarget)}%` }}/>
            </div>
          </div>

          {/* Meals Eaten Today */}
          {log.meals.length > 0 && (
            <div>
              <p className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2">✅ Meals Logged Today</p>
              <div className="space-y-1.5">
                {log.meals.map((m, i) => (
                  <div key={i} className="flex items-center gap-3 bg-slate-50 rounded-xl px-3 py-2.5">
                    <CheckCircle className="w-4 h-4 text-green-500 shrink-0"/>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-700 truncate">{m.name}</p>
                      <p className="text-[10px] text-slate-400">{m.time} · ~{m.cal} kcal estimated</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7-Day Calorie Trend Chart */}
          <div>
            <p className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2">📈 7-Day Calorie Trend</p>
            <div className="bg-slate-50 rounded-xl p-3">
              <div className="flex items-end gap-1 h-16">
                {last7.map(({ label, cal, isToday }, i) => {
                  const h = maxCal > 0 ? Math.max((cal / maxCal) * 100, cal > 0 ? 8 : 0) : 0;
                  const pct = targets.calories > 0 ? cal / targets.calories : 0;
                  const barColor = cal === 0 ? 'bg-slate-200' : pct >= 0.8 ? 'bg-green-400' : pct >= 0.5 ? 'bg-amber-400' : 'bg-red-300';
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div className={`w-full ${barColor} rounded-t-sm transition-all ${isToday ? 'ring-2 ring-indigo-400' : ''}`} style={{ height: `${h}%` }}/>
                      <span className={`text-[9px] ${isToday ? 'font-black text-indigo-600' : 'text-slate-400'}`}>{label}</span>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-3 mt-2 flex-wrap">
                {[['bg-green-400','≥80% target'],['bg-amber-400','50-80%'],['bg-red-300','<50%'],['bg-slate-200','Not logged']].map(([c,l]) => (
                  <span key={l} className="text-[9px] flex items-center gap-1 text-slate-500"><span className={`w-2 h-2 ${c} rounded-full inline-block`}/>{l}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Daily Summary Callout */}
          <div className={`rounded-2xl p-3 border-2 ${pct(log.cal, targets.calories) >= 80 ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
            <p className={`text-xs font-black ${pct(log.cal, targets.calories) >= 80 ? 'text-green-700' : 'text-amber-700'}`}>
              {pct(log.cal, targets.calories) >= 100 ? `🎉 ${profile.name} hit today's nutrition target!` :
               pct(log.cal, targets.calories) >= 80 ? `🌟 Almost there! ${profile.name} is doing great!` :
               pct(log.cal, targets.calories) >= 50 ? `💪 Keep going! Add more nutritious meals.` :
               `🍽️ ${profile.name} needs more fuel today — add a wholesome meal!`}
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {Math.round(log.cal)} / {targets.calories} kcal logged · {Math.round(log.pro)}g protein · {Math.round(log.iron)}mg iron
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
