import React, { useState, useEffect } from 'react';
import { Bell, Plus, X, Clock, Trash2, BellRing } from 'lucide-react';
import type { AlertItem as Alert } from '../data';

interface Props {
  alerts: any[];
  setAlerts: (updated: any[]) => void;
  onClose: () => void;
}

const ALERT_TEMPLATES: Omit<Alert, 'id' | 'active'>[] = [
  { type: 'hydration', title: '💧 Water Time!', message: 'Time for your child to drink a glass of water! Staying hydrated helps brain and body function.', time: '08:00', emoji: '💧' },
  { type: 'hydration', title: '💧 Hydration Check', message: 'Mid-morning hydration reminder! Offer water or coconut water.', time: '10:30', emoji: '💧' },
  { type: 'snack', title: '🍎 Morning Snack', message: 'Healthy snack time! Try fresh fruit, nuts, or a small bowl of yogurt.', time: '10:00', emoji: '🍎' },
  { type: 'meal', title: '🍽️ Lunch Time!', message: 'Lunch time! Make sure half the plate is colorful vegetables! 🥦🥕', time: '13:00', emoji: '🍽️' },
  { type: 'snack', title: '🥛 Evening Snack', message: 'Evening snack time! A glass of milk with a small healthy snack is perfect.', time: '16:00', emoji: '🥛' },
  { type: 'meal', title: '🌙 Dinner Time', message: 'Dinner time! A light, nutritious dinner helps your child sleep better.', time: '19:00', emoji: '🌙' },
  { type: 'activity', title: '🏃 Play Time!', message: 'Time for 30 minutes of active play! Running, jumping, and dancing help strong bones and muscles.', time: '17:00', emoji: '🏃' },
  { type: 'vitamin', title: '💊 Vitamin Time', message: 'Time for your child\'s daily vitamin supplement if prescribed by your pediatrician.', time: '09:00', emoji: '💊' },
  { type: 'hydration', title: '💧 Bedtime Water', message: 'Last water reminder before bed! Small sip only — no large amounts before sleep.', time: '20:00', emoji: '💧' },
];

export default function AlertEngine({ alerts, setAlerts, onClose }: Props) {
  const [customTitle, setCustomTitle] = useState('');
  const [customMsg, setCustomMsg] = useState('');
  const [customTime, setCustomTime] = useState('');
  const [customType, setCustomType] = useState<Alert['type']>('snack');
  const [activeAlert, setActiveAlert] = useState<Alert | null>(null);
  const [tab, setTab] = useState<'active' | 'add'>('active');

 const save = (updated: Alert[]) => {
    setAlerts(updated);
  };

  const addTemplate = (template: Omit<Alert, 'id' | 'active'>) => {
    const alert: Alert = { ...template, id: Date.now().toString(), active: true };
    save([...alerts, alert]);
  };

  const addCustom = () => {
    if (!customTitle || !customTime) return;
    const alert: Alert = {
      id: Date.now().toString(),
      type: customType,
      title: customTitle,
      message: customMsg,
      time: customTime,
      active: true,
      emoji: customType === 'hydration' ? '💧' : customType === 'snack' ? '🍎' : customType === 'meal' ? '🍽️' : customType === 'activity' ? '🏃' : '💊'
    };
    save([...alerts, alert]);
    setCustomTitle(''); setCustomMsg(''); setCustomTime('');
  };

  const toggle = (id: string) => save(alerts.map(a => a.id === id ? { ...a, active: !a.active } : a));
  const remove = (id: string) => save(alerts.filter(a => a.id !== id));

  // Check for due alerts every minute
  useEffect(() => {
    const check = () => {
      const now = new Date();
      const hhmm = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
      const due = alerts.find(a => a.active && a.time === hhmm);
      if (due) setActiveAlert(due);
    };
    check();
    const timer = setInterval(check, 60000);
    return () => clearInterval(timer);
  }, [alerts]);

  const typeColors: Record<Alert['type'], string> = {
    hydration: 'bg-blue-100 text-blue-700 border-blue-200',
    snack: 'bg-amber-100 text-amber-700 border-amber-200',
    meal: 'bg-green-100 text-green-700 border-green-200',
    activity: 'bg-purple-100 text-purple-700 border-purple-200',
    vitamin: 'bg-pink-100 text-pink-700 border-pink-200',
  };

  return (
    <>
      {/* Active alert popup */}
      {activeAlert && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-[100]">
          <div className="bg-white rounded-3xl p-7 shadow-2xl border-4 border-[#FFD93D] w-full max-w-sm text-center">
            <div className="text-5xl mb-4 animate-bounce">{activeAlert.emoji}</div>
            <h2 className="text-xl font-black text-slate-800 mb-2">{activeAlert.title}</h2>
            <p className="text-sm text-slate-500 mb-6">{activeAlert.message}</p>
            <button onClick={() => setActiveAlert(null)} className="w-full py-3 bg-[#FF6B6B] text-white rounded-2xl font-black">Got it! ✅</button>
          </div>
        </div>
      )}

      <div className="fixed inset-0 bg-slate-900/60 flex items-start justify-center p-4 z-50 overflow-y-auto pt-8 backdrop-blur-sm">
        <div className="bg-white rounded-3xl shadow-2xl border-2 border-amber-200 w-full max-w-lg">
          <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-gradient-to-r from-amber-50 to-orange-50 rounded-t-3xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-2xl flex items-center justify-center"><Bell className="w-5 h-5 text-amber-600"/></div>
              <div>
                <h2 className="text-lg font-black text-slate-800">Alert & Reminder Engine</h2>
                <p className="text-xs text-slate-400">{alerts.filter(a => a.active).length} active reminders</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400"/></button>
          </div>

          <div className="p-5">
            {/* Tabs */}
            <div className="flex gap-2 mb-4">
              <button onClick={() => setTab('active')} className={`flex-1 py-2 rounded-xl font-black text-sm transition-all ${tab === 'active' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'}`}>
                🔔 Active ({alerts.length})
              </button>
              <button onClick={() => setTab('add')} className={`flex-1 py-2 rounded-xl font-black text-sm transition-all ${tab === 'add' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'}`}>
                ➕ Add Reminder
              </button>
            </div>

            {tab === 'active' && (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {alerts.length === 0 && (
                  <div className="text-center py-8 text-slate-400">
                    <Bell className="w-10 h-10 mx-auto mb-2 opacity-30"/>
                    <p className="text-sm">No reminders set. Add some from the templates!</p>
                  </div>
                )}
                {alerts.map(alert => (
                  <div key={alert.id} className={`flex items-center gap-3 p-3 rounded-2xl border-2 transition-all ${alert.active ? 'border-slate-200 bg-white' : 'border-slate-100 bg-slate-50 opacity-60'}`}>
                    <span className="text-xl">{alert.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm text-slate-800 truncate">{alert.title}</p>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full border font-bold ${typeColors[alert.type]}`}>{alert.type}</span>
                      </div>
                      <p className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3"/>{alert.time}</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => toggle(alert.id)} className={`w-8 h-5 rounded-full transition-all ${alert.active ? 'bg-green-400' : 'bg-slate-300'}`}>
                        <div className={`w-4 h-4 bg-white rounded-full shadow transition-transform mx-0.5 ${alert.active ? 'translate-x-3' : 'translate-x-0'}`}/>
                      </button>
                      <button onClick={() => remove(alert.id)} className="p-1 hover:bg-red-50 rounded-lg"><Trash2 className="w-3.5 h-3.5 text-red-400"/></button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === 'add' && (
              <div className="space-y-4">
                {/* Quick templates */}
                <div>
                  <p className="text-xs font-black text-slate-500 uppercase tracking-wide mb-2">Quick Add Templates</p>
                  <div className="grid grid-cols-2 gap-2">
                    {ALERT_TEMPLATES.map((t, i) => (
                      <button key={i} onClick={() => addTemplate(t)}
                        className="flex items-center gap-2 bg-slate-50 hover:bg-amber-50 border border-slate-200 hover:border-amber-300 rounded-xl p-2.5 text-left transition-all">
                        <span className="text-lg">{t.emoji}</span>
                        <div>
                          <p className="text-xs font-bold text-slate-700 leading-tight">{t.title}</p>
                          <p className="text-[10px] text-slate-400">{t.time}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom alert */}
                <div className="bg-slate-50 rounded-2xl p-4">
                  <p className="text-xs font-black text-slate-600 uppercase tracking-wide mb-3">Custom Reminder</p>
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Type</label>
                      <select value={customType} onChange={e => setCustomType(e.target.value as Alert['type'])} className="w-full text-sm bg-white border-2 border-slate-200 rounded-xl p-2 outline-none focus:border-amber-400 font-semibold">
                        <option value="hydration">💧 Hydration</option>
                        <option value="snack">🍎 Snack</option>
                        <option value="meal">🍽️ Meal</option>
                        <option value="activity">🏃 Activity</option>
                        <option value="vitamin">💊 Vitamin</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Time *</label>
                      <input type="time" value={customTime} onChange={e => setCustomTime(e.target.value)} className="w-full text-sm bg-white border-2 border-slate-200 rounded-xl p-2 outline-none focus:border-amber-400 font-bold"/>
                    </div>
                  </div>
                  <input type="text" value={customTitle} onChange={e => setCustomTitle(e.target.value)} placeholder="Reminder title *" className="w-full text-sm bg-white border-2 border-slate-200 rounded-xl p-2 outline-none focus:border-amber-400 mb-2 font-semibold"/>
                  <textarea value={customMsg} onChange={e => setCustomMsg(e.target.value)} placeholder="Message (optional)" rows={2} className="w-full text-sm bg-white border-2 border-slate-200 rounded-xl p-2 outline-none focus:border-amber-400 resize-none mb-2"/>
                  <button onClick={addCustom} disabled={!customTitle || !customTime} className="w-full py-2.5 bg-amber-500 text-white rounded-xl font-black text-sm hover:bg-amber-600 disabled:opacity-50">
                    ➕ Add Custom Reminder
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
