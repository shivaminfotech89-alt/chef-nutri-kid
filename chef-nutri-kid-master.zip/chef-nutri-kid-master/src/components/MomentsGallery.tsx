import React, { useState, useRef } from 'react';
import { X, Camera, Share2, Heart, Trash2, Star } from 'lucide-react';
import { freemium, store } from '../freemium';

interface Props { onClose: () => void; }

export default function MomentsGallery({ onClose }: Props) {
  const [gallery, setGallery] = useState<any[]>(() => freemium.getGallery());
  const [caption, setCaption] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const item = {
        base64: reader.result as string,
        caption: caption || `Nutri-Kid Moment 🍎`,
        name: file.name,
        liked: false,
      };
      freemium.addToGallery(item);
      setGallery(freemium.getGallery());
      setCaption('');
      if (fileRef.current) fileRef.current.value = '';
    };
    reader.readAsDataURL(file);
  };

  const toggleLike = (id: number) => {
    const g = gallery.map(i => i.id === id ? { ...i, liked: !i.liked } : i);
    store.set('cnk_gallery', g);
    setGallery(g);
  };

  const deleteItem = (id: number) => {
    const g = gallery.filter(i => i.id !== id);
    store.set('cnk_gallery', g);
    setGallery(g);
  };

  const shareToWhatsApp = (item: any) => {
    const msg = `🍎 My child's healthy meal moment with Chef Nutri-Kid! 🌟\n${item.caption}\n\nGet personalized kids meal plans at: chef-nutri-kid.netlify.app\n\n#ChefNutriKid #HealthyKids #NutriPedsAI`;
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 flex items-start justify-center p-4 z-50 overflow-y-auto pt-6 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-pink-200 w-full max-w-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-gradient-to-r from-pink-50 to-rose-50 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-pink-100 rounded-2xl flex items-center justify-center text-xl">📸</div>
            <div>
              <h2 className="text-lg font-black text-slate-800">Moments Gallery</h2>
              <p className="text-xs text-slate-400">{gallery.length} precious memories</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400"/></button>
        </div>

        <div className="p-5">
          {/* Upload section */}
          <div className="bg-gradient-to-r from-pink-50 to-rose-50 border-2 border-dashed border-pink-300 rounded-2xl p-5 mb-5 text-center">
            <div className="text-3xl mb-2">📷</div>
            <p className="text-sm font-black text-slate-700 mb-1">Capture Your Child's Healthy Moments!</p>
            <p className="text-xs text-slate-500 mb-3">Upload photos of meals, cooking adventures, and healthy snacks</p>
            <input
              type="text"
              value={caption}
              onChange={e => setCaption(e.target.value)}
              placeholder="Add a caption (e.g. Arjun loves his broccoli! 🥦)"
              className="w-full text-sm bg-white border-2 border-pink-200 rounded-xl px-3 py-2 outline-none focus:border-pink-400 mb-3 font-semibold"
            />
            <input ref={fileRef} type="file" accept="image/*" onChange={handleUpload} className="hidden" id="gallery-upload"/>
            <label htmlFor="gallery-upload" className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white px-5 py-2.5 rounded-xl font-black text-sm cursor-pointer hover:opacity-90 transition-all">
              <Camera className="w-4 h-4"/> Upload Photo
            </label>
          </div>

          {/* CTA Banner */}
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-200 rounded-2xl p-4 mb-5 flex items-center gap-3">
            <Star className="w-8 h-8 text-amber-500 shrink-0"/>
            <div>
              <p className="text-sm font-black text-amber-800">🎁 Share & Earn Bonus Days!</p>
              <p className="text-xs text-amber-700">Tag us on Instagram @ChefNutriKid with your child's healthy meal photo and get 7 FREE bonus days added to your plan!</p>
            </div>
          </div>

          {/* Gallery grid */}
          {gallery.length === 0 ? (
            <div className="text-center py-10">
              <div className="text-5xl mb-3">📷</div>
              <p className="text-slate-500 font-semibold text-sm">No moments yet!</p>
              <p className="text-slate-400 text-xs mt-1">Upload your first healthy meal photo above 😊</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {gallery.map(item => (
                <div key={item.id} className="relative group rounded-2xl overflow-hidden border-2 border-slate-100 bg-slate-50">
                  <img src={item.base64} alt={item.caption} className="w-full h-36 object-cover"/>
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-all">
                    <div className="absolute bottom-0 left-0 right-0 p-2">
                      <p className="text-white text-xs font-bold truncate">{item.caption}</p>
                      <div className="flex gap-1.5 mt-1.5">
                        <button onClick={() => toggleLike(item.id)} className={`p-1.5 rounded-lg ${item.liked ? 'bg-red-500' : 'bg-white/20'} text-white`}>
                          <Heart className="w-3 h-3"/>
                        </button>
                        <button onClick={() => shareToWhatsApp(item)} className="p-1.5 rounded-lg bg-green-500 text-white">
                          <Share2 className="w-3 h-3"/>
                        </button>
                        <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded-lg bg-red-500/80 text-white">
                          <Trash2 className="w-3 h-3"/>
                        </button>
                      </div>
                    </div>
                  </div>
                  {item.liked && <div className="absolute top-2 right-2 text-red-500 text-lg">❤️</div>}
                  <div className="p-2">
                    <p className="text-xs text-slate-600 font-semibold truncate">{item.caption}</p>
                    <p className="text-[10px] text-slate-400">{new Date(item.date).toLocaleDateString('en-IN')}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
