// ─────────────────────────────────────────────
// Chef Nutri-Kid — Types (re-exports from data.ts)
// Keeps backward compat while data lives in data.ts
// ─────────────────────────────────────────────
export type {
  DietaryPreference,
  OptimizationGoal,
  AgeBucket,
  FoodItem,
  GrowthEntry,
  DailyLog,
  ChildProfile,
  AlertItem,
  Recipe,
  HealthReport,
  DailyMeal,
  WeeklyChart,
} from './data';

export {
  getNutritionTargets,
  getAgeBucket,
  getWeeklyFallback,
  AGE_BUCKET_META,
  PRESET_INGREDIENTS,
  COMMON_INGREDIENTS_DB,
} from './data';

// Legacy alias
export type { AlertItem as Alert } from './data';

export type AgeGroup = '1-3 years (Toddler)' | '4-5 years (Preschooler)' | '6-12 years (School Age)';
