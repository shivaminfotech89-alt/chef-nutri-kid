// ─────────────────────────────────────────────
// Chef Nutri-Kid — Static Data Module
// Self-contained, zero circular imports
// All large constants live here to prevent
// temporal dead zone (TDZ) hoisting errors
// ─────────────────────────────────────────────

export type DietaryPreference =
  | 'Any / No Restriction'
  | 'Vegetarian'
  | 'Non-Vegetarian'
  | 'Vegan'
  | 'Eggetarian'
  | 'Jain'
  | 'Celiac (Gluten-Free)';

export type OptimizationGoal =
  | 'Boost Immunity'
  | 'Enhance Weight Gain'
  | 'Maximize Iron'
  | 'Brain Development'
  | 'Bone Strength'
  | 'Balanced Growth';

export type AgeBucket = 'toddler' | 'schooler' | 'preteen';

export interface FoodItem {
  id: string;
  name: string;
  emoji: string;
  category: 'fruitsVeggies' | 'wholeGrains' | 'strongProtein' | 'fatsHydrates';
  color: string;
}

export interface GrowthEntry {
  date: string;
  weight: number;
  height: number;
  bmi: number;
  notes?: string;
}

export interface DailyLog {
  date: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  iron: number;
  calcium: number;
  water: number;
  meals: string[];
}

export interface ChildProfile {
  id: string;
  name: string;
  dob: string;
  age: number;
  ageMonths: number;
  ageDays: number;
  ageDisplay: string;
  gender?: 'Boy' | 'Girl';
  weight: number;
  height: number;
  photo?: string;
  foodCategories: DietaryPreference;
  allergies: string[];
  createdAt: string;
  isLocked: boolean;
  growthHistory: GrowthEntry[];
  dailyLogs: DailyLog[];
  targetCalories: number;
  targetProtein: number;
  targetIron: number;
  targetCalcium: number;
}

export interface AlertItem {
  id: string;
  type: 'hydration' | 'snack' | 'meal' | 'activity' | 'vitamin';
  title: string;
  message: string;
  time: string;
  active: boolean;
  emoji: string;
}

export interface Recipe {
  mealName: string;
  plateBreakdown: {
    fruitsVeggies: string;
    wholeGrains: string;
    strongProtein: string;
    fatsHydrates: string;
  };
  nutritionalFocus?: string;
  allergyCheck?: string;
  medicalDisclaimer?: string;
  instructions: string[];
  juniorDuties: string[];
  powerMealFact: string;
  moveChallenge: string;
  tutorialQuery: string;
  dietIndicator: string;
  optimizationGoal?: string;
  nutrition: {
    calories: number;
    protein: string;
    carbs: string;
    fat: string;
    fiber: string;
    iron?: string;
    calcium?: string;
    vitaminC?: string;
    keyVitamins: string;
  };
}

export interface HealthReport {
  reportTitle: string;
  ageGroup: string;
  weightStatus: string;
  bmiNote: string;
  dailyCalories: number;
  dailyProtein: string;
  dailyCalcium: string;
  dailyIron: string;
  keyRecommendations: string[];
  foodsToEat: string[];
  foodsToLimit: string[];
  sampleDayPlan: {
    breakfast: string;
    morningSnack: string;
    lunch: string;
    eveningSnack: string;
    dinner: string;
  };
  growthTip: string;
  healthSummary?: string;
  growthChartAnalysis?: string;
  proactivePlateStrategy?: string[];
  allergySafetyShield?: string;
  milestoneTracker?: string;
  medicalDisclaimer: string;
  childName?: string;
}

export interface DailyMeal {
  day: string;
  breakfast: string;
  morningSnack: string;
  lunch: string;
  eveningSnack: string;
  dinner: string;
  powerFact: string;
}

export interface WeeklyChart {
  meals: DailyMeal[];
  groceryList: string[];
  weeklyTip: string;
}

// ── Nutrition targets by age ──
export function getNutritionTargets(ageYears: number) {
  if (ageYears < 1)  return { calories: 800,  protein: 11, iron: 11, calcium: 260  };
  if (ageYears <= 3) return { calories: 1000, protein: 13, iron: 7,  calcium: 700  };
  if (ageYears <= 5) return { calories: 1200, protein: 19, iron: 10, calcium: 1000 };
  if (ageYears <= 8) return { calories: 1400, protein: 20, iron: 10, calcium: 1000 };
  return              { calories: 1800, protein: 34, iron: 8,  calcium: 1300 };
}

export function getAgeBucket(ageYears: number): AgeBucket {
  if (ageYears <= 4) return 'toddler';
  if (ageYears <= 8) return 'schooler';
  return 'preteen';
}

// ── Age bucket metadata ──
export const AGE_BUCKET_META = {
  toddler:  { label: 'Toddler Engine',    ages: '2–4 yrs',  emoji: '🍼', focus: 'Soft textures, bite-sized, easy digestion',           color: 'bg-pink-50 border-pink-200',   accent: 'text-pink-700',   badge: 'bg-pink-100 text-pink-700'   },
  schooler: { label: 'Early Schooler',    ages: '5–8 yrs',  emoji: '🎒', focus: 'Micronutrient rich, brain development, iron focus',    color: 'bg-blue-50 border-blue-200',   accent: 'text-blue-700',   badge: 'bg-blue-100 text-blue-700'   },
  preteen:  { label: 'Pre-Teen Booster',  ages: '9–12 yrs', emoji: '💪', focus: 'High caloric density, growth spurts, bone density',   color: 'bg-purple-50 border-purple-200', accent: 'text-purple-700', badge: 'bg-purple-100 text-purple-700' },
} as const;

// ── Preset ingredient grid ──
export const PRESET_INGREDIENTS: FoodItem[] = [
  { id: 'broccoli',         name: 'Broccoli',        emoji: '🥦', category: 'fruitsVeggies', color: 'bg-emerald-100 border-emerald-300 text-emerald-800' },
  { id: 'carrots',          name: 'Carrots',          emoji: '🥕', category: 'fruitsVeggies', color: 'bg-orange-100 border-orange-300 text-orange-800'   },
  { id: 'spinach',          name: 'Spinach',          emoji: '🥬', category: 'fruitsVeggies', color: 'bg-green-100 border-green-300 text-green-800'     },
  { id: 'apples',           name: 'Apples',           emoji: '🍎', category: 'fruitsVeggies', color: 'bg-red-100 border-red-300 text-red-800'           },
  { id: 'tomatoes',         name: 'Tomatoes',         emoji: '🍅', category: 'fruitsVeggies', color: 'bg-red-100 border-red-300 text-red-800'           },
  { id: 'sweet_potato',     name: 'Sweet Potato',     emoji: '🍠', category: 'fruitsVeggies', color: 'bg-amber-100 border-amber-300 text-amber-800'     },
  { id: 'pepper',           name: 'Bell Pepper',      emoji: '🫑', category: 'fruitsVeggies', color: 'bg-green-100 border-green-300 text-green-800'     },
  { id: 'berries',          name: 'Berries',          emoji: '🍓', category: 'fruitsVeggies', color: 'bg-rose-100 border-rose-300 text-rose-800'        },
  { id: 'avocado',          name: 'Avocado',          emoji: '🥑', category: 'fatsHydrates',  color: 'bg-lime-100 border-lime-300 text-lime-800'        },
  { id: 'brown_rice',       name: 'Brown Rice',       emoji: '🍚', category: 'wholeGrains',   color: 'bg-amber-50 border-amber-200 text-amber-800'      },
  { id: 'whole_wheat_bread',name: 'Whole Wheat Bread',emoji: '🍞', category: 'wholeGrains',   color: 'bg-yellow-100 border-yellow-300 text-yellow-800'  },
  { id: 'oats',             name: 'Oats',             emoji: '🥣', category: 'wholeGrains',   color: 'bg-amber-100 border-amber-200 text-amber-800'     },
  { id: 'quinoa',           name: 'Quinoa',           emoji: '🌾', category: 'wholeGrains',   color: 'bg-amber-50 border-amber-300 text-amber-800'      },
  { id: 'whole_pasta',      name: 'Wheat Pasta',      emoji: '🍝', category: 'wholeGrains',   color: 'bg-yellow-50 border-yellow-200 text-yellow-800'   },
  { id: 'chicken',          name: 'Chicken Breast',   emoji: '🍗', category: 'strongProtein', color: 'bg-rose-50 border-rose-200 text-rose-800'         },
  { id: 'eggs',             name: 'Eggs',             emoji: '🥚', category: 'strongProtein', color: 'bg-stone-100 border-stone-300 text-stone-800'     },
  { id: 'salmon',           name: 'Salmon',           emoji: '🐟', category: 'strongProtein', color: 'bg-sky-50 border-sky-200 text-sky-800'            },
  { id: 'chickpeas',        name: 'Chickpeas',        emoji: '🫘', category: 'strongProtein', color: 'bg-yellow-100 border-yellow-300 text-yellow-800'  },
  { id: 'tofu',             name: 'Tofu',             emoji: '🟧', category: 'strongProtein', color: 'bg-neutral-100 border-neutral-300 text-neutral-800'},
  { id: 'yogurt',           name: 'Greek Yogurt',     emoji: '🥛', category: 'strongProtein', color: 'bg-blue-50 border-blue-200 text-blue-800'         },
  { id: 'olive_oil',        name: 'Olive Oil',        emoji: '🫗', category: 'fatsHydrates',  color: 'bg-lime-50 border-lime-200 text-lime-800'         },
  { id: 'walnuts',          name: 'Walnuts',          emoji: '🥜', category: 'fatsHydrates',  color: 'bg-amber-100 border-amber-300 text-amber-800'     },
  { id: 'seeds',            name: 'Chia Seeds',       emoji: '🌱', category: 'fatsHydrates',  color: 'bg-green-50 border-green-200 text-green-800'      },
  { id: 'water',            name: 'Fresh Water',      emoji: '💧', category: 'fatsHydrates',  color: 'bg-sky-100 border-sky-300 text-sky-800'           },
];

// ── Ingredient search database ──
export const COMMON_INGREDIENTS_DB: string[] = [
  // Fruits
  'Apple','Avocado','Banana','Blueberries','Cherry','Coconut','Custard Apple','Dates','Dragon Fruit','Figs','Grapes','Grapefruit','Guava','Honeydew','Jackfruit','Jamun','Kiwi','Lemon','Lime','Lychee','Mango','Melon','Mulberry','Orange','Papaya','Peach','Pear','Pineapple','Plum','Pomegranate','Raspberry','Sapota','Starfruit','Strawberries','Tangerine','Watermelon','Cantaloupe','Amla','Karonda','Bael','Tamarind',
  // Vegetables
  'Artichoke','Asparagus','Baby Corn','Bell Pepper','Bitter Gourd','Bok Choy','Bottle Gourd','Broccoli','Brussels Sprouts','Cabbage','Capsicum','Carrots','Cauliflower','Celery','Chili Pepper','Cluster Beans','Corn','Cucumber','Drumstick','Eggplant','Flat Beans','Garlic','Ginger','Green Beans','Ivy Gourd','Kale','Leek','Lettuce','Mushrooms','Okra','Onion','Pointed Gourd','Potatoes','Pumpkin','Radish','Raw Banana','Raw Papaya','Ridge Gourd','Scallion','Shallot','Snake Gourd','Spinach','Spring Onion','Squash','Sweet Potato','Taro Root','Tomatoes','Turnip','Yam','Zucchini','Beetroot','Lotus Root','Colocasia','Arrowroot','Moringa Leaves','Fenugreek Leaves','Mustard Leaves','Curry Leaves','Mint Leaves','Coriander Leaves','Amaranth Leaves','Bathua','Sarson','Suran',
  // Lentils & Pulses
  'Black Eyed Peas','Black Lentils','Chickpeas','Chana Dal','Green Moong Dal','Horse Gram','Kidney Beans','Lentils','Masoor Dal','Moong Dal','Peas','Pigeon Peas','Pinto Beans','Rajma','Soya Beans','Toor Dal','Urad Dal','White Peas','Yellow Moong Dal','Moth Beans','Val Dal','Chawli',
  // Grains
  'Basmati Rice','Brown Rice','Broken Wheat','Corn Flour','Dalia','Jowar','Maize','Millet','Oats','Poha','Quinoa','Ragi','Rice','Sabudana','Semolina','Suji','Wheat','White Rice','Wheat Pasta','Whole Wheat Bread','Bajra','Barley','Amaranth','Buckwheat','Corn Starch','Idli Rice',
  // Flours
  'All Purpose Flour','Almond Flour','Besan','Coconut Flour','Maida','Rajgira Flour','Rice Flour','Ragi Flour','Wheat Flour','Jowar Flour','Bajra Flour','Nachni Flour','Kuttu Flour',
  // Dairy & Protein
  'Butter','Buttermilk','Cheddar Cheese','Cheese','Chicken Breast','Chicken Curry Cut','Chicken Legs','Chicken Thighs','Condensed Milk','Cottage Cheese','Cream','Cream Cheese','Eggs','Fish','Greek Yogurt','Hung Curd','Khoya','Milk','Mozzarella','Mutton','Paneer','Pork','Prawns','Rohu Fish','Salmon','Sardines','Shrimp','Tofu','Tuna','Turkey','Whey Protein','Yogurt','Curd','Dahi','Malai',
  // Nuts & Seeds
  'Almonds','Cashews','Chia Seeds','Flax Seeds','Hemp Seeds','Macadamia','Melon Seeds','Peanut Butter','Peanuts','Pecans','Pine Nuts','Pistachios','Pumpkin Seeds','Sesame Seeds','Sunflower Seeds','Walnuts','Charoli','Fox Nuts','Makhana','Watermelon Seeds',
  // Oils
  'Coconut Oil','Ghee','Groundnut Oil','Mustard Oil','Olive Oil','Rice Bran Oil','Sesame Oil','Sunflower Oil','Til Oil',
  // Spices
  'Ajwain','Asafoetida','Bay Leaf','Black Pepper','Black Salt','Cardamom','Chaat Masala','Cinnamon','Cloves','Coriander Powder','Cumin','Cumin Powder','Curry Powder','Dried Mango Powder','Fenugreek Seeds','Garam Masala','Green Cardamom','Hing','Jeera','Kashmiri Red Chili','Kesar','Mace','Mustard Seeds','Nutmeg','Oregano','Paprika','Pepper Powder','Red Chili Powder','Saffron','Salt','Star Anise','Turmeric','White Pepper','Thyme','Basil','Rosemary','Amchur','Sambar Powder','Rasam Powder','Biryani Masala','Pav Bhaji Masala',
  // Condiments
  'Coconut Milk','Green Chutney','Honey','Imli','Ketchup','Mayonnaise','Mustard','Soy Sauce','Tamarind Paste','Tomato Puree','Vinegar','Worcestershire Sauce','Peanut Chutney','Mint Chutney',
  // Sweeteners
  'Brown Sugar','Coconut Sugar','Jaggery','Mishri','Stevia','Sugar','Maple Syrup','Gud',
  // Indian meals (for routine enhancement)
  'Khichdi','Upma','Daliya','Poha','Idli','Dosa','Roti','Paratha','Thepla','Dhokla','Handvo','Methi Thepla','Bajra Rotla','Jowar Bhakri','Dal Fry','Palak Paneer','Rajma','Chole',
  // Others
  'Cocoa Powder','Coffee','Fresh Water','Green Tea','Rose Water','Vanilla Extract','Baking Powder','Baking Soda','Cornflour','Dark Chocolate','Dry Fruits Mix','Gelatin','Yeast',
];

// ── 3-Week fallback meal matrix ──
type MealDay = { day: string; breakfast: string; morningSnack: string; lunch: string; eveningSnack: string; dinner: string; powerFact: string; };

export const WEEKLY_FALLBACK: Record<AgeBucket, MealDay[][]> = {
  toddler: [
    [
      { day:'Monday',    breakfast:'Soft idli (2) + mild sambar (½ cup)',                        morningSnack:'Mashed banana + honey',          lunch:'Khichdi (½ cup) + ghee + mashed carrot',        eveningSnack:'Warm milk (½ cup) + 2 marie biscuits',          dinner:'Soft roti (1) + dal (½ cup) + mashed potato',          powerFact:'🍌 Bananas give quick energy to run and play!' },
      { day:'Tuesday',   breakfast:'Soft oats (½ cup) + milk + mashed apple',                   morningSnack:'½ cup yogurt + fruit puree',      lunch:'Veg khichdi (½ cup) + ghee',                    eveningSnack:'Steamed sweet potato cubes (½ cup)',             dinner:'Paneer cubes (50g soft) + soft roti + dal',            powerFact:'🥕 Carrots make your eyes sparkle and bright!' },
      { day:'Wednesday', breakfast:'Rava upma (soft, ½ cup) + grated veggies',                  morningSnack:'½ ripe mango or papaya',          lunch:'Moong dal (½ cup) + soft rice + pumpkin sabzi', eveningSnack:'Warm milk (½ cup) + banana',                     dinner:'Soft roti + palak dal (½ cup)',                        powerFact:'🥬 Spinach gives you strong bones and good blood!' },
      { day:'Thursday',  breakfast:'Soft dosa (1 small) + coconut chutney',                     morningSnack:'Watermelon chunks (½ cup)',        lunch:'Dal rice (½ cup) + mashed beetroot',            eveningSnack:'Warm milk + 2 soaked almonds (crushed)',         dinner:'Egg scramble (1 egg) + roti + dal',                    powerFact:'🥚 Eggs help your brain grow big and smart!' },
      { day:'Friday',    breakfast:'Poha (½ cup soft) + peas',                                  morningSnack:'Stewed apple (½ cup)',             lunch:'Rajma (½ cup mashed) + rice + ghee',           eveningSnack:'½ cup yogurt + soft fruit',                      dinner:'Soft roti + mixed veg sabzi + dal',                    powerFact:'🫘 Dal and beans make your muscles strong!' },
      { day:'Saturday',  breakfast:'Sabudana khichdi (½ cup soft)',                             morningSnack:'½ ripe pear mashed',              lunch:'Vegetable khichdi + curd (¼ cup)',              eveningSnack:'Warm milk with pinch turmeric',                  dinner:'Paneer bhurji (50g soft) + roti',                      powerFact:'🥛 Milk makes your bones strong like a superhero!' },
      { day:'Sunday',    breakfast:'Soft besan cheela (1) + yogurt',                            morningSnack:'Fresh papaya (½ cup)',             lunch:'Special soft khichdi + all veggies + ghee',    eveningSnack:'Banana milkshake (½ cup)',                       dinner:'Soft roti + dal + mashed sweet potato',               powerFact:'🌟 Every healthy bite makes you grow taller!' },
    ],
    [
      { day:'Monday',    breakfast:'Ragi porridge (¼ cup) + milk + banana',                     morningSnack:'Mashed avocado on soft toast',    lunch:'Toor dal (½ cup) + soft rice + boiled carrot',  eveningSnack:'Warm milk + date paste',                         dinner:'Soft roti + egg curry (1 egg) + veg',                  powerFact:'🌾 Ragi has more calcium than milk!' },
      { day:'Tuesday',   breakfast:'Soft moong cheela (1) + curd',                              morningSnack:'Soft cooked pear chunks',          lunch:'Palak khichdi (½ cup) + ghee',                  eveningSnack:'Warm milk + crushed almonds',                    dinner:'Paneer in mild gravy + soft roti',                     powerFact:'🧠 Paneer helps your brain learn new things!' },
      { day:'Wednesday', breakfast:'Soft idli (2) + tomato chutney',                            morningSnack:'Mashed banana + honey',           lunch:'Moong dal soup + soft rice',                    eveningSnack:'Steamed corn + butter (¼ cup)',                  dinner:'Soft roti + dal fry + mashed pumpkin',                 powerFact:'🎃 Pumpkin gives Vitamin A for healthy eyes!' },
      { day:'Thursday',  breakfast:'Soft oatmeal + stewed apple',                               morningSnack:'Yogurt + fruit puree (½ cup)',     lunch:'Veg khichdi + ghee (½ cup)',                    eveningSnack:'Warm turmeric milk',                             dinner:'1 egg scramble + soft roti + dal',                     powerFact:'💛 Turmeric milk is a magic healing drink!' },
      { day:'Friday',    breakfast:'Rava idli (2 small) + sambar',                              morningSnack:'Mango puree (¼ cup)',              lunch:'Dal rice + steamed broccoli mash',              eveningSnack:'Milk + crushed nuts',                            dinner:'Soft roti + rajma (½ cup mashed) + curd',              powerFact:'🥦 Broccoli is a superfood — eat and be a hero!' },
      { day:'Saturday',  breakfast:'Soft upma + vegetables + ghee',                             morningSnack:'Papaya chunks (½ cup)',            lunch:'Khichdi + soft sabzi + curd',                   eveningSnack:'Banana milkshake (½ cup)',                       dinner:'Paneer + vegetable soft curry + roti',                 powerFact:'🍌 Bananas give potassium for a healthy heart!' },
      { day:'Sunday',    breakfast:'Soft besan cheela + yogurt + fruit',                        morningSnack:'Mixed fruit puree (½ cup)',        lunch:'Special thali — dal, soft sabzi, rice, roti',   eveningSnack:'Warm milk + 1 tsp honey',                       dinner:'Egg rice (1 egg) or paneer rice + dal soup',           powerFact:'🌈 Eating different colors keeps doctor away!' },
    ],
    [
      { day:'Monday',    breakfast:'Dalia porridge (½ cup) + milk',                             morningSnack:'Steamed sweet potato mash',        lunch:'Moong dal + soft rice + ghee',                  eveningSnack:'Warm milk + banana',                            dinner:'Soft roti + spinach dal + paneer',                     powerFact:'💚 Broken wheat gives energy all day!' },
      { day:'Tuesday',   breakfast:'Soft oats + pear puree',                                    morningSnack:'½ cup yogurt + fruit',             lunch:'Khichdi + mashed carrot + ghee',                eveningSnack:'Warm turmeric milk',                            dinner:'Egg curry (1) + soft roti',                            powerFact:'🐣 Eggs build every cell in your body!' },
      { day:'Wednesday', breakfast:'Rava kheer (½ cup) + milk',                                 morningSnack:'Watermelon (½ cup)',               lunch:'Toor dal + rice + boiled veggies',               eveningSnack:'Milk + crushed almonds (4)',                     dinner:'Paneer bhurji + soft roti + dal',                      powerFact:'🍉 Watermelon keeps you hydrated and glowing!' },
      { day:'Thursday',  breakfast:'Ragi dosa (1 small) + coconut chutney',                     morningSnack:'Mashed avocado',                   lunch:'Palak rice + curd + ghee',                      eveningSnack:'Banana smoothie (½ cup)',                        dinner:'1 egg + soft roti + mixed dal',                        powerFact:'💪 Ragi is a superfood grain for little champions!' },
      { day:'Friday',    breakfast:'Soft idli (2) + mild sambar',                               morningSnack:'Orange segments (seedless)',        lunch:'Rajma (½ cup soft) + rice',                     eveningSnack:'Warm milk + date',                              dinner:'Soft roti + vegetables + dal',                         powerFact:'🍊 Orange gives Vitamin C to fight colds!' },
      { day:'Saturday',  breakfast:'Moong cheela (1) + yogurt',                                 morningSnack:'Stewed pear or apple',             lunch:'Mixed vegetable khichdi + ghee',                eveningSnack:'Milk + crushed nuts',                           dinner:'Paneer + soft sabzi + roti',                           powerFact:'🌟 Every meal makes you grow 1mm taller!' },
      { day:'Sunday',    breakfast:'Soft poha + veggies + ghee',                                morningSnack:'Fruit bowl (soft seasonal)',        lunch:'Grand khichdi + all vegetables + curd',         eveningSnack:'Turmeric milk',                                 dinner:'Egg rice or paneer rice + dal soup',                   powerFact:'🎉 You are amazing for eating so healthy!' },
    ],
  ],
  schooler: [
    [
      { day:'Monday',    breakfast:'Oats (½ cup) + milk + banana',                              morningSnack:'1 apple + 5 almonds',              lunch:'Dal (½ cup) + rice + salad + ghee',             eveningSnack:'1 cup milk + 2 whole wheat biscuits',           dinner:'2 rotis + mixed veg sabzi + curd',                     powerFact:'🥦 Colorful veggies give you rainbow superpowers!' },
      { day:'Tuesday',   breakfast:'Veg upma (1 cup semolina) + peas + carrots',               morningSnack:'1 orange + peanuts (1 tbsp)',       lunch:'Khichdi (¾ cup) + curd + pickle',               eveningSnack:'Seasonal fruit chaat',                           dinner:'Paneer sabzi (100g) + 2 rotis + salad',                powerFact:'🥕 Carrots are brain food for better study!' },
      { day:'Wednesday', breakfast:'Poha (1.5 cups) + vegetables + lemon',                     morningSnack:'Banana smoothie (1 banana + milk)', lunch:'Rajma (½ cup) + brown rice + onion rings',     eveningSnack:'Boiled corn + butter + lemon',                   dinner:'2 eggs curry + 2 rotis + salad',                       powerFact:'🫘 Rajma gives super energy for school sports!' },
      { day:'Thursday',  breakfast:'2 moong dal cheela + green chutney + curd',                morningSnack:'Watermelon (2 cups)',               lunch:'Palak paneer + ½ cup rice + roti',              eveningSnack:'½ cup roasted makhana',                         dinner:'Veg soup + 2 rotis + dal',                             powerFact:'🥬 Spinach iron makes your blood super healthy!' },
      { day:'Friday',    breakfast:'3 idlis + sambar (1 cup) + coconut chutney',               morningSnack:'Mixed fruit bowl',                  lunch:'Chole (½ cup) + brown rice + salad',            eveningSnack:'Sweet potato chaat',                             dinner:'Grilled chicken/tofu (100g) + salad + roti',           powerFact:'🐟 Protein builds every muscle in your body!' },
      { day:'Saturday',  breakfast:'2 methi parathas + curd + pickle',                         morningSnack:'Coconut water + 1 banana',          lunch:'Mixed dal (½ cup) + 2 rotis + vegetables',     eveningSnack:'2 pieces dhokla + green chutney',                dinner:'Veg pulao (1 cup) + raita + papad',                    powerFact:'🥛 Calcium in dairy makes your bones unbreakable!' },
      { day:'Sunday',    breakfast:'2 besan cheela + tomato chutney + curd',                   morningSnack:'Fresh juice + mixed nuts',          lunch:'Special thali — dal, sabzi, rice, roti, curd',  eveningSnack:'Fruit salad + honey + chia seeds',              dinner:'Dal makhani (½ cup) + 2 rotis + salad',                powerFact:'🌟 Healthy kids become world champions!' },
    ],
    [
      { day:'Monday',    breakfast:'Dalia upma (1 cup) + veg + ghee',                          morningSnack:'1 pear + walnuts (4)',              lunch:'Chana dal (½ cup) + rice + spinach sabzi',      eveningSnack:'1 cup milk + banana',                           dinner:'2 rotis + egg bhurji (2 eggs) + salad',                powerFact:'🧠 Walnuts look like brains — they feed yours!' },
      { day:'Tuesday',   breakfast:'Ragi roti (2) + peanut butter',                            morningSnack:'Papaya + pumpkin seeds',            lunch:'Rajma (½ cup) + brown rice + raita',            eveningSnack:'Roasted chana + jaggery',                       dinner:'Paneer tikka (100g) + 2 rotis + salad',                powerFact:'💪 Ragi calcium is best for growing bones!' },
      { day:'Wednesday', breakfast:'Veg dosa (2 small) + sambar',                              morningSnack:'1 banana + milk (1 cup)',           lunch:'Mixed veg khichdi (1 cup) + curd',              eveningSnack:'Makhana with mild spices',                       dinner:'Chicken/tofu curry (100g) + 2 rotis',                  powerFact:'🥚 Eggs every day keep sickness far away!' },
      { day:'Thursday',  breakfast:'Oat pancakes (2) + honey + fruit',                         morningSnack:'Orange + almonds (5)',              lunch:'Palak dal (½ cup) + rice + sabzi',              eveningSnack:'Peanut butter on whole wheat toast',             dinner:'2 rotis + mixed dal + veg + curd',                     powerFact:'🍊 Vitamin C helps absorb iron from dal!' },
      { day:'Friday',    breakfast:'Upma (1 cup) + coconut + curry leaves',                    morningSnack:'Apple + cheese slice',              lunch:'Chole (½ cup) + roti + cucumber salad',         eveningSnack:'Sweet potato boiled + salt',                     dinner:'Fish/paneer (100g) + rice + dal soup',                 powerFact:'🐠 Fish omega-3 makes you incredibly smart!' },
      { day:'Saturday',  breakfast:'Stuffed paratha (2) + curd',                               morningSnack:'Pomegranate seeds (½ cup)',         lunch:'Dal fry + rice + veg sabzi + salad',            eveningSnack:'Dhokla (3 pieces) + mint chutney',              dinner:'Veg biryani (1 cup) + raita',                          powerFact:'💎 Pomegranate is packed with antioxidants!' },
      { day:'Sunday',    breakfast:'Idli (3) + veg sambar + chutney',                          morningSnack:'Fresh fruit bowl + seeds',          lunch:'Grand healthy thali with 6 items',               eveningSnack:'Homemade energy balls (oats + nuts)',            dinner:'Palak paneer + brown rice + dal',                      powerFact:'🌈 Every color on plate is a vitamin!' },
    ],
    [
      { day:'Monday',    breakfast:'Multigrain toast (2) + 2 boiled eggs + fruit',             morningSnack:'Handful trail mix (nuts + seeds)',  lunch:'Moong dal (½ cup) + rice + bhindi sabzi',       eveningSnack:'1 cup milk + dates (2)',                         dinner:'2 rotis + paneer curry + salad',                       powerFact:'🌾 Multigrain bread gives 4 hours of energy!' },
      { day:'Tuesday',   breakfast:'Veg paratha (2) + mint chutney',                           morningSnack:'Watermelon + seeds',               lunch:'Rajma (½ cup) + roti + veg raita',              eveningSnack:'Sprouts chaat (½ cup)',                          dinner:'Egg fried rice (1 cup) + dal soup',                    powerFact:'🌱 Sprouts have 10x more nutrients than seeds!' },
      { day:'Wednesday', breakfast:'Besan cheela (2) + tomato chutney',                        morningSnack:'Banana + peanut butter',            lunch:'Palak rice + curd + pickle',                    eveningSnack:'Roasted peanuts + jaggery',                      dinner:'Chicken curry (100g) + 2 rotis + salad',               powerFact:'🥜 Peanuts are nature\'s protein bombs!' },
      { day:'Thursday',  breakfast:'Poha (1.5 cups) + groundnuts + lemon',                     morningSnack:'Apple + almonds (6)',               lunch:'Toor dal + rice + mixed veg sabzi',             eveningSnack:'Milk + banana smoothie',                         dinner:'Paneer + roti + dal soup + salad',                     powerFact:'🍋 Lemon juice helps iron enter your blood!' },
      { day:'Friday',    breakfast:'Ragi dosa (2) + coconut chutney',                          morningSnack:'Guava + pumpkin seeds',             lunch:'Chole (½ cup) + brown rice + onion salad',     eveningSnack:'Makhana (½ cup) + spices',                       dinner:'Fish/tofu (100g) + roti + veg curry',                  powerFact:'🐟 Eating fish makes you stronger and sharper!' },
      { day:'Saturday',  breakfast:'Oats idli (2) + sambar + chutney',                         morningSnack:'Mixed fruit bowl',                  lunch:'Dal makhani + roti + sabzi + salad',             eveningSnack:'Whole wheat crackers + hummus',                  dinner:'Biryani (1 cup veg/chicken) + raita',                  powerFact:'🌟 Strong muscles need protein every meal!' },
      { day:'Sunday',    breakfast:'Egg bhurji (2 eggs) + paratha (2)',                         morningSnack:'Fresh fruit juice + nuts',          lunch:'Sunday special thali — full balanced meal',      eveningSnack:'Homemade laddoo (1, oats/nuts)',                  dinner:'Dal + roti + paneer sabzi + curd + salad',             powerFact:'🏆 You are a healthy eating champion!' },
    ],
  ],
  preteen: [
    [
      { day:'Monday',    breakfast:'Oats (¾ cup) + milk + 2 eggs + banana',                   morningSnack:'Trail mix (almonds+walnuts+raisins 30g)', lunch:'Dal (¾ cup) + brown rice + sabzi + curd',    eveningSnack:'1.5 cups milk + 2 biscuits + fruit',     dinner:'3 rotis + veg curry + dal + salad',                    powerFact:'💪 Pre-teens need 35g protein daily for growth spurt!' },
      { day:'Tuesday',   breakfast:'Multigrain paratha (2) + paneer bhurji (100g)',            morningSnack:'Peanut butter toast + banana',           lunch:'Rajma (¾ cup) + brown rice + raita + salad', eveningSnack:'1 cup milk + 8 almonds + 3 dates',       dinner:'Chicken/paneer curry (150g) + 3 rotis + salad',        powerFact:'🦴 Calcium peak absorption happens 9-12 years!' },
      { day:'Wednesday', breakfast:'3 eggs any style + whole wheat toast (2)',                 morningSnack:'Greek yogurt (1 cup) + mixed seeds',     lunch:'Chole (¾ cup) + roti + onion salad + lime',  eveningSnack:'Protein smoothie — milk+banana+peanut butter', dinner:'3 rotis + mixed dal + mixed veg sabzi',                powerFact:'🥚 3 eggs give all 9 essential amino acids!' },
      { day:'Thursday',  breakfast:'Dalia + milk (¾ cup) + 2 boiled eggs',                    morningSnack:'Fruit bowl + pumpkin seeds (1 tbsp)',     lunch:'Palak paneer (1 cup) + brown rice + roti',   eveningSnack:'Cheese sandwich (whole wheat) + milk',   dinner:'Fish/tofu (150g) + 2 rotis + dal + salad',             powerFact:'🧠 DHA in fish grows your brain faster!' },
      { day:'Friday',    breakfast:'Ragi porridge (¾ cup) + milk + banana + nuts',            morningSnack:'Sprouts chaat (1 cup) + lemon',          lunch:'Chicken biryani or veg pulao (1 cup) + raita',eveningSnack:'1 cup milk + homemade energy bar',       dinner:'Paneer + dal + 3 rotis + sabzi + salad',               powerFact:'🌾 Ragi has more calcium than milk!' },
      { day:'Saturday',  breakfast:'Stuffed paratha (3) + curd + fruit',                      morningSnack:'Nuts and seeds mix + orange juice',      lunch:'Dal makhani (¾ cup) + roti + sabzi + salad', eveningSnack:'Peanut butter banana toast + milk',      dinner:'Chicken/paneer curry (150g) + rice + dal + salad',     powerFact:'💥 Growth spurt needs 500mg extra calcium daily!' },
      { day:'Sunday',    breakfast:'Full cooked breakfast — 3 eggs + toast + fruit + milk',   morningSnack:'Smoothie bowl — milk + fruits + seeds',  lunch:'Grand healthy thali — full balanced',         eveningSnack:'Homemade protein laddoo (2)',             dinner:'Special dinner — paneer/chicken + biryani + raita',    powerFact:'🚀 You are in the biggest growth phase — fuel it!' },
    ],
    [
      { day:'Monday',    breakfast:'Egg bhurji (3 eggs) + whole wheat roti (2)',              morningSnack:'Peanut butter + apple slices',           lunch:'Moong dal (¾ cup) + rice + palak sabzi + curd', eveningSnack:'Milk (1.5 cups) + nuts + dates',        dinner:'Paneer tikka (150g) + 3 rotis + salad',                powerFact:'💪 Muscles grow fast — give them protein every meal!' },
      { day:'Tuesday',   breakfast:'Ragi idli (3) + sambar (1 cup) + chutney',               morningSnack:'Yogurt (1 cup) + seeds + honey',         lunch:'Chole (¾ cup) + brown rice + onion salad',   eveningSnack:'Smoothie — milk+banana+peanut butter',   dinner:'Chicken/tofu (150g) + dal + 3 rotis',                  powerFact:'🦴 You are building lifetime bone density now!' },
      { day:'Wednesday', breakfast:'Oats (¾ cup) + milk + 2 boiled eggs',                    morningSnack:'Trail mix + fruit juice',                lunch:'Palak paneer + brown rice + roti + salad',   eveningSnack:'Cheese + crackers + milk',                dinner:'Dal fry + 3 rotis + mixed sabzi + curd',               powerFact:'🥛 3 dairy servings per day builds lifelong bones!' },
      { day:'Thursday',  breakfast:'Multigrain paratha (3) + paneer + curd',                  morningSnack:'Sprouts salad (1 cup)',                  lunch:'Fish curry (150g) or rajma + rice + salad',  eveningSnack:'Milkshake (1.5 cups) + banana + nuts',   dinner:'Egg curry (2-3 eggs) + roti + dal + salad',            powerFact:'🐟 Omega-3 boosts brain performance in exams!' },
      { day:'Friday',    breakfast:'Poha (1.5 cups) + peanuts + 2 eggs',                     morningSnack:'Apple + almond butter',                  lunch:'Mixed dal (¾ cup) + rice + sabzi + raita',   eveningSnack:'Protein bar + milk',                     dinner:'Paneer + 3 rotis + palak + dal',                       powerFact:'🌱 Iron carries oxygen to make you think faster!' },
      { day:'Saturday',  breakfast:'Besan cheela (3) + yogurt + fruit',                       morningSnack:'Nuts + dried fruits mix',               lunch:'Chicken biryani (1.5 cups) + raita + salad', eveningSnack:'Milk + energy balls (2)',                 dinner:'Dal makhani + 3 rotis + sabzi + curd',                 powerFact:'⚡ Complex carbs give 6-8 hours steady energy!' },
      { day:'Sunday',    breakfast:'Grand Sunday breakfast — eggs+toast+fruit+milk',          morningSnack:'Smoothie bowl (large)',                  lunch:'Full Sunday thali — all food groups present', eveningSnack:'Peanut butter sandwich + milk',           dinner:'Maximum nutrition pre-teen fuel dinner',               powerFact:'🏆 Pre-teens who eat right become strongest adults!' },
    ],
    [
      { day:'Monday',    breakfast:'Dalia (¾ cup) + milk + 2 eggs + fruit',                  morningSnack:'Banana + peanut butter toast',           lunch:'Rajma (¾ cup) + brown rice + salad + curd',  eveningSnack:'Milk (1.5 cups) + walnuts (6)',           dinner:'3 rotis + palak paneer + dal + salad',                 powerFact:'🧬 Good nutrition 9-12 shapes your health forever!' },
      { day:'Tuesday',   breakfast:'Ragi dosa (3) + coconut chutney + sambar',               morningSnack:'Greek yogurt + 2 tbsp mixed seeds',      lunch:'Chole + roti + onion tomato salad',           eveningSnack:'Protein smoothie — milk+banana+oats',    dinner:'Chicken/paneer (150g) + 3 rotis + sabzi',              powerFact:'🔋 Pre-teen energy needs are at their highest!' },
      { day:'Wednesday', breakfast:'Egg fried rice (1 cup) or omelette + toast',             morningSnack:'Trail mix + orange',                    lunch:'Fish curry (150g) + rice + palak sabzi',      eveningSnack:'Milk + dates + nuts',                    dinner:'Dal + 3 rotis + mixed veg sabzi + curd',               powerFact:'💊 Iron deficiency is most common at your age!' },
      { day:'Thursday',  breakfast:'Stuffed paratha (3) + curd',                              morningSnack:'Sprouts chaat + lemon',                 lunch:'Mixed dal (¾ cup) + brown rice + sabzi + raita',eveningSnack:'Cheese sandwich + banana + milk',        dinner:'Paneer bhurji + roti + dal + salad',                   powerFact:'🦷 Calcium also keeps your teeth strong and white!' },
      { day:'Friday',    breakfast:'Oat pancakes (3) + honey + nuts + milk',                  morningSnack:'Apple + almond butter (2 tbsp)',         lunch:'Chicken biryani or veg pulao (1.5 cups) + raita',eveningSnack:'Energy balls (2) + milk',               dinner:'Egg/paneer curry + 3 rotis + salad + dal soup',        powerFact:'🎯 Focus foods: eggs, fish, walnuts for concentration!' },
      { day:'Saturday',  breakfast:'Idli (4) + veg sambar + chutney',                        morningSnack:'Fruit bowl + pumpkin seeds + yogurt',   lunch:'Dal makhani + 3 rotis + veg sabzi + salad',  eveningSnack:'Peanut butter banana smoothie',           dinner:'Grilled chicken/tofu (150g) + roti + dal + sabzi',     powerFact:'💥 Your bone density peaks at 18 — build it NOW!' },
      { day:'Sunday',    breakfast:'Mega breakfast — 3 eggs+paratha+fruit+milk',              morningSnack:'Smoothie with protein+fruits+seeds',    lunch:'Grandest thali of the week — all food groups', eveningSnack:'Protein laddoo (2) + milk',               dinner:'Special growth dinner — maximum nutrition content',    powerFact:'🌟 Champions are built in the kitchen — be one!' },
    ],
  ],
};
