import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getAuth }                       from 'firebase-admin/auth';
import { getFirestore, FieldValue }      from 'firebase-admin/firestore';
import dotenv from 'dotenv';

dotenv.config();

if (!getApps().length) {
  if (!process.env.FIREBASE_PROJECT_ID)   throw new Error('Missing env var: FIREBASE_PROJECT_ID');
  if (!process.env.FIREBASE_CLIENT_EMAIL) throw new Error('Missing env var: FIREBASE_CLIENT_EMAIL');
  if (!process.env.FIREBASE_PRIVATE_KEY)  throw new Error('Missing env var: FIREBASE_PRIVATE_KEY');
  initializeApp({
    credential: cert({
      projectId:   process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey:  process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
  });
}

export const adminAuth       = getAuth();
export const adminDb         = getFirestore();
export const adminFieldValue = FieldValue;
