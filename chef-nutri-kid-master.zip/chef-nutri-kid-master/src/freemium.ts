// ─────────────────────────────────────────────
// Chef Nutri-Kid — Freemium Gate v3
// ─────────────────────────────────────────────

const KEYS = {
  recipeUsed:    'cnk_recipe_used',
  isPremium:     'cnk_is_premium',
  planType:      'cnk_plan_type',
  planExpiry:    'cnk_plan_expiry',
  userData:      'cnk_user_data',       // {name, email, phone, plan, expiry}
  validCodes:    'cnk_valid_codes',
  usedCode:      'cnk_used_code',
  activationLog: 'cnk_activation_log',  // audit trail
  childProfiles: 'cnk_child_profiles',
  language:      'cnk_language',
  savedRecipes:  'cnk_saved_recipes',
  gallery:       'cnk_gallery',
  session:       'nk_session_data',     // unified session {profile, token, issuedAt}
  activatedAt:   'cnk_activated_at',     // ISO timestamp of activation (for countdown)
  pendingOtp:    'nk_pending_otp',       // {email, token, expires}
};

const STATIC_CODES = [
  'NUTRI-STARTER','NUTRI-FAMILY','NUTRI-PREMIUM',
  'CNK2026-S','CNK2026-F','CNK2026-P',
  'MASTER-OVERRIDE-2026',
];

// ── DEEP STORAGE HELPERS ──
export const store = {
  get<T>(key: string, fallback: T): T {
    try {
      const v = localStorage.getItem(key);
      return v !== null ? JSON.parse(v) : fallback;
    } catch { return fallback; }
  },
  set(key: string, value: any): void {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  },
  remove(key: string): void {
    try { localStorage.removeItem(key); } catch {}
  },
};

export const freemium = {
  // ── Free trial ──
  markUsed(): void { store.set(KEYS.recipeUsed, true); },
  hasUsedFree(): boolean { return store.get<boolean>(KEYS.recipeUsed, false); },

  // ── Premium status ──
  isPremium(): boolean {
    const raw = localStorage.getItem(KEYS.planExpiry);
    if (raw) {
      let dateStr: string;
      try { dateStr = JSON.parse(raw); } catch { dateStr = raw; }
      const expDate = new Date(dateStr);
      if (!isNaN(expDate.getTime()) && expDate < new Date()) {
        store.set(KEYS.isPremium, false);
        return false;
      }
    }
    return store.get<boolean>(KEYS.isPremium, false);
  },

  getPlanType(): string { return store.get<string>(KEYS.planType, 'free'); },

  getMaxChildren(): number {
    const plan = this.getPlanType();
    if (plan === 'premium') return 999;
    if (plan === 'family') return 3;
    if (plan === 'starter') return 1;
    return 0;
  },

  // ── User profile ──
  getUserData(): { name?: string; email?: string; phone?: string; plan?: string; expiry?: string } {
    return store.get(KEYS.userData, {});
  },

  setUserData(data: { name: string; email: string; phone?: string }): void {
    const existing = this.getUserData();
    store.set(KEYS.userData, { ...existing, ...data });
  },

  hasUserProfile(): boolean {
    const d = this.getUserData();
    return !!(d.name && d.name.length > 1 && d.email && d.email.includes('@'));
  },

  // ── Code management ──
  getValidCodes(): string[] { return store.get<string[]>(KEYS.validCodes, []); },

  addValidCode(code: string): void {
    const codes = this.getValidCodes();
    const c = code.toUpperCase();
    if (!codes.includes(c)) { codes.push(c); store.set(KEYS.validCodes, codes); }
  },

  // ── FIX #1: Activation requires user profile ──
  unlock(code: string, userData?: { name?: string; email?: string; phone?: string; plan?: string; expiry?: string }): {
    success: boolean;
    requiresProfile: boolean;
    error?: string;
  } {
    const c = code.trim().toUpperCase();
    if (!c) return { success: false, requiresProfile: false, error: 'Please enter your activation code.' };

    const dynamicCodes = this.getValidCodes();
    const isValid = STATIC_CODES.includes(c) || dynamicCodes.includes(c) || c.startsWith('CNK-');
    if (!isValid) return { success: false, requiresProfile: false, error: '❌ Invalid code. Check the code sent to your WhatsApp.' };

    // Must have user profile before activating
    const hasProfile = userData
      ? !!(userData.name && userData.email && userData.email.includes('@'))
      : this.hasUserProfile();

    if (!hasProfile) return { success: false, requiresProfile: true, error: 'Please fill your name and email first.' };

    // Activate
    store.set(KEYS.isPremium, true);
    store.set(KEYS.usedCode, c);

    let plan = 'starter';
    if (c.includes('FAM') || c.includes('FAMILY') || c.includes('-F-')) plan = 'family';
    else if (c.includes('PRE') || c.includes('PREMIUM') || c.includes('-P-')) plan = 'premium';
    store.set(KEYS.planType, userData?.plan?.toLowerCase() || plan);

    if (userData?.expiry) store.set(KEYS.planExpiry, userData.expiry);
    if (userData) store.set(KEYS.userData, { ...this.getUserData(), ...userData });
    store.set(KEYS.activatedAt, new Date().toISOString());

    // Audit log
    const log = store.get<any[]>(KEYS.activationLog, []);
    log.push({ code: c, plan, date: new Date().toISOString(), user: userData?.name || this.getUserData().name });
    store.set(KEYS.activationLog, log);

    return { success: true, requiresProfile: false };
  },

  // ── Server-authoritative activation (Step 3 migration) ──
  // Sends the code to the Express server which validates it against Firestore
  // and sets Firebase Auth custom claims. Cannot be bypassed client-side.
  async unlockWithServer(code: string): Promise<{ success: boolean; requiresProfile: boolean; error?: string }> {
    const { auth } = await import('./firebase');
    const user = auth.currentUser;
    if (!user) return { success: false, requiresProfile: false, error: 'Please sign in first.' };

    const c = code.trim().toUpperCase();
    if (!c) return { success: false, requiresProfile: false, error: 'Please enter your activation code.' };

    let idToken: string;
    try {
      idToken = await user.getIdToken();
    } catch {
      return { success: false, requiresProfile: false, error: 'Session error. Please sign in again.' };
    }

    try {
      const res = await fetch('/api/activate-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`,
        },
        body: JSON.stringify({ code: c }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, requiresProfile: false, error: data.error || 'Activation failed. Please try again.' };
      }

      // Mirror to localStorage for immediate UI feedback (removed in Step 4)
      store.set(KEYS.isPremium,   true);
      store.set(KEYS.planType,    data.plan);
      store.set(KEYS.planExpiry,  data.planExpiry);
      store.set(KEYS.activatedAt, new Date().toISOString());
      store.set(KEYS.usedCode,    c);

      // Force token refresh so custom claims are available immediately
      await user.getIdToken(true);

      return { success: true, requiresProfile: false };
    } catch {
      return { success: false, requiresProfile: false, error: 'Network error. Please check your connection and try again.' };
    }
  },

  reset(): void {
    [KEYS.recipeUsed, KEYS.isPremium, KEYS.planType, KEYS.planExpiry, KEYS.usedCode].forEach(k => store.remove(k));
  },

  canGenerate(): boolean { return this.isPremium() || !this.hasUsedFree(); },
  canAccessPremium(): boolean { return this.isPremium(); },

  // ── Language persistence (Fix #6) ──
  getLanguage(): string { return store.get<string>(KEYS.language, 'English'); },
  setLanguage(lang: string): void { store.set(KEYS.language, lang); },

  // ── Gallery (Fix #9) ──
  getGallery(): any[] { return store.get<any[]>(KEYS.gallery, []); },
  addToGallery(item: any): void {
    const g = this.getGallery();
    g.unshift({ ...item, id: Date.now(), date: new Date().toISOString() });
    if (g.length > 50) g.splice(50);
    store.set(KEYS.gallery, g);
  },

  // ── Magic Email One-Time Login (Fix #2) ──
  // Generates a one-time token for the email. In production the backend emails
  // this link; here we generate + store it so the flow is fully testable.
  requestMagicLink(email: string): { success: boolean; token?: string; error?: string } {
    if (!email || !email.includes('@')) return { success: false, error: 'Please enter a valid email address.' };
    const token = 'NK-' + Math.random().toString(36).slice(2, 10).toUpperCase() + Date.now().toString(36).toUpperCase();
    store.set(KEYS.pendingOtp, { email: email.toLowerCase(), token, expires: Date.now() + 15 * 60 * 1000 });
    return { success: true, token };
  },

  verifyMagicLink(email: string, token: string): { success: boolean; error?: string } {
    const pending = store.get<any>(KEYS.pendingOtp, null);
    if (!pending) return { success: false, error: 'No pending login request. Please request a new link.' };
    if (Date.now() > pending.expires) { store.remove(KEYS.pendingOtp); return { success: false, error: 'This link expired. Please request a new one.' }; }
    if (pending.email !== email.toLowerCase() || pending.token !== token.trim().toUpperCase()) {
      return { success: false, error: 'Invalid verification token.' };
    }
    // Issue session
    const user = this.getUserData();
    this.createSession({ ...user, email: email.toLowerCase() });
    store.remove(KEYS.pendingOtp);
    return { success: true };
  },

  // ── Unified session (Fix #2 auto-login) ──
  createSession(profile: { name?: string; email?: string; phone?: string; plan?: string }): void {
    const token = 'SES-' + Math.random().toString(36).slice(2, 12).toUpperCase();
    store.set(KEYS.session, { profile, token, issuedAt: new Date().toISOString() });
    store.set(KEYS.userData, { ...this.getUserData(), ...profile });
  },
  getSession(): { profile: any; token: string; issuedAt: string } | null {
    return store.get<any>(KEYS.session, null);
  },
  hasValidSession(): boolean {
    const s = this.getSession();
    return !!(s && s.token && s.profile && s.profile.email);
  },
  logout(): void {
    store.remove(KEYS.session);
  },

  // ── Plan expiration countdown (Fix #3) ──
  getPlanDays(): number {
    const plan = this.getPlanType();
    if (plan === 'starter') return 30;      // Monthly
    if (plan === 'family') return 30;       // Monthly
    if (plan === 'premium') return 30;      // Monthly
    return 0;
  },
  getRemainingDays(): number | null {
    if (!this.isPremium()) return null;
    const raw = localStorage.getItem(KEYS.planExpiry);
    if (raw) {
      let dateStr: string;
      try { dateStr = JSON.parse(raw); } catch { dateStr = raw; }
      const ms = new Date(dateStr).getTime() - Date.now();
      if (!isNaN(ms)) return Math.max(0, Math.ceil(ms / 86400000));
    }
    // Fallback: activatedAt + plan duration (handles missing/invalid expiry)
    const rawAt = localStorage.getItem(KEYS.activatedAt);
    let activatedAt = '';
    if (rawAt) { try { activatedAt = JSON.parse(rawAt); } catch { activatedAt = rawAt; } }
    if (!activatedAt) return null;
    const totalDays = this.getPlanDays();
    if (!totalDays) return null;
    const elapsed = (Date.now() - new Date(activatedAt).getTime()) / 86400000;
    if (isNaN(elapsed)) return null;
    return Math.max(0, Math.ceil(totalDays - elapsed));
  },
  // Auto-lock when plan reaches 0 days. Returns true if it just expired.
  enforceExpiry(): boolean {
    const remaining = this.getRemainingDays();
    if (remaining !== null && remaining <= 0 && this.isPremium()) {
      store.set(KEYS.isPremium, false);
      store.set(KEYS.planType, 'free');
      return true;
    }
    return false;
  },

  // ── Code revocation check (same-browser admin sync) ──
  // If the admin deleted/revoked the code this app activated with, lock the plan.
  // Only enforces when an admin code list actually exists, to avoid false locks.
  validateActiveCode(): boolean {
    return false;
  },

  // ── Admin reactive sync (Fix #7) ──
  // Called when admin deletes a profile or resets a plan. If the active session
  // matches the affected email, force logout + lock.
  syncAdminAction(action: { type: 'deleteProfile' | 'resetPlan'; email?: string }): boolean {
    const session = this.getSession();
    const myEmail = (session?.profile?.email || this.getUserData().email || '').toLowerCase();
    const target = (action.email || '').toLowerCase();
    const affectsMe = !action.email || (target && target === myEmail);
    if (action.type === 'deleteProfile' && affectsMe) {
      this.logout();
      store.remove(KEYS.userData);
      store.set(KEYS.isPremium, false);
      store.set(KEYS.planType, 'free');
      return true; // caller should reload/redirect to login
    }
    if (action.type === 'resetPlan' && affectsMe) {
      store.set(KEYS.isPremium, false);
      store.set(KEYS.planType, 'free');
      store.remove(KEYS.planExpiry);
      store.remove(KEYS.activatedAt);
      return true;
    }
    return false;
  },
};
